﻿namespace QuanLyEShopping.forms
{
    partial class FrmSanPham
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) { components.Dispose(); }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.cboNhomSanPham = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvSanPham = new System.Windows.Forms.DataGridView();
            this.btnThemGiỏHang = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).BeginInit();
            this.SuspendLayout();
            // 
            // cboNhomSanPham
            // 
            this.cboNhomSanPham.FormattingEnabled = true;
            this.cboNhomSanPham.Location = new System.Drawing.Point(120, 25);
            this.cboNhomSanPham.Name = "cboNhomSanPham";
            this.cboNhomSanPham.Size = new System.Drawing.Size(250, 21);
            this.cboNhomSanPham.TabIndex = 0;
            this.cboNhomSanPham.SelectedIndexChanged += new System.EventHandler(this.cboNhomSanPham_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(25, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Chọn Nhóm SP:";
            // 
            // dgvSanPham
            // 
            this.dgvSanPham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSanPham.Location = new System.Drawing.Point(25, 70);
            this.dgvSanPham.Name = "dgvSanPham";
            this.dgvSanPham.Size = new System.Drawing.Size(650, 300);
            this.dgvSanPham.TabIndex = 2;
            // 
            // btnThemGiỏHang
            // 
            this.btnThemGiỏHang.Location = new System.Drawing.Point(525, 390);
            this.btnThemGiỏHang.Name = "btnThemGiỏHang";
            this.btnThemGiỏHang.Size = new System.Drawing.Size(150, 35);
            this.btnThemGiỏHang.TabIndex = 3;
            this.btnThemGiỏHang.Text = "Thêm vào giỏ hàng";
            this.btnThemGiỏHang.UseVisualStyleBackColor = true;
            this.btnThemGiỏHang.Click += new System.EventHandler(this.btnThemGiỏHang_Click);
            // 
            // FrmSanPham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 450);
            this.Controls.Add(this.btnThemGiỏHang);
            this.Controls.Add(this.dgvSanPham);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cboNhomSanPham);
            this.Name = "FrmSanPham";
            this.Text = "Danh Mục Sản Phẩm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvSanPham)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.ComboBox cboNhomSanPham;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dgvSanPham;
        private System.Windows.Forms.Button btnThemGiỏHang;
    }
}