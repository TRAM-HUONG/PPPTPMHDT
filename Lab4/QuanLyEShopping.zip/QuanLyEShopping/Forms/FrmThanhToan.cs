﻿using System;
using System.Windows.Forms;
using QuanLyEShopping.Services;

namespace QuanLyEShopping.forms
{
    public partial class FrmThanhToan : Form
    {
        private ThanhToanService ttService = new ThanhToanService();
        private string soDDHCurrent;
        private decimal tongTienCurrent;

        public FrmThanhToan(string soDDH, decimal tongTien)
        {
            InitializeComponent();
            soDDHCurrent = soDDH;
            tongTienCurrent = tongTien;
            lblSoTien.Text = $"Số tiền cần thanh toán: {tongTienCurrent:N0} đ";

            // Khởi tạo danh sách loại thẻ phổ biến theo đặc tả UC07
            cboLoaiThe.Items.Add("VISA");
            cboLoaiThe.Items.Add("MasterCard");
            cboLoaiThe.Items.Add("Discover");
            cboLoaiThe.Items.Add("American Express");
            cboLoaiThe.SelectedIndex = 0;
        }

        private void btnXacNhanThanhToan_Click(object sender, EventArgs e)
        {
            string loaiThe = cboLoaiThe.SelectedItem.ToString();
            string soHieuThe = txtSoHieuThe.Text.Trim();
            string ngayHetHan = txtNgayHetHan.Text.Trim();
            string hoTenChuThe = txtHoTenChuThe.Text.Trim();
            string csv = txtCSV.Text.Trim();

            // Kiểm tra ràng buộc cơ bản theo đặc tả UC07 (Số hiệu thẻ 15-16 chữ số, mã CSV 3-4 chữ số)
            if (string.IsNullOrEmpty(soHieuThe) || string.IsNullOrEmpty(ngayHetHan) || string.IsNullOrEmpty(hoTenChuThe) || string.IsNullOrEmpty(csv))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin thẻ tín dụng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (soHieuThe.Length < 15 || soHieuThe.Length > 16)
            {
                MessageBox.Show("Số hiệu thẻ tín dụng phải từ 15 đến 16 chữ số!", "Lỗi định dạng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (csv.Length < 3 || csv.Length > 4)
            {
                MessageBox.Show("Mã số an ninh CSV phải có từ 3 đến 4 chữ số!", "Lỗi định dạng", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string maGiaoDich = "GD" + DateTime.Now.ToString("yyMMddHHmmss");

            // Gọi Service kết nối cổng thanh toán để lưu giao dịch
            bool kq = ttService.LuuThongTinThanhToan(maGiaoDich, soDDHCurrent, loaiThe, soHieuThe, ngayHetHan, hoTenChuThe, csv, "Thành công");

            if (kq)
            {
                MessageBox.Show("Giao dịch thanh toán thẻ thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                MessageBox.Show("Thanh toán thất bại do lỗi hệ thống hoặc trùng mã giao dịch.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}