﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyEShopping.Services;

namespace QuanLyEShopping.forms
{
    public partial class FrmGioHang : Form
    {
        private GioHangService ghService = new GioHangService();
        private string maKHCurrent;

        public FrmGioHang(string maKH = "KH01")
        {
            InitializeComponent();
            maKHCurrent = maKH;
            LoadDanhSachGioHang();
        }

        private void LoadDanhSachGioHang()
        {
            DataTable dt = ghService.LayDanhSachGioHang(maKHCurrent);
            dgvGioHang.DataSource = dt;

            // Tính tổng tiền tạm tính cho toàn bộ giỏ hàng
            decimal tongTien = 0;
            foreach (DataRow row in dt.Rows)
            {
                tongTien += decimal.Parse(row["THANHTIEN"].ToString());
            }
            lblTongTien.Text = $"Tổng tiền tạm tính: {tongTien:N0} đ";
        }

        private void btnXoaSanPham_Click(object sender, EventArgs e)
        {
            if (dgvGioHang.CurrentRow != null)
            {
                string maSP = dgvGioHang.CurrentRow.Cells["MASP"].Value.ToString();
                bool kq = ghService.XoaKhoiGioHang(maKHCurrent, maSP);

                if (kq)
                {
                    MessageBox.Show("Đã xóa sản phẩm khỏi giỏ hàng thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    LoadDanhSachGioHang();
                }
                else
                {
                    MessageBox.Show("Xóa sản phẩm thất bại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn sản phẩm cần xóa trong danh sách giỏ hàng.", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnTienDatHang_Click(object sender, EventArgs e)
        {
            if (dgvGioHang.Rows.Count == 0)
            {
                MessageBox.Show("Giỏ hàng của bạn đang trống, không thể tiến hành đặt hàng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Mở form tiến hành đặt hàng và chọn hình thức vận chuyển (UC06)
            FrmDatHang frm = new FrmDatHang(maKHCurrent);
            frm.ShowDialog();
            LoadDanhSachGioHang(); // Tải lại giỏ hàng sau khi đặt thành công
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}