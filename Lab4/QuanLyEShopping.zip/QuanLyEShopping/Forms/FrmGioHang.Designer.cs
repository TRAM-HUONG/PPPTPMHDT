﻿namespace QuanLyEShopping.forms
{
    partial class FrmGioHang
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) { components.Dispose(); }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvGioHang = new System.Windows.Forms.DataGridView();
            this.btnXoaSanPham = new System.Windows.Forms.Button();
            this.btnTienDatHang = new System.Windows.Forms.Button();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvGioHang
            // 
            this.dgvGioHang.AllowUserToAddRows = false;
            this.dgvGioHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvGioHang.Location = new System.Drawing.Point(25, 25);
            this.dgvGioHang.Name = "dgvGioHang";
            this.dgvGioHang.ReadOnly = true;
            this.dgvGioHang.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvGioHang.Size = new System.Drawing.Size(660, 280);
            this.dgvGioHang.TabIndex = 0;
            // 
            // btnXoaSanPham
            // 
            this.btnXoaSanPham.Location = new System.Drawing.Point(25, 360);
            this.btnXoaSanPham.Name = "btnXoaSanPham";
            this.btnXoaSanPham.Size = new System.Drawing.Size(130, 35);
            this.btnXoaSanPham.TabIndex = 1;
            this.btnXoaSanPham.Text = "Xóa Sản Phẩm";
            this.btnXoaSanPham.UseVisualStyleBackColor = true;
            this.btnXoaSanPham.Click += new System.EventHandler(this.btnXoaSanPham_Click);
            // 
            // btnTienDatHang
            // 
            this.btnTienDatHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTienDatHang.ForeColor = System.Drawing.Color.DarkGreen;
            this.btnTienDatHang.Location = new System.Drawing.Point(415, 360);
            this.btnTienDatHang.Name = "btnTienDatHang";
            this.btnTienDatHang.Size = new System.Drawing.Size(140, 35);
            this.btnTienDatHang.TabIndex = 2;
            this.btnTienDatHang.Text = "Tiến Hành Đặt Hàng";
            this.btnTienDatHang.UseVisualStyleBackColor = true;
            this.btnTienDatHang.Click += new System.EventHandler(this.btnTienDatHang_Click);
            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongTien.ForeColor = System.Drawing.Color.Red;
            this.lblTongTien.Location = new System.Drawing.Point(412, 320);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(161, 16);
            this.lblTongTien.TabIndex = 3;
            this.lblTongTien.Text = "Tổng tiền tạm tính: 0 đ";
            // 
            // btnDong
            // 
            this.btnDong.Location = new System.Drawing.Point(575, 360);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(110, 35);
            this.btnDong.TabIndex = 4;
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // FrmGioHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(715, 420);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.lblTongTien);
            this.Controls.Add(this.btnTienDatHang);
            this.Controls.Add(this.btnXoaSanPham);
            this.Controls.Add(this.dgvGioHang);
            this.Name = "FrmGioHang";
            this.Text = "Giỏ Hàng Tạm Thời - e-SHOPPING";
            ((System.ComponentModel.ISupportInitialize)(this.dgvGioHang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.DataGridView dgvGioHang;
        private System.Windows.Forms.Button btnXoaSanPham;
        private System.Windows.Forms.Button btnTienDatHang;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.Button btnDong;
    }
}