﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyEShopping.Services;

namespace QuanLyEShopping.forms
{
    public partial class FrmDatHang : Form
    {
        private DatHangService dhService = new DatHangService();
        private GioHangService ghService = new GioHangService();
        private string maKHCurrent;
        private DataTable dtGioHangHienTai;
        private decimal tongTienHang = 0;

        public FrmDatHang(string maKH)
        {
            InitializeComponent();
            maKHCurrent = maKH;
            LoadThongTinDatHang();
        }

        private void LoadThongTinDatHang()
        {
            // Load hình thức giao hàng / loại phiếu (Phục vụ UC06)
            cboLoaiPhieu.DataSource = dhService.LayDanhSachLoaiPhiếu();
            cboLoaiPhieu.DisplayMember = "TENLOAIPHIEU";
            cboLoaiPhieu.ValueMember = "MALOAIPHIEU";

            // Load giỏ hàng của khách để tính tổng trị giá tiền hàng
            dtGioHangHienTai = ghService.LayDanhSachGioHang(maKHCurrent);
            foreach (DataRow row in dtGioHangHienTai.Rows)
            {
                tongTienHang += decimal.Parse(row["THANHTIEN"].ToString());
            }

            lblTongTienHang.Text = $"Tổng tiền hàng: {tongTienHang:N0} đ";
            TinhToanPhiVanChuyen();
        }

        private void cboLoaiPhieu_SelectedIndexChanged(object sender, EventArgs e)
        {
            TinhToanPhiVanChuyen();
        }

        private void TinhToanPhiVanChuyen()
        {
            if (cboLoaiPhieu.SelectedValue != null)
            {
                string maLoaiPhieu = cboLoaiPhieu.SelectedValue.ToString();

                // Tự động kiểm tra chính sách ưu đãi miễn phí vận chuyển theo tổng tiền
                decimal phiGiao = dhService.TinhPhiGiaoHang(maLoaiPhieu, tongTienHang);

                lblPhiGiaoHang.Text = $"Phí giao hàng: {phiGiao:N0} đ (Đã áp dụng chính sách ưu đãi)";
                lblTongThanhToan.Text = $"Tổng thanh toán: {(tongTienHang + phiGiao):N0} đ";
            }
        }

        private void btnXacNhanDatHang_Click(object sender, EventArgs e)
        {
            string soDDH = "DH" + DateTime.Now.ToString("yyyyMMddHHmmss");
            string maLoaiPhieu = cboLoaiPhieu.SelectedValue.ToString();
            decimal phiGiao = dhService.TinhPhiGiaoHang(maLoaiPhieu, tongTienHang);
            decimal tongTriGia = tongTienHang + phiGiao;

            string tenNhan = txtTenNguoiNhan.Text.Trim();
            string diaChiNhan = txtDiaChiNhan.Text.Trim();
            string dtNhan = txtDienThoaiNhan.Text.Trim();

            if (string.IsNullOrEmpty(tenNhan) || string.IsNullOrEmpty(diaChiNhan) || string.IsNullOrEmpty(dtNhan))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin người nhận hàng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dtGioHangHienTai.Rows.Count == 0)
            {
                MessageBox.Show("Giỏ hàng của bạn đang trống, không thể tiến hành đặt hàng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // BƯỚC 1: Lưu đơn hàng vào CSDL trước để tạo ra SODDH trong bảng DONHANG
            bool taoDonHangThanhCong = dhService.TaoDonHangVaChiTiet(soDDH, maKHCurrent, maLoaiPhieu, tongTriGia, phiGiao, tenNhan, diaChiNhan, dtNhan, dtGioHangHienTai);

            if (!taoDonHangThanhCong)
            {
                MessageBox.Show("Lỗi khi tạo đơn hàng trong hệ thống.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // BƯỚC 2: Sau khi đơn hàng đã tồn tại trong CSDL, mới mở Form thanh toán thẻ tín dụng
            FrmThanhToan frmTT = new FrmThanhToan(soDDH, tongTriGia);
            if (frmTT.ShowDialog() == DialogResult.OK)
            {
                MessageBox.Show("Đặt hàng và thanh toán thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                // Nếu người dùng bấm hủy thanh toán ở form sau, có thể thông báo đơn hàng đang chờ thanh toán
                MessageBox.Show("Thanh toán không hoàn tất. Đơn hàng đã được lưu ở trạng thái chờ thanh toán.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                this.Close();
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}