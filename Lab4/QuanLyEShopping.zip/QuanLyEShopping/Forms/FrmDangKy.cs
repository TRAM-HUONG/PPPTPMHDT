﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyEShopping.Services;

namespace QuanLyEShopping.forms
{
    public partial class FrmDangKy : Form
    {
        private KhachHangService khService = new KhachHangService();

        public FrmDangKy()
        {
            InitializeComponent();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            // Lấy thông tin từ các điều khiển trên giao diện Form theo đặc tả UC01
            string maKH = txtMaKH.Text.Trim();
            string hoTen = txtHoTen.Text.Trim();
            DateTime ngaySinh = dtpNgaySinh.Value;
            string cccd = txtCCCD.Text.Trim();
            string diaChi = txtDiaChi.Text.Trim();
            string dienThoai = txtDienThoai.Text.Trim();
            string tenDangNhap = txtTenDangNhap.Text.Trim();
            string matKhau = txtMatKhau.Text.Trim();
            string email = txtEmail.Text.Trim();

            // Kiểm tra dữ liệu cơ bản không được để trống
            if (string.IsNullOrEmpty(maKH) || string.IsNullOrEmpty(tenDangNhap) || string.IsNullOrEmpty(matKhau) || string.IsNullOrEmpty(cccd))
            {
                MessageBox.Show("Vui lòng điền đầy đủ các thông tin bắt buộc (Mã KH, CCCD, Tên đăng nhập, Mật khẩu)!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // Gọi tầng Service để thực hiện lưu vào cơ sở dữ liệu
                bool ketQua = khService.DangKy(maKH, hoTen, ngaySinh, cccd, diaChi, dienThoai, tenDangNhap, matKhau, email);

                if (ketQua)
                {
                    MessageBox.Show("Đăng ký tài khoản khách hàng thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Đăng ký thất bại. Vui lòng kiểm tra lại thông tin (Tên đăng nhập hoặc CCCD có thể đã tồn tại).", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi hệ thống hoặc trùng khóa dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}