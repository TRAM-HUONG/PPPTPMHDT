﻿namespace QuanLyEShopping.forms
{
    partial class FrmThanhToan
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) { components.Dispose(); }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cboLoaiThe = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSoHieuThe = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNgayHetHan = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtHoTenChuThe = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtCSV = new System.Windows.Forms.TextBox();
            this.lblSoTien = new System.Windows.Forms.Label();
            this.btnXacNhanThanhToan = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Loại thẻ:";
            // 
            // cboLoaiThe
            // 
            this.cboLoaiThe.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiThe.FormattingEnabled = true;
            this.cboLoaiThe.Location = new System.Drawing.Point(140, 67);
            this.cboLoaiThe.Name = "cboLoaiThe";
            this.cboLoaiThe.Size = new System.Drawing.Size(230, 21);
            this.cboLoaiThe.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Số hiệu thẻ:";
            // 
            // txtSoHieuThe
            // 
            this.txtSoHieuThe.Location = new System.Drawing.Point(140, 112);
            this.txtSoHieuThe.Name = "txtSoHieuThe";
            this.txtSoHieuThe.Size = new System.Drawing.Size(230, 20);
            this.txtSoHieuThe.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 160);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Ngày hết hạn:";
            // 
            // txtNgayHetHan
            // 
            this.txtNgayHetHan.Location = new System.Drawing.Point(140, 157);
            this.txtNgayHetHan.Name = "txtNgayHetHan";
            this.txtNgayHetHan.Size = new System.Drawing.Size(230, 20);
            this.txtNgayHetHan.TabIndex = 5;
            this.txtNgayHetHan.Text = "MM/YY";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Họ tên chủ thẻ:";
            // 
            // txtHoTenChuThe
            // 
            this.txtHoTenChuThe.Location = new System.Drawing.Point(140, 202);
            this.txtHoTenChuThe.Name = "txtHoTenChuThe";
            this.txtHoTenChuThe.Size = new System.Drawing.Size(230, 20);
            this.txtHoTenChuThe.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 250);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Mã an ninh (CSV):";
            // 
            // txtCSV
            // 
            this.txtCSV.Location = new System.Drawing.Point(140, 247);
            this.txtCSV.Name = "txtCSV";
            this.txtCSV.PasswordChar = '*';
            this.txtCSV.Size = new System.Drawing.Size(100, 20);
            this.txtCSV.TabIndex = 9;
            // 
            // lblSoTien
            // 
            this.lblSoTien.AutoSize = true;
            this.lblSoTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSoTien.ForeColor = System.Drawing.Color.Blue;
            this.lblSoTien.Location = new System.Drawing.Point(30, 25);
            this.lblSoTien.Name = "lblSoTien";
            this.lblSoTien.Size = new System.Drawing.Size(186, 16);
            this.lblSoTien.TabIndex = 10;
            this.lblSoTien.Text = "Số tiền cần thanh toán: 0 đ";
            // 
            // btnXacNhanThanhToan
            // 
            this.btnXacNhanThanhToan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXacNhanThanhToan.Location = new System.Drawing.Point(140, 300);
            this.btnXacNhanThanhToan.Name = "btnXacNhanThanhToan";
            this.btnXacNhanThanhToan.Size = new System.Drawing.Size(110, 35);
            this.btnXacNhanThanhToan.TabIndex = 11;
            this.btnXacNhanThanhToan.Text = "Thanh Toán";
            this.btnXacNhanThanhToan.UseVisualStyleBackColor = true;
            this.btnXacNhanThanhToan.Click += new System.EventHandler(this.btnXacNhanThanhToan_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(265, 300);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(105, 35);
            this.btnHuy.TabIndex = 12;
            this.btnHuy.Text = "Hủy Bỏ";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // FrmThanhToan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(410, 365);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnXacNhanThanhToan);
            this.Controls.Add(this.lblSoTien);
            this.Controls.Add(this.txtCSV);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtHoTenChuThe);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNgayHetHan);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSoHieuThe);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cboLoaiThe);
            this.Controls.Add(this.label1);
            this.Name = "FrmThanhToan";
            this.Text = "Thanh Toán Thẻ Tín Dụng Trực Tuyến";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cboLoaiThe;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSoHieuThe;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNgayHetHan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtHoTenChuThe;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtCSV;
        private System.Windows.Forms.Label lblSoTien;
        private System.Windows.Forms.Button btnXacNhanThanhToan;
        private System.Windows.Forms.Button btnHuy;
    }
}