﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using QuanLyEShopping.Services;

namespace QuanLyEShopping.forms
{
    public partial class FrmQuanLyTaiKhoan : Form
    {
        private KhachHangService khService = new KhachHangService();
        private string maKHCurrent;

        public FrmQuanLyTaiKhoan(string maKH)
        {
            InitializeComponent();
            maKHCurrent = maKH;
            LoadThongTinTaiKhoan();
        }

        private void LoadThongTinTaiKhoan()
        {
            DataTable dt = khService.LayThongTinKhachHang(maKHCurrent);
            if (dt.Rows.Count > 0)
            {
                DataRow row = dt.Rows[0];
                txtMaKH.Text = row["MAKH"].ToString();
                txtHoTen.Text = row["HOTEN"].ToString();

                // Hiển thị ngày sinh nếu có giá trị
                if (row["NGAYSINH"] != DBNull.Value)
                {
                    dtpNgaySinh.Value = Convert.ToDateTime(row["NGAYSINH"]);
                }

                txtCCCD.Text = row["CCCD"].ToString();
                txtDiaChi.Text = row["DIACHI"].ToString();
                txtDienThoai.Text = row["DIENTHOAI"].ToString();
                txtTenDangNhap.Text = row["TENDANGNHAP"].ToString();
                txtEmail.Text = row["EMAIL"].ToString();

                // Khóa không cho sửa mã khách hàng, số CCCD và tên đăng nhập để bảo toàn tính nhất quán dữ liệu
                txtMaKH.ReadOnly = true;
                txtCCCD.ReadOnly = true;
                txtTenDangNhap.ReadOnly = true;
            }
        }

        private void btnCapNhat_Click(object sender, EventArgs e)
        {
            string hoTen = txtHoTen.Text.Trim();
            string diaChi = txtDiaChi.Text.Trim();
            string dienThoai = txtDienThoai.Text.Trim();
            string email = txtEmail.Text.Trim();

            if (string.IsNullOrEmpty(hoTen))
            {
                MessageBox.Show("Họ tên khách hàng không được để trống!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool kq = khService.CapNhatThongTin(maKHCurrent, hoTen, diaChi, dienThoai, email);

            if (kq)
            {
                MessageBox.Show("Cập nhật thông tin tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Cập nhật thông tin thất bại. Vui lòng thử lại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}