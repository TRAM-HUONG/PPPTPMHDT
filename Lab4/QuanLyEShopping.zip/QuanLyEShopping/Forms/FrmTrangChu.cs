﻿using System;
using System.Windows.Forms;

namespace QuanLyEShopping.forms
{
    public partial class FrmTrangChu : Form
    {
        private string maKHLogin;

        public FrmTrangChu(string maKH)
        {
            InitializeComponent();
            maKHLogin = maKH;
            lblChaoMung.Text = $"Xin chào khách hàng: {maKHLogin}";
        }

        public FrmTrangChu()
        {
        }

        private void btnSanPham_Click(object sender, EventArgs e)
        {
            FrmSanPham frm = new FrmSanPham();
            frm.ShowDialog();
        }

        private void btnGioHang_Click(object sender, EventArgs e)
        {
            FrmGioHang frm = new FrmGioHang();
            frm.ShowDialog();
        }

        private void btnTaiKhoan_Click(object sender, EventArgs e)
        {
            FrmQuanLyTaiKhoan frm = new FrmQuanLyTaiKhoan(maKHLogin);
            frm.ShowDialog();
        }

        private void btnDangXuat_Click(object sender, EventArgs e)
        {
            this.Hide();
            FrmDangNhap frm = new FrmDangNhap();
            frm.ShowDialog();
            this.Close();
        }
    }
}