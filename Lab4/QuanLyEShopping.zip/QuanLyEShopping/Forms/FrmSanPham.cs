﻿
using QuanLyEShopping.Services;
using System;
using System.Data;
using System.Windows.Forms;

namespace QuanLyEShopping.forms
{
    public partial class FrmSanPham : Form
    {
        private SanPhamService spService = new SanPhamService();
        private GioHangService ghService = new GioHangService();
        private string maKHCurrent = "KH01"; // Giả định mã khách hàng hiện tại

        public FrmSanPham()
        {
            InitializeComponent();
            LoadNhomSanPham();
        }

        private void LoadNhomSanPham()
        {
            DataTable dt = spService.LayDanhSachNhomSanPham();
            cboNhomSanPham.DataSource = dt;
            cboNhomSanPham.DisplayMember = "TENNHOM";
            cboNhomSanPham.ValueMember = "MANHOM";
        }

        private void cboNhomSanPham_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboNhomSanPham.SelectedValue != null)
            {
                string maNhom = cboNhomSanPham.SelectedValue.ToString();
                DataTable dt = spService.LaySanPhamTheoNhom(maNhom);
                dgvSanPham.DataSource = dt;
            }
        }

        private void btnThemGiỏHang_Click(object sender, EventArgs e)
        {
            if (dgvSanPham.CurrentRow != null)
            {
                string maSP = dgvSanPham.CurrentRow.Cells["MASP"].Value.ToString();
                bool kq = ghService.ThemVaoGioHang(maKHCurrent, maSP, 1);
                if (kq)
                {
                    MessageBox.Show("Đã thêm sản phẩm vào giỏ hàng thành công!");
                }
                else
                {
                    MessageBox.Show("Thêm vào giỏ hàng thất bại.");
                }
            }
        }
    }
}