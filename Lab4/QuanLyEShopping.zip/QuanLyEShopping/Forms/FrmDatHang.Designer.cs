﻿namespace QuanLyEShopping.forms
{
    partial class FrmDatHang
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) { components.Dispose(); }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtTenNguoiNhan = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDiaChiNhan = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDienThoaiNhan = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboLoaiPhieu = new System.Windows.Forms.ComboBox();
            this.lblTongTienHang = new System.Windows.Forms.Label();
            this.lblPhiGiaoHang = new System.Windows.Forms.Label();
            this.lblTongThanhToan = new System.Windows.Forms.Label();
            this.btnXacNhanDatHang = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDienThoaiNhan);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.txtDiaChiNhan);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.txtTenNguoiNhan);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(25, 20);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(430, 160);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Thông Tin Người Nhận Hàng";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Họ tên người nhận:";
            // 
            // txtTenNguoiNhan
            // 
            this.txtTenNguoiNhan.Location = new System.Drawing.Point(135, 29);
            this.txtTenNguoiNhan.Name = "txtTenNguoiNhan";
            this.txtTenNguoiNhan.Size = new System.Drawing.Size(265, 20);
            this.txtTenNguoiNhan.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 75);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Địa chỉ giao nhận:";
            // 
            // txtDiaChiNhan
            // 
            this.txtDiaChiNhan.Location = new System.Drawing.Point(135, 72);
            this.txtDiaChiNhan.Name = "txtDiaChiNhan";
            this.txtDiaChiNhan.Size = new System.Drawing.Size(265, 20);
            this.txtDiaChiNhan.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 118);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Điện thoại nhận hàng:";
            // 
            // txtDienThoaiNhan
            // 
            this.txtDienThoaiNhan.Location = new System.Drawing.Point(135, 115);
            this.txtDienThoaiNhan.Name = "txtDienThoaiNhan";
            this.txtDienThoaiNhan.Size = new System.Drawing.Size(265, 20);
            this.txtDienThoaiNhan.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 205);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(107, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Hình thức giao hàng:";
            // 
            // cboLoaiPhieu
            // 
            this.cboLoaiPhieu.FormattingEnabled = true;
            this.cboLoaiPhieu.Location = new System.Drawing.Point(160, 202);
            this.cboLoaiPhieu.Name = "cboLoaiPhieu";
            this.cboLoaiPhieu.Size = new System.Drawing.Size(265, 21);
            this.cboLoaiPhieu.TabIndex = 2;
            this.cboLoaiPhieu.SelectedIndexChanged += new System.EventHandler(this.cboLoaiPhieu_SelectedIndexChanged);
            // 
            // lblTongTienHang
            // 
            this.lblTongTienHang.AutoSize = true;
            this.lblTongTienHang.Location = new System.Drawing.Point(35, 250);
            this.lblTongTienHang.Name = "lblTongTienHang";
            this.lblTongTienHang.Size = new System.Drawing.Size(117, 13);
            this.lblTongTienHang.TabIndex = 3;
            this.lblTongTienHang.Text = "Tổng tiền hàng: 0 đ";
            // 
            // lblPhiGiaoHang
            // 
            this.lblPhiGiaoHang.AutoSize = true;
            this.lblPhiGiaoHang.Location = new System.Drawing.Point(35, 280);
            this.lblPhiGiaoHang.Name = "lblPhiGiaoHang";
            this.lblPhiGiaoHang.Size = new System.Drawing.Size(114, 13);
            this.lblPhiGiaoHang.TabIndex = 4;
            this.lblPhiGiaoHang.Text = "Phí giao hàng: 0 đ";
            // 
            // lblTongThanhToan
            // 
            this.lblTongThanhToan.AutoSize = true;
            this.lblTongThanhToan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongThanhToan.ForeColor = System.Drawing.Color.Red;
            this.lblTongThanhToan.Location = new System.Drawing.Point(35, 315);
            this.lblTongThanhToan.Name = "lblTongThanhToan";
            this.lblTongThanhToan.Size = new System.Drawing.Size(155, 16);
            this.lblTongThanhToan.TabIndex = 5;
            this.lblTongThanhToan.Text = "Tổng thanh toán: 0 đ";
            // 
            // btnXacNhanDatHang
            // 
            this.btnXacNhanDatHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXacNhanDatHang.Location = new System.Drawing.Point(160, 365);
            this.btnXacNhanDatHang.Name = "btnXacNhanDatHang";
            this.btnXacNhanDatHang.Size = new System.Drawing.Size(130, 35);
            this.btnXacNhanDatHang.TabIndex = 6;
            this.btnXacNhanDatHang.Text = "Xác Nhận Đặt Hàng";
            this.btnXacNhanDatHang.UseVisualStyleBackColor = true;
            this.btnXacNhanDatHang.Click += new System.EventHandler(this.btnXacNhanDatHang_Click);
            // 
            // btnHuy
            // 
            this.btnHuy.Location = new System.Drawing.Point(310, 365);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(115, 35);
            this.btnHuy.TabIndex = 7;
            this.btnHuy.Text = "Hủy Bỏ";
            this.btnHuy.UseVisualStyleBackColor = true;
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // FrmDatHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 430);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnXacNhanDatHang);
            this.Controls.Add(this.lblTongThanhToan);
            this.Controls.Add(this.lblPhiGiaoHang);
            this.Controls.Add(this.lblTongTienHang);
            this.Controls.Add(this.cboLoaiPhieu);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.groupBox1);
            this.Name = "FrmDatHang";
            this.Text = "Xác Nhận Đặt Hàng & Giao Nhận";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTenNguoiNhan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDiaChiNhan;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDienThoaiNhan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboLoaiPhieu;
        private System.Windows.Forms.Label lblTongTienHang;
        private System.Windows.Forms.Label lblPhiGiaoHang;
        private System.Windows.Forms.Label lblTongThanhToan;
        private System.Windows.Forms.Button btnXacNhanDatHang;
        private System.Windows.Forms.Button btnHuy;
    }
}