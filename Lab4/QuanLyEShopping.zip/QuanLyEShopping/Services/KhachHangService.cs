﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyEShopping.Services
{
    public class KhachHangService
    {
        // Xác thực thông tin đăng nhập hệ thống (UC02)[cite: 5]
        public DataTable DangNhap(string tenDangNhap, string matKhau)
        {
            string sql = "SELECT * FROM KHACHHANG WHERE TENDANGNHAP = @User AND MATKHAU = @Pass";
            return data.Data.Query(sql,
                new SqlParameter("@User", tenDangNhap),
                new SqlParameter("@Pass", matKhau));
        }

        // Đăng ký tài khoản khách hàng mới (UC01)[cite: 5]
        public bool DangKy(string maKH, string hoTen, DateTime ngaySinh, string cccd, string diaChi, string dienThoai, string tenDangNhap, string matKhau, string email)
        {
            string sql = @"INSERT INTO KHACHHANG (MAKH, HOTEN, NGAYSINH, CCCD, DIACHI, DIENTHOAI, TENDANGNHAP, MATKHAU, EMAIL)
                           VALUES (@MaKH, @HoTen, @NgaySinh, @CCCD, @DiaChi, @DienThoai, @TenDangNhap, @MatKhau, @Email)";

            int kq = data.Data.Execute(sql,
                new SqlParameter("@MaKH", maKH),
                new SqlParameter("@HoTen", hoTen),
                new SqlParameter("@NgaySinh", ngaySinh),
                new SqlParameter("@CCCD", cccd),
                new SqlParameter("@DiaChi", diaChi),
                new SqlParameter("@DienThoai", dienThoai),
                new SqlParameter("@TenDangNhap", tenDangNhap),
                new SqlParameter("@MatKhau", matKhau),
                new SqlParameter("@Email", email));
            return kq > 0;
        }

        // Lấy thông tin chi tiết của một khách hàng theo mã
        public DataTable LayThongTinKhachHang(string maKH)
        {
            string sql = "SELECT * FROM KHACHHANG WHERE MAKH = @MaKH";
            return data.Data.Query(sql, new SqlParameter("@MaKH", maKH));
        }

        // Cập nhật thông tin cá nhân khách hàng (UC05)[cite: 5]
        public bool CapNhatThongTin(string maKH, string hoTen, string diaChi, string dienThoai, string email)
        {
            string sql = @"UPDATE KHACHHANG 
                           SET HOTEN = @HoTen, DIACHI = @DiaChi, DIENTHOAI = @DienThoai, EMAIL = @Email 
                           WHERE MAKH = @MaKH";

            int kq = data.Data.Execute(sql,
                new SqlParameter("@HoTen", hoTen),
                new SqlParameter("@DiaChi", diaChi),
                new SqlParameter("@DienThoai", dienThoai),
                new SqlParameter("@Email", email),
                new SqlParameter("@MaKH", maKH));
            return kq > 0;
        }
    }
}