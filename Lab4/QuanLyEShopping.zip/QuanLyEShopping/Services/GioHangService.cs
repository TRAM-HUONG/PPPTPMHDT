﻿using System.Data;
using System.Data.SqlClient;

namespace QuanLyEShopping.Services
{
    public class GioHangService
    {
        // Lấy danh sách sản phẩm có trong giỏ hàng của khách hàng
        public DataTable LayDanhSachGioHang(string maKH)
        {
            string sql = @"SELECT GH.MAKH, GH.MASP, SP.TENSP, GH.SOLUONG, SP.GIABANHIENHANH AS DONGIA, 
                                  (GH.SOLUONG * SP.GIABANHIENHANH) AS THANHTIEN 
                           FROM GIOHANG GH 
                           JOIN SANPHAM SP ON GH.MASP = SP.MASP 
                           WHERE GH.MAKH = @MaKH";
            return data.Data.Query(sql, new SqlParameter("@MaKH", maKH));
        }

        // Thêm sản phẩm vào giỏ hàng (Nếu đã có thì tăng số lượng, chưa có thì thêm mới)
        public bool ThemVaoGioHang(string maKH, string maSP, int soLuongThem)
        {
            string sql = @"IF EXISTS (SELECT * FROM GIOHANG WHERE MAKH = @MaKH AND MASP = @MaSP)
                               UPDATE GIOHANG SET SOLUONG = SOLUONG + @SoLuong WHERE MAKH = @MaKH AND MASP = @MaSP
                           ELSE
                               INSERT INTO GIOHANG (MAKH, MASP, SOLUONG) VALUES (@MaKH, @MaSP, @SoLuong)";

            int kq = data.Data.Execute(sql,
                new SqlParameter("@MaKH", maKH),
                new SqlParameter("@MaSP", maSP),
                new SqlParameter("@SoLuong", soLuongThem));
            return kq > 0;
        }

        // Xóa một sản phẩm cụ thể khỏi giỏ hàng
        public bool XoaKhoiGioHang(string maKH, string maSP)
        {
            string sql = "DELETE FROM GIOHANG WHERE MAKH = @MaKH AND MASP = @MaSP";
            int kq = data.Data.Execute(sql,
                new SqlParameter("@MaKH", maKH),
                new SqlParameter("@MaSP", maSP));
            return kq > 0;
        }

        // Cập nhật số lượng sản phẩm trong giỏ hàng
        public bool CapNhatSoLuongGioHang(string maKH, string maSP, int soLuongMoi)
        {
            string sql = "UPDATE GIOHANG SET SOLUONG = @SoLuong WHERE MAKH = @MaKH AND MASP = @MaSP";
            int kq = data.Data.Execute(sql,
                new SqlParameter("@MaKH", maKH),
                new SqlParameter("@MaSP", maSP),
                new SqlParameter("@SoLuong", soLuongMoi));
            return kq > 0;
        }
    }
}