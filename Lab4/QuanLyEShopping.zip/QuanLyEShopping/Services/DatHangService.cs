﻿using System.Data;
using System.Data.SqlClient;

namespace QuanLyEShopping.Services
{
    public class DatHangService
    {
        public DataTable LayDanhSachLoaiPhiếu()
        {
            string sql = "SELECT * FROM PHIEUDATHANG";
            return data.Data.Query(sql);
        }

        public decimal TinhPhiGiaoHang(string maLoaiPhieu, decimal tongTriGia)
        {
            decimal phiGiao = 0;
            // Chính sách ưu đãi vận chuyển theo đặc tả UC06[cite: 3, 4, 5]
            if (maLoaiPhieu == "CPN" && tongTriGia >= 1000000)
            {
                phiGiao = 0; // Miễn phí chuyển phát nhanh từ 1.000.000đ[cite: 3, 5]
            }
            else if (maLoaiPhieu == "CPNNGAY" && tongTriGia >= 5000000)
            {
                phiGiao = 0; // Miễn phí chuyển phát nhanh trong ngày từ 5.000.000đ[cite: 4, 5]
            }
            else
            {
                string sql = "SELECT DONGIPHIVANCHUYEN FROM PHIEUDATHANG WHERE MALOAIPHIEU = @MaLoai";
                var dt = data.Data.Query(sql, new SqlParameter("@MaLoai", maLoaiPhieu));
                if (dt.Rows.Count > 0)
                {
                    phiGiao = decimal.Parse(dt.Rows[0]["DONGIPHIVANCHUYEN"].ToString());
                }
            }
            return phiGiao;
        }

        public bool TaoDonHangVaChiTiet(string soDDH, string maKH, string maLoaiPhieu, decimal tongTriGia, decimal phiGiao,
                                        string tenNhan, string diaChiNhan, string dtNhan, DataTable dtGioHang)
        {
            using (var cn = data.Data.OpenConnection())
            using (var transaction = cn.BeginTransaction())
            {
                try
                {
                    // 1. Lưu vào bảng DONHANG
                    string sqlDH = @"INSERT INTO DONHANG (SODDH, NGAYDATHANG, TONGTRIGIA, PHIGIAOHANG, TENNGUOINHAN, DIACHINHAN, DIENTHOAINHAN, MAKH, MALOAIPHIEU)
                                     VALUES (@SoDDH, GETDATE(), @TongTriGia, @PhiGiao, @TenNhan, @DiaChiNhan, @DTNhan, @MaKH, @MaLoai)";
                    using (var cmdDH = new SqlCommand(sqlDH, cn, transaction))
                    {
                        cmdDH.Parameters.AddWithValue("@SoDDH", soDDH);
                        cmdDH.Parameters.AddWithValue("@TongTriGia", tongTriGia);
                        cmdDH.Parameters.AddWithValue("@PhiGiao", phiGiao);
                        cmdDH.Parameters.AddWithValue("@TenNhan", tenNhan);
                        cmdDH.Parameters.AddWithValue("@DiaChiNhan", diaChiNhan);
                        cmdDH.Parameters.AddWithValue("@DTNhan", dtNhan);
                        cmdDH.Parameters.AddWithValue("@MaKH", maKH);
                        cmdDH.Parameters.AddWithValue("@MaLoai", maLoaiPhieu);
                        cmdDH.ExecuteNonQuery();
                    }

                    // 2. Lưu chi tiết vào CHITIETDONHANG và xóa giỏ hàng
                    foreach (DataRow row in dtGioHang.Rows)
                    {
                        string sqlCT = "INSERT INTO CHITIETDONHANG (SODDH, MASP, SOLUONG, DONGIA) VALUES (@SoDDH, @MaSP, @SoLuong, @DonGia)";
                        using (var cmdCT = new SqlCommand(sqlCT, cn, transaction))
                        {
                            cmdCT.Parameters.AddWithValue("@SoDDH", soDDH);
                            cmdCT.Parameters.AddWithValue("@MaSP", row["MASP"].ToString());
                            cmdCT.Parameters.AddWithValue("@SoLuong", int.Parse(row["SOLUONG"].ToString()));
                            cmdCT.Parameters.AddWithValue("@DonGia", decimal.Parse(row["DONGIA"].ToString()));
                            cmdCT.ExecuteNonQuery();
                        }
                    }

                    // Xóa giỏ hàng sau khi đặt thành công
                    string sqlClearGH = "DELETE FROM GIOHANG WHERE MAKH = @MaKH";
                    using (var cmdClear = new SqlCommand(sqlClearGH, cn, transaction))
                    {
                        cmdClear.Parameters.AddWithValue("@MaKH", maKH);
                        cmdClear.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return true;
                }
                catch
                {
                    transaction.Rollback();
                    return false;
                }
            }
        }
    }
}