﻿using System.Data.SqlClient;

namespace QuanLyEShopping.Services
{
    public class ThanhToanService
    {
        public bool LuuThongTinThanhToan(string maGiaoDich, string soDDH, string loaiThe, string soHieuThe, string ngayHetHan, string hoTenChuThe, string csv, string trangThai)
        {
            string sql = @"INSERT INTO THANHTOANTHE (MAGIAODICH, SODDH, LOAITHE, SOHIEUTHE, NGAYHETHAN, HOTENCHUTHE, MASOANNINHCSV, TRANGTHAITHANHTOAN)
                           VALUES (@MaGD, @SoDDH, @LoaiThe, @SoHieuThe, @NgayHetHan, @HoTenChuThe, @CSV, @TrangThai)";
            int kq = data.Data.Execute(sql,
                new SqlParameter("@MaGD", maGiaoDich),
                new SqlParameter("@SoDDH", soDDH),
                new SqlParameter("@LoaiThe", loaiThe),
                new SqlParameter("@SoHieuThe", soHieuThe),
                new SqlParameter("@NgayHetHan", ngayHetHan),
                new SqlParameter("@HoTenChuThe", hoTenChuThe),
                new SqlParameter("@CSV", csv),
                new SqlParameter("@TrangThai", trangThai));
            return kq > 0;
        }
    }
}