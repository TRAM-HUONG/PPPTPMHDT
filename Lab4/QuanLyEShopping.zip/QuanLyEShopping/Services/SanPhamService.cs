﻿using System.Data;
using System.Data.SqlClient;

namespace QuanLyEShopping.Services
{
    public class SanPhamService
    {
        public DataTable LayDanhSachNhomSanPham()
        {
            string sql = "SELECT * FROM NHOMSANPHAM";
            return data.Data.Query(sql);
        }

        public DataTable LaySanPhamTheoNhom(string maNhom)
        {
            string sql = "SELECT * FROM SANPHAM WHERE MANHOM = @MaNhom";
            return data.Data.Query(sql, new SqlParameter("@MaNhom", maNhom));
        }

        public DataTable LayChiTietSanPham(string maSP)
        {
            string sql = "SELECT * FROM SANPHAM WHERE MASP = @MaSP";
            return data.Data.Query(sql, new SqlParameter("@MaSP", maSP));
        }
    }
}