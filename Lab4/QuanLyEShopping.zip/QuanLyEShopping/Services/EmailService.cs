﻿using System;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;

namespace QuanLyEShopping.Services
{
    public class EmailService
    {
        // Theo đặc tả UC08: Gửi email xác nhận thành công, tuyệt đối không bao gồm thông tin thẻ tín dụng vì lý do an ninh
        public bool GuiEmailXacNhanDonHang(string emailNhan, string soDDH, string chiTietDonHang, decimal tongTien)
        {
            try
            {
                // Đoạn mã mẫu cấu hình SmtpClient (có thể cấu hình qua App.config thực tế)
                /*
                MailMessage mail = new MailMessage();
                mail.From = new MailAddress("shop_eshopping@gmail.com");
                mail.To.Add(emailNhan);
                mail.Subject = $"[e-SHOPPING] Xác nhận đơn hàng thành công #{soDDH}";
                mail.Body = $"Cảm ơn bạn đã mua hàng tại e-SHOPPING!\n\nThông tin đơn hàng #{soDDH}:\n{chiTietDonHang}\nTổng thanh toán: {tongTien:N0} đ\n\n(Lưu ý: Thông tin thẻ thanh toán đã được ẩn vì lý do an ninh).";
                
                SmtpClient smtp = new SmtpClient("smtp.gmail.com", 587);
                smtp.Credentials = new NetworkCredential("email_cua_ban@gmail.com", "mat_khau_ung_dung");
                smtp.EnableSsl = true;
                smtp.Send(mail);
                */

                // Giả lập gửi email thành công trong prototype
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
    }
}