﻿using System;
using System.Windows.Forms;
using QuanLyEShopping.forms; // Đảm bảo đúng namespace chứa các form

namespace QuanLyEShopping
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Khởi chạy từ Form Đăng Nhập để hệ thống chuyển hướng chuẩn xác
            Application.Run(new FrmDangNhap());
        }
    }
}