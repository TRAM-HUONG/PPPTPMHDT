﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyThuVien.Services;

namespace QuanLyThuVien.Forms
{
    public partial class FrmDanhMuc : Form
    {
        private readonly DanhMucService service = new DanhMucService();

        public FrmDanhMuc()
        {
            InitializeComponent();
            RegisterEvents();
            LoadDataInit();
        }

        private void RegisterEvents()
        {
            // Sự kiện Tab Nhân Viên
            btnNVThem.Click += (s, e) => ShowResult(service.LuuNhanVien(new NhanVien { MaNhanVien = txtNVMa.Text.Trim(), Ho = txtNVHo.Text.Trim(), Ten = txtNVTen.Text.Trim(), Phai = Convert.ToString(cboNVPhai.SelectedItem), NgaySinh = dtNVNgaySinh.Value, ChucVu = txtNVChucVu.Text.Trim(), SoDienThoai = txtNVSDT.Text.Trim() }, false));
            btnNVCapNhat.Click += (s, e) => ShowResult(service.LuuNhanVien(new NhanVien { MaNhanVien = txtNVMa.Text.Trim(), Ho = txtNVHo.Text.Trim(), Ten = txtNVTen.Text.Trim(), Phai = Convert.ToString(cboNVPhai.SelectedItem), NgaySinh = dtNVNgaySinh.Value, ChucVu = txtNVChucVu.Text.Trim(), SoDienThoai = txtNVSDT.Text.Trim() }, true));
            btnNVXoa.Click += (s, e) => { if (XacNhanXoa()) ShowResult(service.Xoa("NhanVien", "MaNhanVien", txtNVMa.Text.Trim())); };
            btnNVMoi.Click += (s, e) => LamMoiNV();
            dgvNV.SelectionChanged += (s, e) =>
            {
                if (dgvNV.CurrentRow?.DataBoundItem is DataRowView r)
                {
                    txtNVMa.Text = Convert.ToString(r["MaNhanVien"]);
                    txtNVHo.Text = Convert.ToString(r["Ho"]);
                    txtNVTen.Text = Convert.ToString(r["Ten"]);
                    cboNVPhai.SelectedItem = Convert.ToString(r["Phai"]);
                    dtNVNgaySinh.Value = Convert.ToDateTime(r["NgaySinh"]);
                    txtNVChucVu.Text = Convert.ToString(r["ChucVu"]);
                    txtNVSDT.Text = Convert.ToString(r["SoDienThoai"]);
                    txtNVMa.ReadOnly = true;
                    btnNVThem.Enabled = false;
                    btnNVCapNhat.Enabled = true;
                    btnNVXoa.Enabled = true;
                }
            };

            // Sự kiện Tab Thể Loại
            btnTLThem.Click += (s, e) => ShowResult(service.LuuTheLoai(txtTLMa.Text, txtTLTen.Text, false));
            btnTLCapNhat.Click += (s, e) => ShowResult(service.LuuTheLoai(txtTLMa.Text, txtTLTen.Text, true));
            btnTLXoa.Click += (s, e) => { if (XacNhanXoa()) ShowResult(service.Xoa("TheLoai", "MaTheLoai", txtTLMa.Text.Trim())); };
            dgvTL.SelectionChanged += (s, e) =>
            {
                if (dgvTL.CurrentRow?.DataBoundItem is DataRowView r)
                {
                    txtTLMa.Text = Convert.ToString(r["MaTheLoai"]);
                    txtTLTen.Text = Convert.ToString(r["TenTheLoai"]);
                    txtTLMa.ReadOnly = true;
                    btnTLThem.Enabled = false;
                    btnTLCapNhat.Enabled = true;
                    btnTLXoa.Enabled = true;
                }
            };

            // Sự kiện Tab Nhà Xuất Bản
            btnNXBThem.Click += (s, e) => ShowResult(service.LuuNhaXuatBan(txtNXBMa.Text, txtNXBDiaChi.Text, txtNXBSDT.Text, false));
            btnNXBCapNhat.Click += (s, e) => ShowResult(service.LuuNhaXuatBan(txtNXBMa.Text, txtNXBDiaChi.Text, txtNXBSDT.Text, true));
            btnNXBXoa.Click += (s, e) => { if (XacNhanXoa()) ShowResult(service.Xoa("NhaXuatBan", "MaNhaXuatBan", txtNXBMa.Text.Trim())); };
            dgvNXB.SelectionChanged += (s, e) =>
            {
                if (dgvNXB.CurrentRow?.DataBoundItem is DataRowView r)
                {
                    txtNXBMa.Text = Convert.ToString(r["MaNhaXuatBan"]);
                    txtNXBDiaChi.Text = Convert.ToString(r["DiaChi"]);
                    txtNXBSDT.Text = Convert.ToString(r["SoDienThoai"]);
                    txtNXBMa.ReadOnly = true;
                    btnNXBThem.Enabled = false;
                    btnNXBCapNhat.Enabled = true;
                    btnNXBXoa.Enabled = true;
                }
            };

            btnDong.Click += (s, e) => Close();
        }

        private void LoadDataInit()
        {
            TaiTatCa();
            LamMoiNV();
            LamMoiTL();
            LamMoiNXB();
        }

        private void TaiTatCa()
        {
            dgvNV.DataSource = service.LayNhanVien();
            dgvNV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dgvTL.DataSource = service.LayTheLoai();
            dgvTL.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

            dgvNXB.DataSource = service.LayNhaXuatBan();
            dgvNXB.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void ShowResult(KetQuaXuLy kq)
        {
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thông báo" : "Lỗi", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
            if (kq.ThanhCong) TaiTatCa();
        }

        private void LamMoiNV()
        {
            txtNVMa.Clear();
            txtNVHo.Clear();
            txtNVTen.Clear();
            txtNVChucVu.Clear();
            txtNVSDT.Clear();
            dtNVNgaySinh.Value = DateTime.Today.AddYears(-25);
            txtNVMa.ReadOnly = false;
            btnNVThem.Enabled = true;
            btnNVCapNhat.Enabled = false;
            btnNVXoa.Enabled = false;
        }

        private void LamMoiTL()
        {
            txtTLMa.Clear();
            txtTLTen.Clear();
            txtTLMa.ReadOnly = false;
            btnTLThem.Enabled = true;
            btnTLCapNhat.Enabled = false;
            btnTLXoa.Enabled = false;
        }

        private void LamMoiNXB()
        {
            txtNXBMa.Clear();
            txtNXBDiaChi.Clear();
            txtNXBSDT.Clear();
            txtNXBMa.ReadOnly = false;
            btnNXBThem.Enabled = true;
            btnNXBCapNhat.Enabled = false;
            btnNXBXoa.Enabled = false;
        }

        private bool XacNhanXoa() => MessageBox.Show("Xóa dữ liệu đang chọn?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;
    }
}