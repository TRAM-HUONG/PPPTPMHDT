﻿namespace QuanLyThuVien.Forms
{
    partial class FrmDocGia
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtMa = new System.Windows.Forms.TextBox();
            this.txtHo = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.txtAnh = new System.Windows.Forms.TextBox();
            this.dtNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.dtNgayCap = new System.Windows.Forms.DateTimePicker();
            this.dtHan = new System.Windows.Forms.DateTimePicker();
            this.cboPhai = new System.Windows.Forms.ComboBox();
            this.chkLePhi = new System.Windows.Forms.CheckBox();
            this.dgvDocGia = new System.Windows.Forms.DataGridView();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnCapThe = new System.Windows.Forms.Button();
            this.btnGiaHan = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).BeginInit();
            this.SuspendLayout();

            // Các Label tĩnh
            System.Windows.Forms.Label lblMa = new System.Windows.Forms.Label { Text = "Mã ĐG:", Left = 20, Top = 25, Width = 70 };
            System.Windows.Forms.Label lblHo = new System.Windows.Forms.Label { Text = "Họ:", Left = 240, Top = 25, Width = 40 };
            System.Windows.Forms.Label lblTen = new System.Windows.Forms.Label { Text = "Tên:", Left = 460, Top = 25, Width = 40 };
            System.Windows.Forms.Label lblNgaySinh = new System.Windows.Forms.Label { Text = "Ngày sinh:", Left = 630, Top = 25, Width = 80 };
            System.Windows.Forms.Label lblPhai = new System.Windows.Forms.Label { Text = "Phái:", Left = 870, Top = 25, Width = 40 };
            System.Windows.Forms.Label lblSDT = new System.Windows.Forms.Label { Text = "SĐT:", Left = 20, Top = 65, Width = 70 };
            System.Windows.Forms.Label lblDiaChi = new System.Windows.Forms.Label { Text = "Địa chỉ:", Left = 270, Top = 65, Width = 60 };
            System.Windows.Forms.Label lblEmail = new System.Windows.Forms.Label { Text = "Email:", Left = 630, Top = 65, Width = 80 };
            System.Windows.Forms.Label lblAnh = new System.Windows.Forms.Label { Text = "Ảnh 3x4:", Left = 20, Top = 105, Width = 70 };
            System.Windows.Forms.Label lblNgayCap = new System.Windows.Forms.Label { Text = "Ngày cấp:", Left = 20, Top = 145, Width = 70 };
            System.Windows.Forms.Label lblHan = new System.Windows.Forms.Label { Text = "Hạn thẻ:", Left = 260, Top = 145, Width = 70 };

            // Controls nhập liệu
            this.txtMa.Left = 100; this.txtMa.Top = 20; this.txtMa.Width = 120;
            this.txtHo.Left = 290; this.txtHo.Top = 20; this.txtHo.Width = 150;
            this.txtTen.Left = 510; this.txtTen.Top = 20; this.txtTen.Width = 100;
            this.dtNgaySinh.Left = 720; this.dtNgaySinh.Top = 20; this.dtNgaySinh.Width = 130; this.dtNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.cboPhai.Left = 920; this.cboPhai.Top = 20; this.cboPhai.Width = 100;
            this.cboPhai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboPhai.Items.AddRange(new object[] { "Nam", "Nữ", "Khác" });
            this.cboPhai.SelectedIndex = 0;

            this.txtSDT.Left = 100; this.txtSDT.Top = 60; this.txtSDT.Width = 150;
            this.txtDiaChi.Left = 340; this.txtDiaChi.Top = 60; this.txtDiaChi.Width = 270;
            this.txtEmail.Left = 720; this.txtEmail.Top = 60; this.txtEmail.Width = 300;
            this.txtAnh.Left = 100; this.txtAnh.Top = 100; this.txtAnh.Width = 510;

            this.dtNgayCap.Left = 100; this.dtNgayCap.Top = 140; this.dtNgayCap.Width = 140; this.dtNgayCap.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtHan.Left = 340; this.dtHan.Top = 140; this.dtHan.Width = 140; this.dtHan.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.chkLePhi.Text = "Đã đóng lệ phí"; this.chkLePhi.Left = 500; this.chkLePhi.Top = 142; this.chkLePhi.Width = 120; this.chkLePhi.Checked = true;

            // Nút bấm
            this.btnThem.Text = "Thêm ĐG"; this.btnThem.Left = 650; this.btnThem.Top = 138; this.btnThem.Width = 90; this.btnThem.Height = 32;
            this.btnCapNhat.Text = "Sửa ĐG"; this.btnCapNhat.Left = 750; this.btnCapNhat.Top = 138; this.btnCapNhat.Width = 90; this.btnCapNhat.Height = 32;
            this.btnCapThe.Text = "Cấp thẻ"; this.btnCapThe.Left = 850; this.btnCapThe.Top = 138; this.btnCapThe.Width = 90; this.btnCapThe.Height = 32;
            this.btnGiaHan.Text = "Gia hạn"; this.btnGiaHan.Left = 950; this.btnGiaHan.Top = 138; this.btnGiaHan.Width = 90; this.btnGiaHan.Height = 32;
            this.btnLamMoi.Text = "Làm mới"; this.btnLamMoi.Left = 1050; this.btnLamMoi.Top = 138; this.btnLamMoi.Width = 90; this.btnLamMoi.Height = 32;

            this.btnDong.Text = "Đóng"; this.btnDong.Left = 1060; this.btnDong.Top = 735; this.btnDong.Width = 100; this.btnDong.Height = 35;
            this.btnDong.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;

            // DataGridView
            this.dgvDocGia.Left = 20; this.dgvDocGia.Top = 190; this.dgvDocGia.Width = 1140; this.dgvDocGia.Height = 530;
            this.dgvDocGia.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.dgvDocGia.ReadOnly = true;
            this.dgvDocGia.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDocGia.MultiSelect = false;

            // Form
            this.ClientSize = new System.Drawing.Size(1190, 790);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Độc giả và thẻ";

            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblMa, this.txtMa, lblHo, this.txtHo, lblTen, this.txtTen, lblNgaySinh, this.dtNgaySinh, lblPhai, this.cboPhai,
                lblSDT, this.txtSDT, lblDiaChi, this.txtDiaChi, lblEmail, this.txtEmail, lblAnh, this.txtAnh,
                lblNgayCap, this.dtNgayCap, lblHan, this.dtHan, this.chkLePhi,
                this.btnThem, this.btnCapNhat, this.btnCapThe, this.btnGiaHan, this.btnLamMoi,
                this.dgvDocGia, this.btnDong
            });

            ((System.ComponentModel.ISupportInitialize)(this.dgvDocGia)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtMa, txtHo, txtTen, txtSDT, txtDiaChi, txtEmail, txtAnh;
        private System.Windows.Forms.DateTimePicker dtNgaySinh, dtNgayCap, dtHan;
        private System.Windows.Forms.ComboBox cboPhai;
        private System.Windows.Forms.CheckBox chkLePhi;
        private System.Windows.Forms.DataGridView dgvDocGia;
        private System.Windows.Forms.Button btnThem, btnCapNhat, btnCapThe, btnGiaHan, btnLamMoi, btnDong;
    }
}