﻿namespace QuanLyThuVien.Forms
{
    partial class FrmMuonTra
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabMuon = new System.Windows.Forms.TabPage();
            this.btnLapPhieu = new System.Windows.Forms.Button();
            this.btnBoSach = new System.Windows.Forms.Button();
            this.btnThemSach = new System.Windows.Forms.Button();
            this.lblTrangThai = new System.Windows.Forms.Label();
            this.btnKiemTra = new System.Windows.Forms.Button();
            this.dtHenTra = new System.Windows.Forms.DateTimePicker();
            this.dtNgayMuon = new System.Windows.Forms.DateTimePicker();
            this.cboNhanVienMuon = new System.Windows.Forms.ComboBox();
            this.cboDocGia = new System.Windows.Forms.ComboBox();
            this.dgvSachChon = new System.Windows.Forms.DataGridView();
            this.dgvSachCon = new System.Windows.Forms.DataGridView();
            this.tabTra = new System.Windows.Forms.TabPage();
            this.btnTraSach = new System.Windows.Forms.Button();
            this.numPhiPhat = new System.Windows.Forms.NumericUpDown();
            this.cboTinhTrang = new System.Windows.Forms.ComboBox();
            this.dtNgayTra = new System.Windows.Forms.DateTimePicker();
            this.cboNhanVienTra = new System.Windows.Forms.ComboBox();
            this.dgvDangMuon = new System.Windows.Forms.DataGridView();
            this.btnTaiSachMuon = new System.Windows.Forms.Button();
            this.cboDocGiaTra = new System.Windows.Forms.ComboBox();
            this.btnDong = new System.Windows.Forms.Button();

            // Label controls
            System.Windows.Forms.Label lblDocGiaMuon = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblNhanVienMuon = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblNgayMuon = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblHenTra = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblSachKho = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblSachChon = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblDocGiaTra = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblSachDangMuon = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblNhanVienTra = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblNgayTra = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblTinhTrang = new System.Windows.Forms.Label();
            System.Windows.Forms.Label lblPhiPhat = new System.Windows.Forms.Label();

            this.tabControl1.SuspendLayout();
            this.tabMuon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSachChon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSachCon)).BeginInit();
            this.tabTra.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPhiPhat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDangMuon)).BeginInit();
            this.SuspendLayout();

            // tabControl1
            this.tabControl1.Controls.Add(this.tabMuon);
            this.tabControl1.Controls.Add(this.tabTra);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1060, 535);
            this.tabControl1.TabIndex = 0;

            // tabMuon
            this.tabMuon.Controls.Add(lblSachChon);
            this.tabMuon.Controls.Add(lblSachKho);
            this.tabMuon.Controls.Add(lblHenTra);
            this.tabMuon.Controls.Add(lblNgayMuon);
            this.tabMuon.Controls.Add(lblNhanVienMuon);
            this.tabMuon.Controls.Add(lblDocGiaMuon);
            this.tabMuon.Controls.Add(this.btnLapPhieu);
            this.tabMuon.Controls.Add(this.btnBoSach);
            this.tabMuon.Controls.Add(this.btnThemSach);
            this.tabMuon.Controls.Add(this.lblTrangThai);
            this.tabMuon.Controls.Add(this.btnKiemTra);
            this.tabMuon.Controls.Add(this.dtHenTra);
            this.tabMuon.Controls.Add(this.dtNgayMuon);
            this.tabMuon.Controls.Add(this.cboNhanVienMuon);
            this.tabMuon.Controls.Add(this.cboDocGia);
            this.tabMuon.Controls.Add(this.dgvSachChon);
            this.tabMuon.Controls.Add(this.dgvSachCon);
            this.tabMuon.Location = new System.Drawing.Point(4, 25);
            this.tabMuon.Name = "tabMuon";
            this.tabMuon.Padding = new System.Windows.Forms.Padding(3);
            this.tabMuon.Size = new System.Drawing.Size(1052, 506);
            this.tabMuon.TabIndex = 0;
            this.tabMuon.Text = "Mượn sách";
            this.tabMuon.UseVisualStyleBackColor = true;

            // Labels Tab Muon
            lblDocGiaMuon.AutoSize = true;
            lblDocGiaMuon.Location = new System.Drawing.Point(15, 20);
            lblDocGiaMuon.Text = "Độc giả:";

            lblNhanVienMuon.AutoSize = true;
            lblNhanVienMuon.Location = new System.Drawing.Point(15, 58);
            lblNhanVienMuon.Text = "Nhân viên:";

            lblNgayMuon.AutoSize = true;
            lblNgayMuon.Location = new System.Drawing.Point(245, 58);
            lblNgayMuon.Text = "Ngày mượn:";

            lblHenTra.AutoSize = true;
            lblHenTra.Location = new System.Drawing.Point(465, 58);
            lblHenTra.Text = "Ngày hẹn trả:";

            lblSachKho.AutoSize = true;
            lblSachKho.Location = new System.Drawing.Point(15, 95);
            lblSachKho.Text = "Sách còn trong kho:";

            lblSachChon.AutoSize = true;
            lblSachChon.Location = new System.Drawing.Point(565, 95);
            lblSachChon.Text = "Sách chọn (tối đa 3):";

            // Control Tab Muon
            this.cboDocGia.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDocGia.Location = new System.Drawing.Point(90, 16);
            this.cboDocGia.Size = new System.Drawing.Size(230, 24);

            this.btnKiemTra.Location = new System.Drawing.Point(330, 14);
            this.btnKiemTra.Size = new System.Drawing.Size(100, 28);
            this.btnKiemTra.Text = "Kiểm tra ĐK";
            this.btnKiemTra.Click += new System.EventHandler(this.btnKiemTra_Click);

            this.lblTrangThai.AutoSize = true;
            this.lblTrangThai.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblTrangThai.ForeColor = System.Drawing.Color.DarkGreen;
            this.lblTrangThai.Location = new System.Drawing.Point(440, 20);

            this.cboNhanVienMuon.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNhanVienMuon.Location = new System.Drawing.Point(90, 54);
            this.cboNhanVienMuon.Size = new System.Drawing.Size(140, 24);

            this.dtNgayMuon.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgayMuon.Location = new System.Drawing.Point(330, 54);
            this.dtNgayMuon.Size = new System.Drawing.Size(120, 22);

            this.dtHenTra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtHenTra.Location = new System.Drawing.Point(565, 54);
            this.dtHenTra.Size = new System.Drawing.Size(120, 22);

            this.dgvSachCon.AllowUserToAddRows = false;
            this.dgvSachCon.ReadOnly = true;
            this.dgvSachCon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSachCon.Location = new System.Drawing.Point(15, 120);
            this.dgvSachCon.Size = new System.Drawing.Size(460, 360);

            this.btnThemSach.Location = new System.Drawing.Point(485, 180);
            this.btnThemSach.Size = new System.Drawing.Size(70, 35);
            this.btnThemSach.Text = "Thêm >>";
            this.btnThemSach.Click += new System.EventHandler(this.btnThemSach_Click);

            this.btnBoSach.Location = new System.Drawing.Point(485, 225);
            this.btnBoSach.Size = new System.Drawing.Size(70, 35);
            this.btnBoSach.Text = "<< Bỏ";
            this.btnBoSach.Click += new System.EventHandler(this.btnBoSach_Click);

            this.dgvSachChon.AllowUserToAddRows = false;
            this.dgvSachChon.ReadOnly = true;
            this.dgvSachChon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSachChon.Location = new System.Drawing.Point(565, 120);
            this.dgvSachChon.Size = new System.Drawing.Size(470, 290);

            // Nút Lập phiếu mượn được đặt đúng chỗ bên dưới bảng
            this.btnLapPhieu.BackColor = System.Drawing.Color.LightSkyBlue;
            this.btnLapPhieu.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLapPhieu.Location = new System.Drawing.Point(885, 425);
            this.btnLapPhieu.Size = new System.Drawing.Size(150, 42);
            this.btnLapPhieu.Text = "Lập phiếu mượn";
            this.btnLapPhieu.UseVisualStyleBackColor = false;
            this.btnLapPhieu.Click += new System.EventHandler(this.btnLapPhieu_Click);

            // tabTra
            this.tabTra.Controls.Add(lblPhiPhat);
            this.tabTra.Controls.Add(lblTinhTrang);
            this.tabTra.Controls.Add(lblNgayTra);
            this.tabTra.Controls.Add(lblNhanVienTra);
            this.tabTra.Controls.Add(lblSachDangMuon);
            this.tabTra.Controls.Add(lblDocGiaTra);
            this.tabTra.Controls.Add(this.btnTraSach);
            this.tabTra.Controls.Add(this.numPhiPhat);
            this.tabTra.Controls.Add(this.cboTinhTrang);
            this.tabTra.Controls.Add(this.dtNgayTra);
            this.tabTra.Controls.Add(this.cboNhanVienTra);
            this.tabTra.Controls.Add(this.dgvDangMuon);
            this.tabTra.Controls.Add(this.btnTaiSachMuon);
            this.tabTra.Controls.Add(this.cboDocGiaTra);
            this.tabTra.Location = new System.Drawing.Point(4, 25);
            this.tabTra.Name = "tabTra";
            this.tabTra.Padding = new System.Windows.Forms.Padding(3);
            this.tabTra.Size = new System.Drawing.Size(1052, 506);
            this.tabTra.TabIndex = 1;
            this.tabTra.Text = "Trả sách";
            this.tabTra.UseVisualStyleBackColor = true;

            // Labels Tab Tra
            lblDocGiaTra.AutoSize = true;
            lblDocGiaTra.Location = new System.Drawing.Point(15, 20);
            lblDocGiaTra.Text = "Độc giả trả:";

            lblSachDangMuon.AutoSize = true;
            lblSachDangMuon.Location = new System.Drawing.Point(15, 58);
            lblSachDangMuon.Text = "Sách chưa trả:";

            lblNhanVienTra.AutoSize = true;
            lblNhanVienTra.Location = new System.Drawing.Point(680, 90);
            lblNhanVienTra.Text = "Nhân viên nhận:";

            lblNgayTra.AutoSize = true;
            lblNgayTra.Location = new System.Drawing.Point(680, 130);
            lblNgayTra.Text = "Ngày trả:";

            lblTinhTrang.AutoSize = true;
            lblTinhTrang.Location = new System.Drawing.Point(680, 170);
            lblTinhTrang.Text = "Tình trạng:";

            lblPhiPhat.AutoSize = true;
            lblPhiPhat.Location = new System.Drawing.Point(680, 210);
            lblPhiPhat.Text = "Phí phạt:";

            // Control Tab Tra
            this.cboDocGiaTra.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboDocGiaTra.Location = new System.Drawing.Point(100, 16);
            this.cboDocGiaTra.Size = new System.Drawing.Size(230, 24);
            this.cboDocGiaTra.SelectedIndexChanged += new System.EventHandler(this.cboDocGiaTra_SelectedIndexChanged);

            this.btnTaiSachMuon.Location = new System.Drawing.Point(340, 14);
            this.btnTaiSachMuon.Size = new System.Drawing.Size(150, 28);
            this.btnTaiSachMuon.Text = "Tải sách đang mượn";
            this.btnTaiSachMuon.Click += new System.EventHandler(this.btnTaiSachMuon_Click);

            this.dgvDangMuon.AllowUserToAddRows = false;
            this.dgvDangMuon.ReadOnly = true;
            this.dgvDangMuon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvDangMuon.Location = new System.Drawing.Point(15, 85);
            this.dgvDangMuon.Size = new System.Drawing.Size(640, 395);

            this.cboNhanVienTra.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNhanVienTra.Location = new System.Drawing.Point(790, 85);
            this.cboNhanVienTra.Size = new System.Drawing.Size(160, 24);

            this.dtNgayTra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtNgayTra.Location = new System.Drawing.Point(790, 125);
            this.dtNgayTra.Size = new System.Drawing.Size(160, 22);

            this.cboTinhTrang.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTinhTrang.Location = new System.Drawing.Point(790, 165);
            this.cboTinhTrang.Size = new System.Drawing.Size(160, 24);

            this.numPhiPhat.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });
            this.numPhiPhat.Location = new System.Drawing.Point(790, 205);
            this.numPhiPhat.Size = new System.Drawing.Size(160, 22);

            this.btnTraSach.Location = new System.Drawing.Point(790, 255);
            this.btnTraSach.Size = new System.Drawing.Size(160, 38);
            this.btnTraSach.Text = "Xác nhận trả sách";
            this.btnTraSach.Click += new System.EventHandler(this.btnTraSach_Click);

            // btnDong
            this.btnDong.Location = new System.Drawing.Point(972, 555);
            this.btnDong.Size = new System.Drawing.Size(100, 32);
            this.btnDong.Text = "Đóng";
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // FrmMuonTra Form
            this.ClientSize = new System.Drawing.Size(1084, 596);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabControl1);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "FrmMuonTra";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Mượn - Trả sách";
            this.Load += new System.EventHandler(this.FrmMuonTra_Load);

            this.tabControl1.ResumeLayout(false);
            this.tabMuon.ResumeLayout(false);
            this.tabMuon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSachChon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSachCon)).EndInit();
            this.tabTra.ResumeLayout(false);
            this.tabTra.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numPhiPhat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDangMuon)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabMuon;
        private System.Windows.Forms.TabPage tabTra;
        private System.Windows.Forms.DataGridView dgvSachCon;
        private System.Windows.Forms.DataGridView dgvSachChon;
        private System.Windows.Forms.ComboBox cboDocGia;
        private System.Windows.Forms.ComboBox cboNhanVienMuon;
        private System.Windows.Forms.DateTimePicker dtNgayMuon;
        private System.Windows.Forms.DateTimePicker dtHenTra;
        private System.Windows.Forms.Button btnKiemTra;
        private System.Windows.Forms.Label lblTrangThai;
        private System.Windows.Forms.Button btnThemSach;
        private System.Windows.Forms.Button btnBoSach;
        private System.Windows.Forms.Button btnLapPhieu;
        private System.Windows.Forms.ComboBox cboDocGiaTra;
        private System.Windows.Forms.Button btnTaiSachMuon;
        private System.Windows.Forms.DataGridView dgvDangMuon;
        private System.Windows.Forms.ComboBox cboNhanVienTra;
        private System.Windows.Forms.DateTimePicker dtNgayTra;
        private System.Windows.Forms.ComboBox cboTinhTrang;
        private System.Windows.Forms.NumericUpDown numPhiPhat;
        private System.Windows.Forms.Button btnTraSach;
        private System.Windows.Forms.Button btnDong;
    }
}