﻿namespace QuanLyThuVien.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabs = new System.Windows.Forms.TabControl();
            this.tabNV = new System.Windows.Forms.TabPage();
            this.tabTL = new System.Windows.Forms.TabPage();
            this.tabNXB = new System.Windows.Forms.TabPage();

            // NV Controls
            this.txtNVMa = new System.Windows.Forms.TextBox();
            this.txtNVHo = new System.Windows.Forms.TextBox();
            this.txtNVTen = new System.Windows.Forms.TextBox();
            this.txtNVChucVu = new System.Windows.Forms.TextBox();
            this.txtNVSDT = new System.Windows.Forms.TextBox();
            this.cboNVPhai = new System.Windows.Forms.ComboBox();
            this.dtNVNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.dgvNV = new System.Windows.Forms.DataGridView();
            this.btnNVThem = new System.Windows.Forms.Button();
            this.btnNVCapNhat = new System.Windows.Forms.Button();
            this.btnNVXoa = new System.Windows.Forms.Button();
            this.btnNVMoi = new System.Windows.Forms.Button();

            // TL Controls
            this.txtTLMa = new System.Windows.Forms.TextBox();
            this.txtTLTen = new System.Windows.Forms.TextBox();
            this.dgvTL = new System.Windows.Forms.DataGridView();
            this.btnTLThem = new System.Windows.Forms.Button();
            this.btnTLCapNhat = new System.Windows.Forms.Button();
            this.btnTLXoa = new System.Windows.Forms.Button();

            // NXB Controls
            this.txtNXBMa = new System.Windows.Forms.TextBox();
            this.txtNXBDiaChi = new System.Windows.Forms.TextBox();
            this.txtNXBSDT = new System.Windows.Forms.TextBox();
            this.dgvNXB = new System.Windows.Forms.DataGridView();
            this.btnNXBThem = new System.Windows.Forms.Button();
            this.btnNXBCapNhat = new System.Windows.Forms.Button();
            this.btnNXBXoa = new System.Windows.Forms.Button();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabs.SuspendLayout();
            this.tabNV.SuspendLayout();
            this.tabTL.SuspendLayout();
            this.tabNXB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNXB)).BeginInit();
            this.SuspendLayout();

            // 
            // tabs
            // 
            this.tabs.Controls.Add(this.tabNV);
            this.tabs.Controls.Add(this.tabTL);
            this.tabs.Controls.Add(this.tabNXB);
            this.tabs.Location = new System.Drawing.Point(20, 20);
            this.tabs.Name = "tabs";
            this.tabs.SelectedIndex = 0;
            this.tabs.Size = new System.Drawing.Size(1020, 630);
            this.tabs.TabIndex = 0;
            this.tabs.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;

            // 
            // tabNV
            // 
            System.Windows.Forms.Label lblNVMa = new System.Windows.Forms.Label { Text = "Mã NV:", Location = new System.Drawing.Point(20, 25), Size = new System.Drawing.Size(80, 20) };
            System.Windows.Forms.Label lblNVHo = new System.Windows.Forms.Label { Text = "Họ:", Location = new System.Drawing.Point(20, 65), Size = new System.Drawing.Size(80, 20) };
            System.Windows.Forms.Label lblNVTen = new System.Windows.Forms.Label { Text = "Tên:", Location = new System.Drawing.Point(280, 65), Size = new System.Drawing.Size(60, 20) };
            System.Windows.Forms.Label lblNVPhai = new System.Windows.Forms.Label { Text = "Phái:", Location = new System.Drawing.Point(20, 105), Size = new System.Drawing.Size(80, 20) };
            System.Windows.Forms.Label lblNVNgaySinh = new System.Windows.Forms.Label { Text = "Ngày sinh:", Location = new System.Drawing.Point(280, 105), Size = new System.Drawing.Size(80, 20) };
            System.Windows.Forms.Label lblNVChucVu = new System.Windows.Forms.Label { Text = "Chức vụ:", Location = new System.Drawing.Point(20, 145), Size = new System.Drawing.Size(80, 20) };
            System.Windows.Forms.Label lblNVSDT = new System.Windows.Forms.Label { Text = "SĐT:", Location = new System.Drawing.Point(280, 145), Size = new System.Drawing.Size(60, 20) };

            this.txtNVMa.Location = new System.Drawing.Point(110, 20); this.txtNVMa.Size = new System.Drawing.Size(150, 23);
            this.txtNVHo.Location = new System.Drawing.Point(110, 60); this.txtNVHo.Size = new System.Drawing.Size(150, 23);
            this.txtNVTen.Location = new System.Drawing.Point(350, 60); this.txtNVTen.Size = new System.Drawing.Size(120, 23);
            this.cboNVPhai.Location = new System.Drawing.Point(110, 100); this.cboNVPhai.Size = new System.Drawing.Size(150, 23);
            this.cboNVPhai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboNVPhai.Items.AddRange(new object[] { "Nam", "Nữ", "Khác" });
            this.cboNVPhai.SelectedIndex = 0;
            this.dtNVNgaySinh.Location = new System.Drawing.Point(350, 100); this.dtNVNgaySinh.Size = new System.Drawing.Size(150, 23);
            this.dtNVNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.txtNVChucVu.Location = new System.Drawing.Point(110, 140); this.txtNVChucVu.Size = new System.Drawing.Size(150, 23);
            this.txtNVSDT.Location = new System.Drawing.Point(350, 140); this.txtNVSDT.Size = new System.Drawing.Size(150, 23);

            this.btnNVThem.Text = "Thêm"; this.btnNVThem.Location = new System.Drawing.Point(540, 20); this.btnNVThem.Size = new System.Drawing.Size(90, 35);
            this.btnNVCapNhat.Text = "Cập nhật"; this.btnNVCapNhat.Location = new System.Drawing.Point(640, 20); this.btnNVCapNhat.Size = new System.Drawing.Size(90, 35);
            this.btnNVXoa.Text = "Xóa"; this.btnNVXoa.Location = new System.Drawing.Point(740, 20); this.btnNVXoa.Size = new System.Drawing.Size(90, 35);
            this.btnNVMoi.Text = "Làm mới"; this.btnNVMoi.Location = new System.Drawing.Point(840, 20); this.btnNVMoi.Size = new System.Drawing.Size(90, 35);

            this.dgvNV.Location = new System.Drawing.Point(20, 190);
            this.dgvNV.Size = new System.Drawing.Size(970, 390);
            this.dgvNV.ReadOnly = true;
            this.dgvNV.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNV.MultiSelect = false;
            this.dgvNV.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;

            this.tabNV.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblNVMa, this.txtNVMa, lblNVHo, this.txtNVHo, lblNVTen, this.txtNVTen,
                lblNVPhai, this.cboNVPhai, lblNVNgaySinh, this.dtNVNgaySinh, lblNVChucVu, this.txtNVChucVu,
                lblNVSDT, this.txtNVSDT, this.btnNVThem, this.btnNVCapNhat, this.btnNVXoa, this.btnNVMoi, this.dgvNV
            });
            this.tabNV.Text = "Nhân viên";

            // 
            // tabTL
            // 
            System.Windows.Forms.Label lblTLMa = new System.Windows.Forms.Label { Text = "Mã thể loại:", Location = new System.Drawing.Point(20, 25), Size = new System.Drawing.Size(90, 20) };
            System.Windows.Forms.Label lblTLTen = new System.Windows.Forms.Label { Text = "Tên thể loại:", Location = new System.Drawing.Point(290, 25), Size = new System.Drawing.Size(90, 20) };

            this.txtTLMa.Location = new System.Drawing.Point(120, 20); this.txtTLMa.Size = new System.Drawing.Size(150, 23);
            this.txtTLTen.Location = new System.Drawing.Point(390, 20); this.txtTLTen.Size = new System.Drawing.Size(250, 23);

            this.btnTLThem.Text = "Thêm"; this.btnTLThem.Location = new System.Drawing.Point(660, 18); this.btnTLThem.Size = new System.Drawing.Size(90, 32);
            this.btnTLCapNhat.Text = "Cập nhật"; this.btnTLCapNhat.Location = new System.Drawing.Point(760, 18); this.btnTLCapNhat.Size = new System.Drawing.Size(90, 32);
            this.btnTLXoa.Text = "Xóa"; this.btnTLXoa.Location = new System.Drawing.Point(860, 18); this.btnTLXoa.Size = new System.Drawing.Size(90, 32);

            this.dgvTL.Location = new System.Drawing.Point(20, 70);
            this.dgvTL.Size = new System.Drawing.Size(970, 510);
            this.dgvTL.ReadOnly = true;
            this.dgvTL.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTL.MultiSelect = false;
            this.dgvTL.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;

            this.tabTL.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblTLMa, this.txtTLMa, lblTLTen, this.txtTLTen, this.btnTLThem, this.btnTLCapNhat, this.btnTLXoa, this.dgvTL
            });
            this.tabTL.Text = "Thể loại";

            // 
            // tabNXB
            // 
            System.Windows.Forms.Label lblNXBMa = new System.Windows.Forms.Label { Text = "Mã NXB:", Location = new System.Drawing.Point(20, 25), Size = new System.Drawing.Size(80, 20) };
            System.Windows.Forms.Label lblNXBDiaChi = new System.Windows.Forms.Label { Text = "Địa chỉ:", Location = new System.Drawing.Point(280, 25), Size = new System.Drawing.Size(70, 20) };
            System.Windows.Forms.Label lblNXBSDT = new System.Windows.Forms.Label { Text = "SĐT:", Location = new System.Drawing.Point(630, 25), Size = new System.Drawing.Size(50, 20) };

            this.txtNXBMa.Location = new System.Drawing.Point(110, 20); this.txtNXBMa.Size = new System.Drawing.Size(150, 23);
            this.txtNXBDiaChi.Location = new System.Drawing.Point(360, 20); this.txtNXBDiaChi.Size = new System.Drawing.Size(250, 23);
            this.txtNXBSDT.Location = new System.Drawing.Point(690, 20); this.txtNXBSDT.Size = new System.Drawing.Size(140, 23);

            this.btnNXBThem.Text = "Thêm"; this.btnNXBThem.Location = new System.Drawing.Point(20, 65); this.btnNXBThem.Size = new System.Drawing.Size(90, 32);
            this.btnNXBCapNhat.Text = "Cập nhật"; this.btnNXBCapNhat.Location = new System.Drawing.Point(120, 65); this.btnNXBCapNhat.Size = new System.Drawing.Size(90, 32);
            this.btnNXBXoa.Text = "Xóa"; this.btnNXBXoa.Location = new System.Drawing.Point(220, 65); this.btnNXBXoa.Size = new System.Drawing.Size(90, 32);

            this.dgvNXB.Location = new System.Drawing.Point(20, 110);
            this.dgvNXB.Size = new System.Drawing.Size(970, 470);
            this.dgvNXB.ReadOnly = true;
            this.dgvNXB.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNXB.MultiSelect = false;
            this.dgvNXB.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;

            this.tabNXB.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblNXBMa, this.txtNXBMa, lblNXBDiaChi, this.txtNXBDiaChi, lblNXBSDT, this.txtNXBSDT,
                this.btnNXBThem, this.btnNXBCapNhat, this.btnNXBXoa, this.dgvNXB
            });
            this.tabNXB.Text = "Nhà xuất bản";

            // 
            // btnDong
            // 
            this.btnDong.Text = "Đóng";
            this.btnDong.Location = new System.Drawing.Point(940, 660);
            this.btnDong.Size = new System.Drawing.Size(100, 35);
            this.btnDong.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;

            // 
            // FrmDanhMuc
            // 
            this.ClientSize = new System.Drawing.Size(1060, 720);
            this.Controls.Add(this.tabs);
            this.Controls.Add(this.btnDong);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Danh mục và nhân viên";

            this.tabs.ResumeLayout(false);
            this.tabNV.ResumeLayout(false);
            this.tabNV.PerformLayout();
            this.tabTL.ResumeLayout(false);
            this.tabTL.PerformLayout();
            this.tabNXB.ResumeLayout(false);
            this.tabNXB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNXB)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage tabNV;
        private System.Windows.Forms.TabPage tabTL;
        private System.Windows.Forms.TabPage tabNXB;
        private System.Windows.Forms.TextBox txtNVMa, txtNVHo, txtNVTen, txtNVChucVu, txtNVSDT;
        private System.Windows.Forms.ComboBox cboNVPhai;
        private System.Windows.Forms.DateTimePicker dtNVNgaySinh;
        private System.Windows.Forms.DataGridView dgvNV;
        private System.Windows.Forms.Button btnNVThem, btnNVCapNhat, btnNVXoa, btnNVMoi;
        private System.Windows.Forms.TextBox txtTLMa, txtTLTen;
        private System.Windows.Forms.DataGridView dgvTL;
        private System.Windows.Forms.Button btnTLThem, btnTLCapNhat, btnTLXoa;
        private System.Windows.Forms.TextBox txtNXBMa, txtNXBDiaChi, txtNXBSDT;
        private System.Windows.Forms.DataGridView dgvNXB;
        private System.Windows.Forms.Button btnNXBThem, btnNXBCapNhat, btnNXBXoa;
        private System.Windows.Forms.Button btnDong;
    }
}