﻿namespace QuanLyThuVien.Forms
{
    partial class FrmSach
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.txtTim = new System.Windows.Forms.TextBox();
            this.btnTim = new System.Windows.Forms.Button();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.numNam = new System.Windows.Forms.NumericUpDown();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.cboTheLoai = new System.Windows.Forms.ComboBox();
            this.cboNXB = new System.Windows.Forms.ComboBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnCapNhat = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.btnLamMoi = new System.Windows.Forms.Button();
            this.dgvSach = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.numNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSach)).BeginInit();
            this.SuspendLayout();

            // Labels
            System.Windows.Forms.Label lblTim = new System.Windows.Forms.Label { Text = "Từ khóa:", Left = 20, Top = 25, Width = 60 };
            System.Windows.Forms.Label lblMa = new System.Windows.Forms.Label { Text = "Mã sách:", Left = 20, Top = 70, Width = 90 };
            System.Windows.Forms.Label lblTen = new System.Windows.Forms.Label { Text = "Tên sách:", Left = 20, Top = 110, Width = 90 };
            System.Windows.Forms.Label lblNam = new System.Windows.Forms.Label { Text = "Năm XB:", Left = 20, Top = 150, Width = 90 };
            System.Windows.Forms.Label lblSoLuong = new System.Windows.Forms.Label { Text = "Số lượng:", Left = 250, Top = 150, Width = 80 };
            System.Windows.Forms.Label lblTheLoai = new System.Windows.Forms.Label { Text = "Thể loại:", Left = 20, Top = 190, Width = 90 };
            System.Windows.Forms.Label lblNXB = new System.Windows.Forms.Label { Text = "NXB:", Left = 20, Top = 230, Width = 90 };

            // Tìm kiếm
            this.txtTim.Left = 90; this.txtTim.Top = 20; this.txtTim.Width = 200;
            this.btnTim.Text = "Tìm"; this.btnTim.Left = 300; this.btnTim.Top = 18; this.btnTim.Width = 80;

            // Inputs
            this.txtMa.Left = 120; this.txtMa.Top = 65; this.txtMa.Width = 150;
            this.txtTen.Left = 120; this.txtTen.Top = 105; this.txtTen.Width = 300;

            this.numNam.Left = 120; this.numNam.Top = 145; this.numNam.Width = 100;
            this.numNam.Minimum = 1000M; this.numNam.Maximum = 3000M; this.numNam.Value = System.DateTime.Today.Year;

            this.numSoLuong.Left = 340; this.numSoLuong.Top = 145; this.numSoLuong.Width = 80;
            this.numSoLuong.Maximum = 100000M;

            this.cboTheLoai.Left = 120; this.cboTheLoai.Top = 185; this.cboTheLoai.Width = 200;
            this.cboTheLoai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.cboNXB.Left = 120; this.cboNXB.Top = 225; this.cboNXB.Width = 200;
            this.cboNXB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            // Buttons
            int btnTop = 270;
            this.btnThem.Text = "Thêm"; this.btnThem.Left = 20; this.btnThem.Top = btnTop; this.btnThem.Width = 90; this.btnThem.Height = 35;
            this.btnCapNhat.Text = "Cập nhật"; this.btnCapNhat.Left = 120; this.btnCapNhat.Top = btnTop; this.btnCapNhat.Width = 90; this.btnCapNhat.Height = 35;
            this.btnXoa.Text = "Xóa"; this.btnXoa.Left = 220; this.btnXoa.Top = btnTop; this.btnXoa.Width = 90; this.btnXoa.Height = 35;
            this.btnLamMoi.Text = "Làm mới"; this.btnLamMoi.Left = 320; this.btnLamMoi.Top = btnTop; this.btnLamMoi.Width = 90; this.btnLamMoi.Height = 35;

            // DataGridView
            this.dgvSach.Left = 20; this.dgvSach.Top = 320; this.dgvSach.Width = 1060; this.dgvSach.Height = 360;
            this.dgvSach.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.dgvSach.ReadOnly = true;
            this.dgvSach.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvSach.MultiSelect = false;

            this.btnDong.Text = "Đóng"; this.btnDong.Left = 990; this.btnDong.Top = 690; this.btnDong.Width = 90; this.btnDong.Height = 35;
            this.btnDong.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;

            // Form Properties
            this.ClientSize = new System.Drawing.Size(1120, 740);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Quản lý đầu sách";

            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblTim, this.txtTim, this.btnTim,
                lblMa, this.txtMa,
                lblTen, this.txtTen,
                lblNam, this.numNam,
                lblSoLuong, this.numSoLuong,
                lblTheLoai, this.cboTheLoai,
                lblNXB, this.cboNXB,
                this.btnThem, this.btnCapNhat, this.btnXoa, this.btnLamMoi,
                this.dgvSach, this.btnDong
            });

            ((System.ComponentModel.ISupportInitialize)(this.numNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSach)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.TextBox txtMa, txtTen, txtTim;
        private System.Windows.Forms.NumericUpDown numNam, numSoLuong;
        private System.Windows.Forms.ComboBox cboTheLoai, cboNXB;
        private System.Windows.Forms.DataGridView dgvSach;
        private System.Windows.Forms.Button btnTim, btnThem, btnCapNhat, btnXoa, btnLamMoi, btnDong;
    }
}