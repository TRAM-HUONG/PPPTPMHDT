﻿namespace QuanLyThuVien.Forms
{
    partial class FrmThongKe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.dtTu = new System.Windows.Forms.DateTimePicker();
            this.dtDen = new System.Windows.Forms.DateTimePicker();
            this.btnThongKe = new System.Windows.Forms.Button();
            this.lblMuon = new System.Windows.Forms.Label();
            this.lblQuaHan = new System.Windows.Forms.Label();
            this.lblMat = new System.Windows.Forms.Label();
            this.lblHuHong = new System.Windows.Forms.Label();
            this.lblPhiPhat = new System.Windows.Forms.Label();
            this.dgvPhat = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvPhat)).BeginInit();
            this.SuspendLayout();

            // Các Label tĩnh
            System.Windows.Forms.Label lblTu = new System.Windows.Forms.Label { Text = "Từ ngày:", Left = 20, Top = 25, Width = 70 };
            System.Windows.Forms.Label lblDen = new System.Windows.Forms.Label { Text = "Đến ngày:", Left = 270, Top = 25, Width = 80 };
            System.Windows.Forms.Label lblChiTiet = new System.Windows.Forms.Label { Text = "Chi tiết phiếu phạt:", Left = 20, Top = 145, Width = 200, Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Italic) };

            // DateTimePickers & Button Thống kê
            this.dtTu.Left = 100; this.dtTu.Top = 20; this.dtTu.Width = 150; this.dtTu.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDen.Left = 360; this.dtDen.Top = 20; this.dtDen.Width = 150; this.dtDen.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.btnThongKe.Text = "Thống kê"; this.btnThongKe.Left = 530; this.btnThongKe.Top = 18; this.btnThongKe.Width = 100; this.btnThongKe.Height = 32;

            // Labels hiển thị số liệu
            this.lblMuon.Text = "Lượt sách mượn: 0"; this.lblMuon.Left = 20; this.lblMuon.Top = 70; this.lblMuon.Width = 300; this.lblMuon.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblQuaHan.Text = "Sách quá hạn: 0"; this.lblQuaHan.Left = 350; this.lblQuaHan.Top = 70; this.lblQuaHan.Width = 300; this.lblQuaHan.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblMat.Text = "Sách mất: 0"; this.lblMat.Left = 680; this.lblMat.Top = 70; this.lblMat.Width = 300; this.lblMat.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);

            this.lblHuHong.Text = "Sách hư hỏng: 0"; this.lblHuHong.Left = 20; this.lblHuHong.Top = 105; this.lblHuHong.Width = 300; this.lblHuHong.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblPhiPhat.Text = "Tổng phí phạt: 0 đ"; this.lblPhiPhat.Left = 350; this.lblPhiPhat.Top = 105; this.lblPhiPhat.Width = 400; this.lblPhiPhat.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold); this.lblPhiPhat.ForeColor = System.Drawing.Color.DarkRed;

            // DataGridView
            this.dgvPhat.Left = 20; this.dgvPhat.Top = 170; this.dgvPhat.Width = 1015; this.dgvPhat.Height = 470;
            this.dgvPhat.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right;
            this.dgvPhat.ReadOnly = true;
            this.dgvPhat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvPhat.MultiSelect = false;

            // Nút Đóng
            this.btnDong.Text = "Đóng"; this.btnDong.Left = 935; this.btnDong.Top = 650; this.btnDong.Width = 100; this.btnDong.Height = 35;
            this.btnDong.Anchor = System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right;

            // Form Properties
            this.ClientSize = new System.Drawing.Size(1070, 700);
            this.Font = new System.Drawing.Font("Segoe UI", 9.5F);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Thống kê";

            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                lblTu, this.dtTu, lblDen, this.dtDen, this.btnThongKe,
                this.lblMuon, this.lblQuaHan, this.lblMat,
                this.lblHuHong, this.lblPhiPhat,
                lblChiTiet, this.dgvPhat,
                this.btnDong
            });

            ((System.ComponentModel.ISupportInitialize)(this.dgvPhat)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.DateTimePicker dtTu, dtDen;
        private System.Windows.Forms.Button btnThongKe, btnDong;
        private System.Windows.Forms.Label lblMuon, lblQuaHan, lblMat, lblHuHong, lblPhiPhat;
        private System.Windows.Forms.DataGridView dgvPhat;
    }
}