﻿using System;
using System.Drawing;
using System.Windows.Forms;
using QuanLyThuVien.Services;

namespace QuanLyThuVien.Forms
{
    public partial class FrmThongKe : Form
    {
        private readonly ThongKeService service = new ThongKeService();

        public FrmThongKe()
        {
            InitializeComponent();
            RegisterEvents();
            LoadDataInit();
        }

        private void RegisterEvents()
        {
            btnThongKe.Click += (s, e) => TaiDuLieu();
            btnDong.Click += (s, e) => Close();
        }

        private void LoadDataInit()
        {
            dtTu.Value = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            dtDen.Value = DateTime.Today;
            TaiDuLieu();
        }

        private void TaiDuLieu()
        {
            var t = service.LayTongHop(dtTu.Value, dtDen.Value);
            lblMuon.Text = "Lượt sách mượn: " + t.LuotSachMuon;
            lblQuaHan.Text = "Sách quá hạn: " + t.SachQuaHan;
            lblMat.Text = "Sách mất: " + t.SachMat;
            lblHuHong.Text = "Sách hư hỏng: " + t.SachHuHong;
            lblPhiPhat.Text = "Tổng phí phạt: " + t.TongPhiPhat.ToString("N0") + " đ";
            dgvPhat.DataSource = service.LayChiTietPhat(dtTu.Value, dtDen.Value);
            dgvPhat.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }
    }
}