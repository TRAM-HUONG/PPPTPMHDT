﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyEShopping.data
{
    public static class Data
    {
        public static string ConnectionString
        {
            get
            {
                return ConfigurationManager.ConnectionStrings["QL_NhanSu_SonDongA"].ConnectionString;
            }
        }

        public static SqlConnection OpenConnection()
        {
            var cn = new SqlConnection(ConnectionString);
            cn.Open();
            return cn;
        }

        public static DataTable Query(string sql, params SqlParameter[] ps)
        {
            using (var cn = OpenConnection())
            using (var cmd = new SqlCommand(sql, cn))
            using (var da = new SqlDataAdapter(cmd))
            {
                if (ps != null)
                {
                    cmd.Parameters.AddRange(ps);
                }

                var dt = new DataTable();
                da.Fill(dt);
                return dt;
            }
        }

        public static int Execute(string sql, params SqlParameter[] ps)
        {
            using (var cn = OpenConnection())
            using (var cmd = new SqlCommand(sql, cn))
            {
                if (ps != null)
                {
                    cmd.Parameters.AddRange(ps);
                }

                return cmd.ExecuteNonQuery();
            }
        }

        public static object Scalar(string sql, params SqlParameter[] ps)
        {
            using (var cn = OpenConnection())
            using (var cmd = new SqlCommand(sql, cn))
            {
                if (ps != null)
                {
                    cmd.Parameters.AddRange(ps);
                }

                return cmd.ExecuteScalar();
            }
        }
    }
}