﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmKhenThuongKyLuat : Form
    {
        private KhenThuongKyLuatService ktklService = new KhenThuongKyLuatService();

        public FrmKhenThuongKyLuat()
        {
            InitializeComponent();
        }

        private void FrmKhenThuongKyLuat_Load(object sender, EventArgs e)
        {
            LoadComboBoxData();
            LoadDataGrid();
        }

        private void LoadComboBoxData()
        {
            try
            {
                cbMaNV.DataSource = ktklService.GetDanhSachNhanVien();
                cbMaNV.DisplayMember = "HoTen";
                cbMaNV.ValueMember = "MaNV";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách nhân viên: " + ex.Message);
            }
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewKTKL.DataSource = ktklService.GetKhenThuongKyLuatCaNhan();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string soQD = txtSoQD.Text.Trim();
                DateTime ngayQD = dtpNgayQD.Value;
                string noiDung = txtNoiDung.Text.Trim();
                string maNV = cbMaNV.SelectedValue.ToString();
                decimal soTien = decimal.Parse(txtSoTien.Text.Trim());

                if (string.IsNullOrEmpty(soQD))
                {
                    MessageBox.Show("Vui lòng nhập Số quyết định!");
                    return;
                }

                if (ktklService.InsertKTKL_CaNhan(soQD, ngayQD, noiDung, maNV, soTien))
                {
                    MessageBox.Show("Thêm quyết định thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewKTKL.SelectedRows.Count > 0)
                {
                    string soQD = dataGridViewKTKL.SelectedRows[0].Cells["SoQuyetDinhKhenThuong_KyLuat"].Value.ToString();
                    string maNV = dataGridViewKTKL.SelectedRows[0].Cells["MaNV"].Value.ToString();

                    if (ktklService.DeleteKTKL_CaNhan(soQD, maNV))
                    {
                        MessageBox.Show("Xóa quyết định thành công!");
                        LoadDataGrid();
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng chọn dòng cần xóa trên bảng!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void dataGridViewKTKL_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewKTKL.Rows[e.RowIndex];
                txtSoQD.Text = row.Cells["SoQuyetDinhKhenThuong_KyLuat"].Value.ToString();
                if (row.Cells["NgayQuyetDinh"].Value != DBNull.Value)
                    dtpNgayQD.Value = Convert.ToDateTime(row.Cells["NgayQuyetDinh"].Value);
                txtNoiDung.Text = row.Cells["NoiDungQuyetDinh"].Value.ToString();
                cbMaNV.SelectedValue = row.Cells["MaNV"].Value.ToString();
                txtSoTien.Text = row.Cells["SoTienKhenThuong_KyLuatCaNhan"].Value.ToString();
            }
        }
    }
}