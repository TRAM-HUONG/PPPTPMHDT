﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmHopDong : Form
    {
        private HopDongService hdService = new HopDongService();

        public FrmHopDong()
        {
            InitializeComponent();
        }

        private void FrmHopDong_Load(object sender, EventArgs e)
        {
            LoadComboBoxData();
            LoadDataGrid();
        }

        private void LoadComboBoxData()
        {
            try
            {
                cbMaNV.DataSource = hdService.GetDanhSachNhanVien();
                cbMaNV.DisplayMember = "HoTen";
                cbMaNV.ValueMember = "MaNV";

                cbMaLoaiHD.DataSource = hdService.GetDanhSachLoaiHopDong();
                cbMaLoaiHD.DisplayMember = "TenLoaiHopDong";
                cbMaLoaiHD.ValueMember = "MaLoaiHopDong";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh mục: " + ex.Message);
            }
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewHD.DataSource = hdService.GetAllHopDong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string soHD = txtSoHD.Text.Trim();
                DateTime ngayLap = dtpNgayLap.Value;
                string noiDung = txtNoiDung.Text.Trim();
                string maLoaiHD = cbMaLoaiHD.SelectedValue.ToString();
                string maNV = cbMaNV.SelectedValue.ToString();

                if (string.IsNullOrEmpty(soHD))
                {
                    MessageBox.Show("Vui lòng nhập Số hợp đồng!");
                    return;
                }

                if (hdService.InsertHopDong(soHD, ngayLap, noiDung, maLoaiHD, maNV))
                {
                    MessageBox.Show("Thêm hợp đồng thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string soHD = txtSoHD.Text.Trim();
                if (string.IsNullOrEmpty(soHD))
                {
                    MessageBox.Show("Vui lòng chọn hợp đồng cần xóa!");
                    return;
                }

                if (hdService.DeleteHopDong(soHD))
                {
                    MessageBox.Show("Xóa hợp đồng thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void dataGridViewHD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewHD.Rows[e.RowIndex];
                txtSoHD.Text = row.Cells["SoHopDong"].Value.ToString();
                if (row.Cells["NgayLapHopDong"].Value != DBNull.Value)
                    dtpNgayLap.Value = Convert.ToDateTime(row.Cells["NgayLapHopDong"].Value);
                txtNoiDung.Text = row.Cells["NoiDungHopDong"].Value.ToString();
                cbMaLoaiHD.SelectedValue = row.Cells["MaLoaiHopDong"].Value.ToString();
                cbMaNV.SelectedValue = row.Cells["MaNV"].Value.ToString();
            }
        }
    }
}