﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmTuyenDung : Form
    {
        private TuyenDungService tdService = new TuyenDungService();

        public FrmTuyenDung()
        {
            InitializeComponent();
        }

        private void FrmTuyenDung_Load(object sender, EventArgs e)
        {
            LoadComboBoxData();
            LoadDataGrid();
        }

        private void LoadComboBoxData()
        {
            try
            {
                cbMaNV.DataSource = tdService.GetDanhSachNhanVien();
                cbMaNV.DisplayMember = "HoTen";
                cbMaNV.ValueMember = "MaNV";

                cbMaPB.DataSource = tdService.GetDanhSachPhongBan();
                cbMaPB.DisplayMember = "TenPhongBan";
                cbMaPB.ValueMember = "MaPhongBan";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh mục: " + ex.Message);
            }
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewTD.DataSource = tdService.GetAllQuyetDinhTuyenDung();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string soQD = txtSoQD.Text.Trim();
                DateTime ngayQD = dtpNgayQD.Value;
                int thoiGianTV = int.Parse(txtThoiGianTV.Text.Trim());
                decimal mucLuongTV = decimal.Parse(txtMucLuongTV.Text.Trim());
                string noiDung = txtNoiDung.Text.Trim();
                string maNV = cbMaNV.SelectedValue.ToString();
                string maPB = cbMaPB.SelectedValue.ToString();

                if (string.IsNullOrEmpty(soQD))
                {
                    MessageBox.Show("Vui lòng nhập Số quyết định tuyển dụng!");
                    return;
                }

                if (tdService.InsertQuyetDinh(soQD, ngayQD, thoiGianTV, mucLuongTV, noiDung, maNV, maPB))
                {
                    MessageBox.Show("Thêm quyết định tuyển dụng thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string soQD = txtSoQD.Text.Trim();
                if (string.IsNullOrEmpty(soQD))
                {
                    MessageBox.Show("Vui lòng chọn quyết định cần xóa!");
                    return;
                }

                if (tdService.DeleteQuyetDinh(soQD))
                {
                    MessageBox.Show("Xóa quyết định thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void dataGridViewTD_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewTD.Rows[e.RowIndex];
                txtSoQD.Text = row.Cells["SoQuyetDinhTuyenDung"].Value.ToString();
                if (row.Cells["NgayQuyetDinhTuyenDung"].Value != DBNull.Value)
                    dtpNgayQD.Value = Convert.ToDateTime(row.Cells["NgayQuyetDinhTuyenDung"].Value);
                txtThoiGianTV.Text = row.Cells["ThoiGianThuViec"].Value.ToString();
                txtMucLuongTV.Text = row.Cells["MucLuongThuViec"].Value.ToString();
                txtNoiDung.Text = row.Cells["NoiDungQuyetDinh"].Value.ToString();
                cbMaNV.SelectedValue = row.Cells["MaNV"].Value.ToString();
                cbMaPB.SelectedValue = row.Cells["MaPhongBan"].Value.ToString();
            }
        }
    }
}