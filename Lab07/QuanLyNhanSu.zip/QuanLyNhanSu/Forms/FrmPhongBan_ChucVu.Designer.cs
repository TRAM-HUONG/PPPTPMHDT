﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmPhongBan_ChucVu
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxPB = new System.Windows.Forms.GroupBox();
            this.btnXoaPB = new System.Windows.Forms.Button();
            this.btnThemPB = new System.Windows.Forms.Button();
            this.dataGridViewPB = new System.Windows.Forms.DataGridView();
            this.txtDienThoaiPB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTenPB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMaPB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBoxCV = new System.Windows.Forms.GroupBox();
            this.txtPhuCapCV = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnXoaCV = new System.Windows.Forms.Button();
            this.btnThemCV = new System.Windows.Forms.Button();
            this.dataGridViewCV = new System.Windows.Forms.DataGridView();
            this.txtHeSoLuong = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTenCV = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtMaCV = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.groupBoxPB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPB)).BeginInit();
            this.groupBoxCV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCV)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(0, 0, 128);
            this.label1.Location = new System.Drawing.Point(310, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ PHÒNG BAN & CHỨC VỤ";
            // 
            // groupBoxPB
            // 
            this.groupBoxPB.Controls.Add(this.btnXoaPB);
            this.groupBoxPB.Controls.Add(this.btnThemPB);
            this.groupBoxPB.Controls.Add(this.dataGridViewPB);
            this.groupBoxPB.Controls.Add(this.txtDienThoaiPB);
            this.groupBoxPB.Controls.Add(this.label4);
            this.groupBoxPB.Controls.Add(this.txtTenPB);
            this.groupBoxPB.Controls.Add(this.label3);
            this.groupBoxPB.Controls.Add(this.txtMaPB);
            this.groupBoxPB.Controls.Add(this.label2);
            this.groupBoxPB.Location = new System.Drawing.Point(20, 60);
            this.groupBoxPB.Name = "groupBoxPB";
            this.groupBoxPB.Size = new System.Drawing.Size(430, 480);
            this.groupBoxPB.TabIndex = 1;
            this.groupBoxPB.TabStop = false;
            this.groupBoxPB.Text = "Danh Mục Phòng Ban";
            // 
            // btnXoaPB
            // 
            this.btnXoaPB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnXoaPB.Location = new System.Drawing.Point(235, 140);
            this.btnXoaPB.Name = "btnXoaPB";
            this.btnXoaPB.Size = new System.Drawing.Size(80, 30);
            this.btnXoaPB.TabIndex = 8;
            this.btnXoaPB.Text = "Xóa";
            this.btnXoaPB.UseVisualStyleBackColor = true;
            this.btnXoaPB.Click += new System.EventHandler(this.btnXoaPB_Click);
            // 
            // btnThemPB
            // 
            this.btnThemPB.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnThemPB.Location = new System.Drawing.Point(120, 140);
            this.btnThemPB.Name = "btnThemPB";
            this.btnThemPB.Size = new System.Drawing.Size(80, 30);
            this.btnThemPB.TabIndex = 7;
            this.btnThemPB.Text = "Thêm";
            this.btnThemPB.UseVisualStyleBackColor = true;
            this.btnThemPB.Click += new System.EventHandler(this.btnThemPB_Click);
            // 
            // dataGridViewPB
            // 
            this.dataGridViewPB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPB.Location = new System.Drawing.Point(15, 185);
            this.dataGridViewPB.Name = "dataGridViewPB";
            this.dataGridViewPB.Size = new System.Drawing.Size(400, 280);
            this.dataGridViewPB.TabIndex = 6;
            this.dataGridViewPB.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPB_CellClick);
            // 
            // txtDienThoaiPB
            // 
            this.txtDienThoaiPB.Location = new System.Drawing.Point(120, 100);
            this.txtDienThoaiPB.Name = "txtDienThoaiPB";
            this.txtDienThoaiPB.Size = new System.Drawing.Size(280, 20);
            this.txtDienThoaiPB.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 103);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Điện Thoại:";
            // 
            // txtTenPB
            // 
            this.txtTenPB.Location = new System.Drawing.Point(120, 65);
            this.txtTenPB.Name = "txtTenPB";
            this.txtTenPB.Size = new System.Drawing.Size(280, 20);
            this.txtTenPB.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tên Phòng Ban:";
            // 
            // txtMaPB
            // 
            this.txtMaPB.Location = new System.Drawing.Point(120, 30);
            this.txtMaPB.Name = "txtMaPB";
            this.txtMaPB.Size = new System.Drawing.Size(280, 20);
            this.txtMaPB.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã Phòng Ban:";
            // 
            // groupBoxCV
            // 
            this.groupBoxCV.Controls.Add(this.txtPhuCapCV);
            this.groupBoxCV.Controls.Add(this.label9);
            this.groupBoxCV.Controls.Add(this.btnXoaCV);
            this.groupBoxCV.Controls.Add(this.btnThemCV);
            this.groupBoxCV.Controls.Add(this.dataGridViewCV);
            this.groupBoxCV.Controls.Add(this.txtHeSoLuong);
            this.groupBoxCV.Controls.Add(this.label5);
            this.groupBoxCV.Controls.Add(this.txtTenCV);
            this.groupBoxCV.Controls.Add(this.label6);
            this.groupBoxCV.Controls.Add(this.txtMaCV);
            this.groupBoxCV.Controls.Add(this.label7);
            this.groupBoxCV.Location = new System.Drawing.Point(470, 60);
            this.groupBoxCV.Name = "groupBoxCV";
            this.groupBoxCV.Size = new System.Drawing.Size(430, 480);
            this.groupBoxCV.TabIndex = 2;
            this.groupBoxCV.TabStop = false;
            this.groupBoxCV.Text = "Danh Mục Chức Vụ";
            // 
            // txtPhuCapCV
            // 
            this.txtPhuCapCV.Location = new System.Drawing.Point(120, 130);
            this.txtPhuCapCV.Name = "txtPhuCapCV";
            this.txtPhuCapCV.Size = new System.Drawing.Size(280, 20);
            this.txtPhuCapCV.TabIndex = 10;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(20, 133);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Phụ Cấp:";
            // 
            // btnXoaCV
            // 
            this.btnXoaCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnXoaCV.Location = new System.Drawing.Point(235, 160);
            this.btnXoaCV.Name = "btnXoaCV";
            this.btnXoaCV.Size = new System.Drawing.Size(80, 30);
            this.btnXoaCV.TabIndex = 8;
            this.btnXoaCV.Text = "Xóa";
            this.btnXoaCV.UseVisualStyleBackColor = true;
            this.btnXoaCV.Click += new System.EventHandler(this.btnXoaCV_Click);
            // 
            // btnThemCV
            // 
            this.btnThemCV.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnThemCV.Location = new System.Drawing.Point(120, 160);
            this.btnThemCV.Name = "btnThemCV";
            this.btnThemCV.Size = new System.Drawing.Size(80, 30);
            this.btnThemCV.TabIndex = 7;
            this.btnThemCV.Text = "Thêm";
            this.btnThemCV.UseVisualStyleBackColor = true;
            this.btnThemCV.Click += new System.EventHandler(this.btnThemCV_Click);
            // 
            // dataGridViewCV
            // 
            this.dataGridViewCV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewCV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCV.Location = new System.Drawing.Point(15, 200);
            this.dataGridViewCV.Name = "dataGridViewCV";
            this.dataGridViewCV.Size = new System.Drawing.Size(400, 265);
            this.dataGridViewCV.TabIndex = 6;
            this.dataGridViewCV.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCV_CellClick);
            // 
            // txtHeSoLuong
            // 
            this.txtHeSoLuong.Location = new System.Drawing.Point(120, 95);
            this.txtHeSoLuong.Name = "txtHeSoLuong";
            this.txtHeSoLuong.Size = new System.Drawing.Size(280, 20);
            this.txtHeSoLuong.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Hệ Số Lương:";
            // 
            // txtTenCV
            // 
            this.txtTenCV.Location = new System.Drawing.Point(120, 60);
            this.txtTenCV.Name = "txtTenCV";
            this.txtTenCV.Size = new System.Drawing.Size(280, 20);
            this.txtTenCV.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 63);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(73, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Tên Chức Vụ:";
            // 
            // txtMaCV
            // 
            this.txtMaCV.Location = new System.Drawing.Point(120, 25);
            this.txtMaCV.Name = "txtMaCV";
            this.txtMaCV.Size = new System.Drawing.Size(280, 20);
            this.txtMaCV.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(20, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(69, 13);
            this.label7.TabIndex = 0;
            this.label7.Text = "Mã Chức Vụ:";
            // 
            // FrmPhongBan_ChucVu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 560);
            this.Controls.Add(this.groupBoxCV);
            this.Controls.Add(this.groupBoxPB);
            this.Controls.Add(this.label1);
            this.Name = "FrmPhongBan_ChucVu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Phòng ban & Chức vụ - Sơn Đông Á";
            this.Load += new System.EventHandler(this.FrmPhongBan_ChucVu_Load);
            this.groupBoxPB.ResumeLayout(false);
            this.groupBoxPB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPB)).EndInit();
            this.groupBoxCV.ResumeLayout(false);
            this.groupBoxCV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxPB;
        private System.Windows.Forms.Button btnXoaPB;
        private System.Windows.Forms.Button btnThemPB;
        private System.Windows.Forms.DataGridView dataGridViewPB;
        private System.Windows.Forms.TextBox txtDienThoaiPB;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTenPB;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtMaPB;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBoxCV;
        private System.Windows.Forms.Button btnXoaCV;
        private System.Windows.Forms.Button btnThemCV;
        private System.Windows.Forms.DataGridView dataGridViewCV;
        private System.Windows.Forms.TextBox txtHeSoLuong;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTenCV;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtMaCV;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtPhuCapCV;
        private System.Windows.Forms.Label label9;
    }
}