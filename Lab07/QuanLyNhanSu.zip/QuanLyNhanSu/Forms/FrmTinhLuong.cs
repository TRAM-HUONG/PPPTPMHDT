﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmTinhLuong : Form
    {
        private TinhLuongService tlService = new TinhLuongService();

        public FrmTinhLuong()
        {
            InitializeComponent();
        }

        private void FrmTinhLuong_Load(object sender, EventArgs e)
        {
            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewTL.DataSource = tlService.TinhBangLuongThang();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tính lương: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTinhLuong_Click(object sender, EventArgs e)
        {
            LoadDataGrid();
            MessageBox.Show("Đã tổng hợp và tính bảng lương thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}