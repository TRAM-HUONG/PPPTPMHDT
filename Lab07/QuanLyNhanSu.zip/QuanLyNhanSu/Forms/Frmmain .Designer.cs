﻿namespace QuanLyNhanSu.Forms
{
    partial class Frmmain
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTieuDe = new System.Windows.Forms.Label();
            this.btnNhanVien = new System.Windows.Forms.Button();
            this.btnPhongBanChucVu = new System.Windows.Forms.Button();
            this.btnTuyenDung = new System.Windows.Forms.Button();
            this.btnHopDong = new System.Windows.Forms.Button();
            this.btnBaoHiem = new System.Windows.Forms.Button();
            this.btnQuyetDinhLuong = new System.Windows.Forms.Button();
            this.btnKeHoachPhanCong = new System.Windows.Forms.Button();
            this.btnChamCong = new System.Windows.Forms.Button();
            this.btnPhuTroi = new System.Windows.Forms.Button();
            this.btnKhenThuongKyLuat = new System.Windows.Forms.Button();
            this.btnTinhLuong = new System.Windows.Forms.Button();
            this.btnThoat = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblTieuDe
            // 
            this.lblTieuDe.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold);
            this.lblTieuDe.ForeColor = System.Drawing.Color.FromArgb(0, 0, 128);
            this.lblTieuDe.Location = new System.Drawing.Point(50, 25);
            this.lblTieuDe.Name = "lblTieuDe";
            this.lblTieuDe.Size = new System.Drawing.Size(784, 40);
            this.lblTieuDe.TabIndex = 0;
            this.lblTieuDe.Text = "CÔNG TY SƠN ĐÔNG Á - QUẢN LÝ NHÂN SỰ";
            this.lblTieuDe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnNhanVien
            // 
            this.btnNhanVien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnNhanVien.Location = new System.Drawing.Point(80, 90);
            this.btnNhanVien.Name = "btnNhanVien";
            this.btnNhanVien.Size = new System.Drawing.Size(320, 50);
            this.btnNhanVien.TabIndex = 1;
            this.btnNhanVien.Text = "Hồ sơ Nhân viên";
            this.btnNhanVien.UseVisualStyleBackColor = true;
            this.btnNhanVien.Click += new System.EventHandler(this.btnNhanVien_Click);
            // 
            // btnPhongBanChucVu
            // 
            this.btnPhongBanChucVu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnPhongBanChucVu.Location = new System.Drawing.Point(484, 90);
            this.btnPhongBanChucVu.Name = "btnPhongBanChucVu";
            this.btnPhongBanChucVu.Size = new System.Drawing.Size(320, 50);
            this.btnPhongBanChucVu.TabIndex = 2;
            this.btnPhongBanChucVu.Text = "Phòng ban & Chức vụ";
            this.btnPhongBanChucVu.UseVisualStyleBackColor = true;
            this.btnPhongBanChucVu.Click += new System.EventHandler(this.btnPhongBanChucVu_Click);
            // 
            // btnTuyenDung
            // 
            this.btnTuyenDung.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnTuyenDung.Location = new System.Drawing.Point(80, 160);
            this.btnTuyenDung.Name = "btnTuyenDung";
            this.btnTuyenDung.Size = new System.Drawing.Size(320, 50);
            this.btnTuyenDung.TabIndex = 3;
            this.btnTuyenDung.Text = "Quyết định Tuyển dụng";
            this.btnTuyenDung.UseVisualStyleBackColor = true;
            this.btnTuyenDung.Click += new System.EventHandler(this.btnTuyenDung_Click);
            // 
            // btnHopDong
            // 
            this.btnHopDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnHopDong.Location = new System.Drawing.Point(484, 160);
            this.btnHopDong.Name = "btnHopDong";
            this.btnHopDong.Size = new System.Drawing.Size(320, 50);
            this.btnHopDong.TabIndex = 4;
            this.btnHopDong.Text = "Hợp đồng lao động";
            this.btnHopDong.UseVisualStyleBackColor = true;
            this.btnHopDong.Click += new System.EventHandler(this.btnHopDong_Click);
            // 
            // btnBaoHiem
            // 
            this.btnBaoHiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnBaoHiem.Location = new System.Drawing.Point(80, 230);
            this.btnBaoHiem.Name = "btnBaoHiem";
            this.btnBaoHiem.Size = new System.Drawing.Size(320, 50);
            this.btnBaoHiem.TabIndex = 5;
            this.btnBaoHiem.Text = "Sổ Bảo hiểm (BHXH, BHYT)";
            this.btnBaoHiem.UseVisualStyleBackColor = true;
            this.btnBaoHiem.Click += new System.EventHandler(this.btnBaoHiem_Click);
            // 
            // btnQuyetDinhLuong
            // 
            this.btnQuyetDinhLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnQuyetDinhLuong.Location = new System.Drawing.Point(484, 230);
            this.btnQuyetDinhLuong.Name = "btnQuyetDinhLuong";
            this.btnQuyetDinhLuong.Size = new System.Drawing.Size(320, 50);
            this.btnQuyetDinhLuong.TabIndex = 6;
            this.btnQuyetDinhLuong.Text = "Quyết định Lương & Phụ cấp";
            this.btnQuyetDinhLuong.UseVisualStyleBackColor = true;
            this.btnQuyetDinhLuong.Click += new System.EventHandler(this.btnQuyetDinhLuong_Click);
            // 
            // btnKeHoachPhanCong
            // 
            this.btnKeHoachPhanCong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnKeHoachPhanCong.Location = new System.Drawing.Point(80, 300);
            this.btnKeHoachPhanCong.Name = "btnKeHoachPhanCong";
            this.btnKeHoachPhanCong.Size = new System.Drawing.Size(320, 50);
            this.btnKeHoachPhanCong.TabIndex = 7;
            this.btnKeHoachPhanCong.Text = "Kế hoạch Phân công";
            this.btnKeHoachPhanCong.UseVisualStyleBackColor = true;
            this.btnKeHoachPhanCong.Click += new System.EventHandler(this.btnKeHoachPhanCong_Click);
            // 
            // btnChamCong
            // 
            this.btnChamCong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnChamCong.Location = new System.Drawing.Point(484, 300);
            this.btnChamCong.Name = "btnChamCong";
            this.btnChamCong.Size = new System.Drawing.Size(320, 50);
            this.btnChamCong.TabIndex = 8;
            this.btnChamCong.Text = "Bảng Chấm công";
            this.btnChamCong.UseVisualStyleBackColor = true;
            this.btnChamCong.Click += new System.EventHandler(this.btnChamCong_Click);
            // 
            // btnPhuTroi
            // 
            this.btnPhuTroi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnPhuTroi.Location = new System.Drawing.Point(80, 370);
            this.btnPhuTroi.Name = "btnPhuTroi";
            this.btnPhuTroi.Size = new System.Drawing.Size(320, 50);
            this.btnPhuTroi.TabIndex = 9;
            this.btnPhuTroi.Text = "Phiếu ghi nhận Phụ trội";
            this.btnPhuTroi.UseVisualStyleBackColor = true;
            this.btnPhuTroi.Click += new System.EventHandler(this.btnPhuTroi_Click);
            // 
            // btnKhenThuongKyLuat
            // 
            this.btnKhenThuongKyLuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnKhenThuongKyLuat.Location = new System.Drawing.Point(484, 370);
            this.btnKhenThuongKyLuat.Name = "btnKhenThuongKyLuat";
            this.btnKhenThuongKyLuat.Size = new System.Drawing.Size(320, 50);
            this.btnKhenThuongKyLuat.TabIndex = 10;
            this.btnKhenThuongKyLuat.Text = "Khen thưởng & Kỷ luật";
            this.btnKhenThuongKyLuat.UseVisualStyleBackColor = true;
            this.btnKhenThuongKyLuat.Click += new System.EventHandler(this.btnKhenThuongKyLuat_Click);
            // 
            // btnTinhLuong
            // 
            this.btnTinhLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnTinhLuong.Location = new System.Drawing.Point(80, 440);
            this.btnTinhLuong.Name = "btnTinhLuong";
            this.btnTinhLuong.Size = new System.Drawing.Size(320, 50);
            this.btnTinhLuong.TabIndex = 11;
            this.btnTinhLuong.Text = "Tính lương Hằng tháng";
            this.btnTinhLuong.UseVisualStyleBackColor = true;
            this.btnTinhLuong.Click += new System.EventHandler(this.btnTinhLuong_Click);
            // 
            // btnThoat
            // 
            this.btnThoat.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.btnThoat.Location = new System.Drawing.Point(484, 440);
            this.btnThoat.Name = "btnThoat";
            this.btnThoat.Size = new System.Drawing.Size(320, 50);
            this.btnThoat.TabIndex = 12;
            this.btnThoat.Text = "Thoát chương trình";
            this.btnThoat.UseVisualStyleBackColor = true;
            this.btnThoat.Click += new System.EventHandler(this.btnThoat_Click);
            // 
            // Frmmain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 521);
            this.Controls.Add(this.btnThoat);
            this.Controls.Add(this.btnTinhLuong);
            this.Controls.Add(this.btnKhenThuongKyLuat);
            this.Controls.Add(this.btnPhuTroi);
            this.Controls.Add(this.btnChamCong);
            this.Controls.Add(this.btnKeHoachPhanCong);
            this.Controls.Add(this.btnQuyetDinhLuong);
            this.Controls.Add(this.btnBaoHiem);
            this.Controls.Add(this.btnHopDong);
            this.Controls.Add(this.btnTuyenDung);
            this.Controls.Add(this.btnPhongBanChucVu);
            this.Controls.Add(this.btnNhanVien);
            this.Controls.Add(this.lblTieuDe);
            this.Name = "Frmmain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Nhân sự - Công ty Sơn Đông Á";
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Label lblTieuDe;
        private System.Windows.Forms.Button btnNhanVien;
        private System.Windows.Forms.Button btnPhongBanChucVu;
        private System.Windows.Forms.Button btnTuyenDung;
        private System.Windows.Forms.Button btnHopDong;
        private System.Windows.Forms.Button btnBaoHiem;
        private System.Windows.Forms.Button btnQuyetDinhLuong;
        private System.Windows.Forms.Button btnKeHoachPhanCong;
        private System.Windows.Forms.Button btnChamCong;
        private System.Windows.Forms.Button btnPhuTroi;
        private System.Windows.Forms.Button btnKhenThuongKyLuat;
        private System.Windows.Forms.Button btnTinhLuong;
        private System.Windows.Forms.Button btnThoat;
    }
}