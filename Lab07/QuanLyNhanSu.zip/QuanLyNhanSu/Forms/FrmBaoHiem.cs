﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmBaoHiem : Form
    {
        private BaoHiemService bhService = new BaoHiemService();

        public FrmBaoHiem()
        {
            InitializeComponent();
        }

        private void FrmBaoHiem_Load(object sender, EventArgs e)
        {
            LoadComboBoxData();
            LoadDataGrid();
        }

        private void LoadComboBoxData()
        {
            try
            {
                cbMaNV.DataSource = bhService.GetDanhSachNhanVien();
                cbMaNV.DisplayMember = "HoTen";
                cbMaNV.ValueMember = "MaNV";

                cbMaBH.DataSource = bhService.GetDanhSachBaoHiem();
                cbMaBH.DisplayMember = "TenBaoHiem";
                cbMaBH.ValueMember = "MaBaoHiem";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh mục: " + ex.Message);
            }
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewBH.DataSource = bhService.GetAllSoBaoHiem();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string maSoBH = txtMaSoBH.Text.Trim();
                DateTime ngayLap = dtpNgayLap.Value;
                string thoiHan = txtThoiHan.Text.Trim();
                string maNV = cbMaNV.SelectedValue.ToString();
                string maBH = cbMaBH.SelectedValue.ToString();

                if (string.IsNullOrEmpty(maSoBH))
                {
                    MessageBox.Show("Vui lòng nhập Mã sổ bảo hiểm!");
                    return;
                }

                if (bhService.InsertSoBaoHiem(maSoBH, ngayLap, thoiHan, maNV, maBH))
                {
                    MessageBox.Show("Thêm sổ bảo hiểm thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string maSoBH = txtMaSoBH.Text.Trim();
                if (string.IsNullOrEmpty(maSoBH))
                {
                    MessageBox.Show("Vui lòng chọn sổ bảo hiểm cần xóa!");
                    return;
                }

                if (bhService.DeleteSoBaoHiem(maSoBH))
                {
                    MessageBox.Show("Xóa sổ bảo hiểm thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void dataGridViewBH_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewBH.Rows[e.RowIndex];
                txtMaSoBH.Text = row.Cells["MaSoBaoHiem"].Value.ToString();
                if (row.Cells["NgayLapSoBaoHiem"].Value != DBNull.Value)
                    dtpNgayLap.Value = Convert.ToDateTime(row.Cells["NgayLapSoBaoHiem"].Value);
                txtThoiHan.Text = row.Cells["ThoiHanSoBaoHiem"].Value.ToString();
                cbMaNV.SelectedValue = row.Cells["MaNV"].Value.ToString();
                cbMaBH.SelectedValue = row.Cells["MaBaoHiem"].Value.ToString();
            }
        }
    }
}