﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmPhuTroi : Form
    {
        private PhuTroiService ptService = new PhuTroiService();

        public FrmPhuTroi()
        {
            InitializeComponent();
        }

        private void FrmPhuTroi_Load(object sender, EventArgs e)
        {
            LoadComboBoxData();
            LoadDataGrid();
            txtHeSo.Text = "1.5"; // Mặc định hệ số phụ trội là 1.5
        }

        private void LoadComboBoxData()
        {
            try
            {
                cbMaNV.DataSource = ptService.GetDanhSachNhanVien();
                cbMaNV.DisplayMember = "HoTen";
                cbMaNV.ValueMember = "MaNV";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách nhân viên: " + ex.Message);
            }
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewPT.DataSource = ptService.GetAllPhuTroi();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string soPhieu = txtSoPhieu.Text.Trim();
                DateTime ngayPhuTroi = dtpNgayPhuTroi.Value;
                string hinhThuc = cbHinhThuc.SelectedItem?.ToString() ?? "Tăng ca";
                float soGioPT = float.Parse(txtSoGioPT.Text.Trim());
                float heSo = float.Parse(txtHeSo.Text.Trim());
                string maNV = cbMaNV.SelectedValue.ToString();
                float soGioTG = float.Parse(txtSoGioTG.Text.Trim());

                if (string.IsNullOrEmpty(soPhieu))
                {
                    MessageBox.Show("Vui lòng nhập Số phiếu phụ trội!");
                    return;
                }

                if (ptService.InsertPhuTroi(soPhieu, ngayPhuTroi, hinhThuc, soGioPT, heSo, maNV, soGioTG))
                {
                    MessageBox.Show("Thêm phiếu phụ trội thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewPT.SelectedRows.Count > 0)
                {
                    string soPhieu = dataGridViewPT.SelectedRows[0].Cells["SoPhieuGhiNhanPhuTroi"].Value.ToString();
                    string maNV = dataGridViewPT.SelectedRows[0].Cells["MaNV"].Value.ToString();

                    if (ptService.DeletePhuTroi(soPhieu, maNV))
                    {
                        MessageBox.Show("Xóa phiếu phụ trội thành công!");
                        LoadDataGrid();
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng chọn dòng cần xóa trên bảng!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void dataGridViewPT_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewPT.Rows[e.RowIndex];
                txtSoPhieu.Text = row.Cells["SoPhieuGhiNhanPhuTroi"].Value.ToString();
                if (row.Cells["NgayPhuTroi"].Value != DBNull.Value)
                    dtpNgayPhuTroi.Value = Convert.ToDateTime(row.Cells["NgayPhuTroi"].Value);
                cbHinhThuc.Text = row.Cells["HinhThucPhuTroi"].Value.ToString();
                txtSoGioPT.Text = row.Cells["SoGioPhuTroi"].Value.ToString();
                txtHeSo.Text = row.Cells["HeSoPhuTroi"].Value.ToString();
                cbMaNV.SelectedValue = row.Cells["MaNV"].Value.ToString();
                txtSoGioTG.Text = row.Cells["SoGioPhuTroiThamGia"].Value.ToString();
            }
        }
    }
}