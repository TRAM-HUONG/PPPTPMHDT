﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmQuyetDinhLuong : Form
    {
        private LuongService luongService = new LuongService();

        public FrmQuyetDinhLuong()
        {
            InitializeComponent();
        }

        private void FrmQuyetDinhLuong_Load(object sender, EventArgs e)
        {
            LoadComboBoxData();
            LoadDataGrid();
        }

        private void LoadComboBoxData()
        {
            try
            {
                cbMaNV.DataSource = luongService.GetDanhSachNhanVien();
                cbMaNV.DisplayMember = "HoTen";
                cbMaNV.ValueMember = "MaNV";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh sách nhân viên: " + ex.Message);
            }
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewLuong.DataSource = luongService.GetAllQuyetDinhLuong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string soQDL = txtSoQDL.Text.Trim();
                DateTime ngayQDL = dtpNgayQDL.Value;
                decimal mucLuongCB = decimal.Parse(txtMucLuongCB.Text.Trim());
                string maNV = cbMaNV.SelectedValue.ToString();

                if (string.IsNullOrEmpty(soQDL))
                {
                    MessageBox.Show("Vui lòng nhập Số quyết định lương!");
                    return;
                }

                if (luongService.InsertQuyetDinhLuong(soQDL, ngayQDL, mucLuongCB, maNV))
                {
                    MessageBox.Show("Thêm quyết định lương thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string soQDL = txtSoQDL.Text.Trim();
                if (string.IsNullOrEmpty(soQDL))
                {
                    MessageBox.Show("Vui lòng chọn quyết định lương cần xóa!");
                    return;
                }

                if (luongService.DeleteQuyetDinhLuong(soQDL))
                {
                    MessageBox.Show("Xóa quyết định lương thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void dataGridViewLuong_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewLuong.Rows[e.RowIndex];
                txtSoQDL.Text = row.Cells["SoQuyetDinhLuong"].Value.ToString();
                if (row.Cells["NgayQuyetDinhLuong"].Value != DBNull.Value)
                    dtpNgayQDL.Value = Convert.ToDateTime(row.Cells["NgayQuyetDinhLuong"].Value);
                txtMucLuongCB.Text = row.Cells["MucLuongCoBan"].Value.ToString();
                cbMaNV.SelectedValue = row.Cells["MaNV"].Value.ToString();
            }
        }
    }
}