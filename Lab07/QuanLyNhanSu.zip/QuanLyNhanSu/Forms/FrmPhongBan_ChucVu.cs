﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmPhongBan_ChucVu : Form
    {
        private PhongBanService pbService = new PhongBanService();
        private ChucVuService cvService = new ChucVuService();

        public FrmPhongBan_ChucVu()
        {
            InitializeComponent();
        }

        private void FrmPhongBan_ChucVu_Load(object sender, EventArgs e)
        {
            LoadDataPhongBan();
            LoadDataChucVu();
        }

        private void LoadDataPhongBan()
        {
            try
            {
                dataGridViewPB.DataSource = pbService.GetAllPhongBan();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu phòng ban: " + ex.Message);
            }
        }

        private void LoadDataChucVu()
        {
            try
            {
                dataGridViewCV.DataSource = cvService.GetAllChucVu();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu chức vụ: " + ex.Message);
            }
        }

        // --- SỰ KIỆN PHÒNG BAN ---
        private void btnThemPB_Click(object sender, EventArgs e)
        {
            try
            {
                string maPB = txtMaPB.Text.Trim();
                string tenPB = txtTenPB.Text.Trim();
                string dtPB = txtDienThoaiPB.Text.Trim();

                if (string.IsNullOrEmpty(maPB) || string.IsNullOrEmpty(tenPB))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ Mã và Tên phòng ban!");
                    return;
                }

                if (pbService.InsertPhongBan(maPB, tenPB, dtPB))
                {
                    MessageBox.Show("Thêm phòng ban thành công!");
                    LoadDataPhongBan();
                }
            }
            catch (Exception ex) { MessageBox.Show("Lỗi: " + ex.Message); }
        }

        private void btnXoaPB_Click(object sender, EventArgs e)
        {
            try
            {
                string maPB = txtMaPB.Text.Trim();
                if (pbService.DeletePhongBan(maPB))
                {
                    MessageBox.Show("Xóa phòng ban thành công!");
                    LoadDataPhongBan();
                }
            }
            catch (Exception ex) { MessageBox.Show("Lỗi: " + ex.Message); }
        }

        private void dataGridViewPB_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewPB.Rows[e.RowIndex];
                txtMaPB.Text = row.Cells["MaPhongBan"].Value.ToString();
                txtTenPB.Text = row.Cells["TenPhongBan"].Value.ToString();
                txtDienThoaiPB.Text = row.Cells["DienThoaiPhongBan"]?.Value?.ToString() ?? "";
            }
        }

        // --- SỰ KIỆN CHỨC VỤ ---
        private void btnThemCV_Click(object sender, EventArgs e)
        {
            try
            {
                string maCV = txtMaCV.Text.Trim();
                string tenCV = txtTenCV.Text.Trim();
                float heSo = float.Parse(txtHeSoLuong.Text.Trim());
                decimal phuCap = decimal.Parse(txtPhuCapCV.Text.Trim());

                if (cvService.InsertChucVu(maCV, tenCV, heSo, phuCap))
                {
                    MessageBox.Show("Thêm chức vụ thành công!");
                    LoadDataChucVu();
                }
            }
            catch (Exception ex) { MessageBox.Show("Lỗi định dạng dữ liệu: " + ex.Message); }
        }

        private void btnXoaCV_Click(object sender, EventArgs e)
        {
            try
            {
                string maCV = txtMaCV.Text.Trim();
                if (cvService.DeleteChucVu(maCV))
                {
                    MessageBox.Show("Xóa chức vụ thành công!");
                    LoadDataChucVu();
                }
            }
            catch (Exception ex) { MessageBox.Show("Lỗi: " + ex.Message); }
        }

        private void dataGridViewCV_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewCV.Rows[e.RowIndex];
                txtMaCV.Text = row.Cells["MaChucVu"].Value.ToString();
                txtTenCV.Text = row.Cells["TenChucVu"].Value.ToString();
                txtHeSoLuong.Text = row.Cells["HeSoLuong"].Value.ToString();
                txtPhuCapCV.Text = row.Cells["PhuCapChucVu"].Value.ToString();
            }
        }
    }
}