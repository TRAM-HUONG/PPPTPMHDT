﻿using System;
using System.Windows.Forms;

namespace QuanLyNhanSu.Forms
{
    public partial class Frmmain : Form
    {
        public Frmmain()
        {
            InitializeComponent();
        }

        // Hàm hỗ trợ mở form con, tránh mở trùng lặp
        private void OpenChildForm(Form childForm)
        {
            // Nếu dùng dạng giao diện Dashboard chính, khi bấm vào nút sẽ mở form chức năng lên dạng cửa sổ độc lập (ShowDialog hoặc Show)
            childForm.StartPosition = FormStartPosition.CenterScreen;
            childForm.ShowDialog();
        }

        private void btnNhanVien_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmNhanVien());
        }

        private void btnPhongBanChucVu_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmPhongBan_ChucVu());
        }

        private void btnTuyenDung_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmTuyenDung());
        }

        private void btnHopDong_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmHopDong());
        }

        private void btnBaoHiem_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmBaoHiem());
        }

        private void btnQuyetDinhLuong_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmQuyetDinhLuong());
        }

        private void btnKeHoachPhanCong_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmKeHoachPhanCong());
        }

        private void btnChamCong_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmChamCong());
        }

        private void btnPhuTroi_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmPhuTroi());
        }

        private void btnKhenThuongKyLuat_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmKhenThuongKyLuat());
        }

        private void btnTinhLuong_Click(object sender, EventArgs e)
        {
            OpenChildForm(new FrmTinhLuong());
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có muốn thoát chương trình không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}