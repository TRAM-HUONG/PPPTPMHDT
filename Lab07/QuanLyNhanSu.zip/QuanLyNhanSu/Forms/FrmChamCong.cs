﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmChamCong : Form
    {
        private ChamCongService ccService = new ChamCongService();

        public FrmChamCong()
        {
            InitializeComponent();
        }

        private void FrmChamCong_Load(object sender, EventArgs e)
        {
            LoadDataGrid();
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewCC.DataSource = ccService.GetAllBangChamCong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string maBCC = txtMaBCC.Text.Trim();
                DateTime tuNgay = dtpTuNgay.Value;
                DateTime denNgay = dtpDenNgay.Value;

                if (string.IsNullOrEmpty(maBCC))
                {
                    MessageBox.Show("Vui lòng nhập Mã bảng chấm công!");
                    return;
                }

                if (ccService.InsertBangChamCong(maBCC, tuNgay, denNgay))
                {
                    MessageBox.Show("Thêm bảng chấm công thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                string maBCC = txtMaBCC.Text.Trim();
                if (string.IsNullOrEmpty(maBCC))
                {
                    MessageBox.Show("Vui lòng chọn bảng chấm công cần xóa!");
                    return;
                }

                if (ccService.DeleteBangChamCong(maBCC))
                {
                    MessageBox.Show("Xóa bảng chấm công thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void dataGridViewCC_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewCC.Rows[e.RowIndex];
                txtMaBCC.Text = row.Cells["MaBangChamCong"].Value.ToString();
                if (row.Cells["TuNgay"].Value != DBNull.Value)
                    dtpTuNgay.Value = Convert.ToDateTime(row.Cells["TuNgay"].Value);
                if (row.Cells["DenNgay"].Value != DBNull.Value)
                    dtpDenNgay.Value = Convert.ToDateTime(row.Cells["DenNgay"].Value);
            }
        }
    }
}