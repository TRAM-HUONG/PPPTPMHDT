﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyNhanSu.Services;

namespace QuanLyNhanSu.Forms
{
    public partial class FrmKeHoachPhanCong : Form
    {
        private PhanCongService pcService = new PhanCongService();

        public FrmKeHoachPhanCong()
        {
            InitializeComponent();
        }

        private void FrmKeHoachPhanCong_Load(object sender, EventArgs e)
        {
            LoadComboBoxData();
            LoadDataGrid();
        }

        private void LoadComboBoxData()
        {
            try
            {
                cbMaNV.DataSource = pcService.GetDanhSachNhanVien();
                cbMaNV.DisplayMember = "HoTen";
                cbMaNV.ValueMember = "MaNV";

                cbMaBCC.DataSource = pcService.GetDanhSachBangChamCong();
                cbMaBCC.DisplayMember = "MaBangChamCong";
                cbMaBCC.ValueMember = "MaBangChamCong";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải danh mục: " + ex.Message);
            }
        }

        private void LoadDataGrid()
        {
            try
            {
                dataGridViewPC.DataSource = pcService.GetAllPhanCong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            try
            {
                string maNV = cbMaNV.SelectedValue.ToString();
                string maBCC = cbMaBCC.SelectedValue.ToString();
                float soGio = float.Parse(txtSoGio.Text.Trim());

                if (pcService.InsertPhanCong(maNV, maBCC, soGio))
                {
                    MessageBox.Show("Phân công nhân viên thành công!");
                    LoadDataGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi nhập liệu: " + ex.Message);
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridViewPC.SelectedRows.Count > 0)
                {
                    string maNV = dataGridViewPC.SelectedRows[0].Cells["MaNV"].Value.ToString();
                    string maBCC = dataGridViewPC.SelectedRows[0].Cells["MaBangChamCong"].Value.ToString();

                    if (pcService.DeletePhanCong(maNV, maBCC))
                    {
                        MessageBox.Show("Xóa phân công thành công!");
                        LoadDataGrid();
                    }
                }
                else
                {
                    MessageBox.Show("Vui lòng chọn dòng cần xóa trên bảng!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi: " + ex.Message);
            }
        }

        private void dataGridViewPC_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridViewPC.Rows[e.RowIndex];
                cbMaNV.SelectedValue = row.Cells["MaNV"].Value.ToString();
                cbMaBCC.SelectedValue = row.Cells["MaBangChamCong"].Value.ToString();
                txtSoGio.Text = row.Cells["SoGioLamViec"].Value.ToString();
            }
        }
    }
}