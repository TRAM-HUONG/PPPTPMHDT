﻿namespace QuanLyNhanSu.Forms
{
    partial class FrmPhuTroi
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSoPhieu = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpNgayPhuTroi = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.cbHinhThuc = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSoGioPT = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtHeSo = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cbMaNV = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtSoGioTG = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnXoa = new System.Windows.Forms.Button();
            this.dataGridViewPT = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPT)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(0, 0, 128);
            this.label1.Location = new System.Drawing.Point(300, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(278, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "QUẢN LÝ GIỜ PHỤ TRỘI (TĂNG CA)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Số Phiếu:";
            // 
            // txtSoPhieu
            // 
            this.txtSoPhieu.Location = new System.Drawing.Point(130, 77);
            this.txtSoPhieu.Name = "txtSoPhieu";
            this.txtSoPhieu.Size = new System.Drawing.Size(180, 20);
            this.txtSoPhieu.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Ngày Phụ Trội:";
            // 
            // dtpNgayPhuTroi
            // 
            this.dtpNgayPhuTroi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayPhuTroi.Location = new System.Drawing.Point(130, 117);
            this.dtpNgayPhuTroi.Name = "dtpNgayPhuTroi";
            this.dtpNgayPhuTroi.Size = new System.Drawing.Size(180, 20);
            this.dtpNgayPhuTroi.TabIndex = 4;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(30, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Hình Thức PT:";
            // 
            // cbHinhThuc
            // 
            this.cbHinhThuc.FormattingEnabled = true;
            this.cbHinhThuc.Items.AddRange(new object[] {
            "Tăng ca",
            "Ngày lễ",
            "Ngày nghỉ"});
            this.cbHinhThuc.Location = new System.Drawing.Point(130, 157);
            this.cbHinhThuc.Name = "cbHinhThuc";
            this.cbHinhThuc.Size = new System.Drawing.Size(180, 21);
            this.cbHinhThuc.TabIndex = 6;
            this.cbHinhThuc.Text = "Tăng ca";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(30, 200);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Tổng Giờ PT:";
            // 
            // txtSoGioPT
            // 
            this.txtSoGioPT.Location = new System.Drawing.Point(130, 197);
            this.txtSoGioPT.Name = "txtSoGioPT";
            this.txtSoGioPT.Size = new System.Drawing.Size(180, 20);
            this.txtSoGioPT.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(440, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Hệ Số PT:";
            // 
            // txtHeSo
            // 
            this.txtHeSo.Location = new System.Drawing.Point(540, 77);
            this.txtHeSo.Name = "txtHeSo";
            this.txtHeSo.Size = new System.Drawing.Size(200, 20);
            this.txtHeSo.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(440, 120);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Nhân Viên:";
            // 
            // cbMaNV
            // 
            this.cbMaNV.FormattingEnabled = true;
            this.cbMaNV.Location = new System.Drawing.Point(540, 117);
            this.cbMaNV.Name = "cbMaNV";
            this.cbMaNV.Size = new System.Drawing.Size(200, 21);
            this.cbMaNV.TabIndex = 12;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(440, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(87, 13);
            this.label8.TabIndex = 13;
            this.label8.Text = "Số Giờ Tham Gia:";
            // 
            // txtSoGioTG
            // 
            this.txtSoGioTG.Location = new System.Drawing.Point(540, 157);
            this.txtSoGioTG.Name = "txtSoGioTG";
            this.txtSoGioTG.Size = new System.Drawing.Size(200, 20);
            this.txtSoGioTG.TabIndex = 14;
            // 
            // btnThem
            // 
            this.btnThem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnThem.Location = new System.Drawing.Point(320, 235);
            this.btnThem.Name = "btnThem";
            this.btnThem.Size = new System.Drawing.Size(90, 35);
            this.btnThem.TabIndex = 15;
            this.btnThem.Text = "Thêm";
            this.btnThem.UseVisualStyleBackColor = true;
            this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
            // 
            // btnXoa
            // 
            this.btnXoa.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);
            this.btnXoa.Location = new System.Drawing.Point(450, 235);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(90, 35);
            this.btnXoa.TabIndex = 16;
            this.btnXoa.Text = "Xóa";
            this.btnXoa.UseVisualStyleBackColor = true;
            this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
            // 
            // dataGridViewPT
            // 
            this.dataGridViewPT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPT.Location = new System.Drawing.Point(30, 290);
            this.dataGridViewPT.Name = "dataGridViewPT";
            this.dataGridViewPT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewPT.Size = new System.Drawing.Size(810, 230);
            this.dataGridViewPT.TabIndex = 17;
            this.dataGridViewPT.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewPT_CellClick);
            // 
            // FrmPhuTroi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(870, 540);
            this.Controls.Add(this.dataGridViewPT);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.txtSoGioTG);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.cbMaNV);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtHeSo);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtSoGioPT);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cbHinhThuc);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtpNgayPhuTroi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSoPhieu);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FrmPhuTroi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Giờ Phụ Trội - Sơn Đông Á";
            this.Load += new System.EventHandler(this.FrmPhuTroi_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPT)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSoPhieu;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtpNgayPhuTroi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cbHinhThuc;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtSoGioPT;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtHeSo;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cbMaNV;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSoGioTG;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnXoa;
        private System.Windows.Forms.DataGridView dataGridViewPT;
    }
}