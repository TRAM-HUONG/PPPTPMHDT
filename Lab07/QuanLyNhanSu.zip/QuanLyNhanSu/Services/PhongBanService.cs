﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class PhongBanService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        public DataTable GetAllPhongBan()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM PhongBan";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public bool InsertPhongBan(string maPB, string tenPB, string dienThoai)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO PhongBan (MaPhongBan, TenPhongBan, DienThoaiPhongBan) VALUES (@MaPB, @TenPB, @DienThoai)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaPB", maPB);
                    cmd.Parameters.AddWithValue("@TenPB", tenPB);
                    cmd.Parameters.AddWithValue("@DienThoai", dienThoai);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool UpdatePhongBan(string maPB, string tenPB, string dienThoai)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE PhongBan SET TenPhongBan = @TenPB, DienThoaiPhongBan = @DienThoai WHERE MaPhongBan = @MaPB";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaPB", maPB);
                    cmd.Parameters.AddWithValue("@TenPB", tenPB);
                    cmd.Parameters.AddWithValue("@DienThoai", dienThoai);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool DeletePhongBan(string maPB)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM PhongBan WHERE MaPhongBan = @MaPB";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaPB", maPB);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}