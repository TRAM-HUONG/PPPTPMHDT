﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class TinhLuongService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Tổng hợp bảng lương hằng tháng dựa trên Lương cơ bản, Số giờ làm việc và Giờ phụ trội
        public DataTable TinhBangLuongThang()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // Câu lệnh truy vấn kết hợp các bảng để tính toán tổng lương thực tế
                string query = @"SELECT 
                                    nv.MaNV, 
                                    nv.HoTen, 
                                    ISNULL(qdl.MucLuongCoBan, 0) AS MucLuongCoBan,
                                    ISNULL(cc.SoGioLamViec, 0) AS SoGioLamViec,
                                    ISNULL(pt.SoGioPhuTroiThamGia, 0) AS SoGioPhuTroi,
                                    ISNULL(kt.SoTienKhenThuong_KyLuatCaNhan, 0) AS TienThuongPhat,
                                    -- Công thức tính lương tạm tính (Lương CB / 160 giờ chuẩn * số giờ làm + phụ trội hệ số 1.5 + thưởng phạt)
                                    (ISNULL(qdl.MucLuongCoBan, 0) / 160 * ISNULL(cc.SoGioLamViec, 0) + 
                                     (ISNULL(qdl.MucLuongCoBan, 0) / 160 * 1.5 * ISNULL(pt.SoGioPhuTroiThamGia, 0)) + 
                                     ISNULL(kt.SoTienKhenThuong_KyLuatCaNhan, 0)) AS ThucLinh
                                 FROM NhanVien nv
                                 LEFT JOIN QuyetDinhLuong qdl ON nv.MaNV = qdl.MaNV
                                 LEFT JOIN ChiTietBangChamCong cc ON nv.MaNV = cc.MaNV
                                 LEFT JOIN ChiTietPhieuPhuTroi pt ON nv.MaNV = pt.MaNV
                                 LEFT JOIN KhenThuong_KyLuatCaNhan kt ON nv.MaNV = kt.MaNV";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }
    }
}