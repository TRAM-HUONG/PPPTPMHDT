﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class ChamCongService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy danh sách bảng chấm công tổng hợp
        public DataTable GetAllBangChamCong()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM BangChamCong";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm bảng chấm công mới
        public bool InsertBangChamCong(string maBCC, DateTime tuNgay, DateTime denNgay)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO BangChamCong (MaBangChamCong, TuNgay, DenNgay) VALUES (@MaBCC, @TuNgay, @DenNgay)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaBCC", maBCC);
                    cmd.Parameters.AddWithValue("@TuNgay", tuNgay);
                    cmd.Parameters.AddWithValue("@DenNgay", denNgay);

                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Xóa bảng chấm công
        public bool DeleteBangChamCong(string maBCC)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM BangChamCong WHERE MaBangChamCong = @MaBCC";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaBCC", maBCC);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}