﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class KhenThuongKyLuatService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy danh sách khen thưởng kỷ luật cá nhân
        public DataTable GetKhenThuongKyLuatCaNhan()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"SELECT kt.SoQuyetDinhKhenThuong_KyLuat, qd.NgayQuyetDinh, qd.NoiDungQuyetDinh, 
                                        kt.MaNV, nv.HoTen, kt.SoTienKhenThuong_KyLuatCaNhan
                                 FROM KhenThuong_KyLuatCaNhan kt
                                 JOIN QuyetDinhKhenThuong_KyLuat qd ON kt.SoQuyetDinhKhenThuong_KyLuat = qd.SoQuyetDinhKhenThuong_KyLuat
                                 JOIN NhanVien nv ON kt.MaNV = nv.MaNV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Nhân viên
        public DataTable GetDanhSachNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaNV, HoTen FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm quyết định khen thưởng / kỷ luật cá nhân
        public bool InsertKTKL_CaNhan(string soQD, DateTime ngayQD, string noiDung, string maNV, decimal soTien)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // 1. Thêm vào bảng chung QuyetDinhKhenThuong_KyLuat (nếu chưa có)
                    string query1 = @"IF NOT EXISTS (SELECT 1 FROM QuyetDinhKhenThuong_KyLuat WHERE SoQuyetDinhKhenThuong_KyLuat = @SoQD)
                                      BEGIN
                                          INSERT INTO QuyetDinhKhenThuong_KyLuat (SoQuyetDinhKhenThuong_KyLuat, NgayQuyetDinh, NoiDungQuyetDinh) 
                                          VALUES (@SoQD, @NgayQD, @NoiDung)
                                      END";
                    using (SqlCommand cmd1 = new SqlCommand(query1, conn, transaction))
                    {
                        cmd1.Parameters.AddWithValue("@SoQD", soQD);
                        cmd1.Parameters.AddWithValue("@NgayQD", ngayQD);
                        cmd1.Parameters.AddWithValue("@NoiDung", noiDung);
                        cmd1.ExecuteNonQuery();
                    }

                    // 2. Thêm vào bảng KhenThuong_KyLuatCaNhan
                    string query2 = @"INSERT INTO KhenThuong_KyLuatCaNhan (SoQuyetDinhKhenThuong_KyLuat, MaNV, SoTienKhenThuong_KyLuatCaNhan) 
                                      VALUES (@SoQD, @MaNV, @SoTien)";
                    using (SqlCommand cmd2 = new SqlCommand(query2, conn, transaction))
                    {
                        cmd2.Parameters.AddWithValue("@SoQD", soQD);
                        cmd2.Parameters.AddWithValue("@MaNV", maNV);
                        cmd2.Parameters.AddWithValue("@SoTien", soTien);
                        cmd2.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return true;
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        // Xóa quyết định khen thưởng / kỷ luật cá nhân
        public bool DeleteKTKL_CaNhan(string soQD, string maNV)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM KhenThuong_KyLuatCaNhan WHERE SoQuyetDinhKhenThuong_KyLuat = @SoQD AND MaNV = @MaNV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoQD", soQD);
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}