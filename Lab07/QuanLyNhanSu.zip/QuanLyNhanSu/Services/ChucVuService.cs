﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class ChucVuService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        public DataTable GetAllChucVu()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM ChucVu";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        public bool InsertChucVu(string maCV, string tenCV, float heSoLuong, decimal phuCapCV)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO ChucVu (MaChucVu, TenChucVu, HeSoLuong, PhuCapChucVu) VALUES (@MaCV, @TenCV, @HeSo, @PhuCap)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaCV", maCV);
                    cmd.Parameters.AddWithValue("@TenCV", tenCV);
                    cmd.Parameters.AddWithValue("@HeSo", heSoLuong);
                    cmd.Parameters.AddWithValue("@PhuCap", phuCapCV);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool UpdateChucVu(string maCV, string tenCV, float heSoLuong, decimal phuCapCV)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE ChucVu SET TenChucVu = @TenCV, HeSoLuong = @HeSo, PhuCapChucVu = @PhuCap WHERE MaChucVu = @MaCV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaCV", maCV);
                    cmd.Parameters.AddWithValue("@TenCV", tenCV);
                    cmd.Parameters.AddWithValue("@HeSo", heSoLuong);
                    cmd.Parameters.AddWithValue("@PhuCap", phuCapCV);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        public bool DeleteChucVu(string maCV)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM ChucVu WHERE MaChucVu = @MaCV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaCV", maCV);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}