﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class PhuTroiService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy danh sách chi tiết phiếu phụ trội kèm tên nhân viên
        public DataTable GetAllPhuTroi()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"SELECT ct.SoPhieuGhiNhanPhuTroi, pt.NgayPhuTroi, pt.HinhThucPhuTroi, 
                                        pt.SoGioPhuTroi, pt.HeSoPhuTroi, ct.MaNV, nv.HoTen, ct.SoGioPhuTroiThamGia
                                 FROM ChiTietPhieuPhuTroi ct
                                 JOIN PhieuGhiNhanPhuTroi pt ON ct.SoPhieuGhiNhanPhuTroi = pt.SoPhieuGhiNhanPhuTroi
                                 JOIN NhanVien nv ON ct.MaNV = nv.MaNV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Nhân viên
        public DataTable GetDanhSachNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaNV, HoTen FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm phiếu phụ trội và chi tiết phụ trội theo nhân viên
        public bool InsertPhuTroi(string soPhieu, DateTime ngayPhuTroi, string hinhThuc, float soGioPT, float heSo, string maNV, float soGioTG)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // 1. Thêm vào bảng PhieuGhiNhanPhuTroi (Kiểm tra nếu phiếu chưa tồn tại)
                    string query1 = @"IF NOT EXISTS (SELECT 1 FROM PhieuGhiNhanPhuTroi WHERE SoPhieuGhiNhanPhuTroi = @SoPhieu)
                                      BEGIN
                                          INSERT INTO PhieuGhiNhanPhuTroi (SoPhieuGhiNhanPhuTroi, NgayPhuTroi, HinhThucPhuTroi, SoGioPhuTroi, HeSoPhuTroi) 
                                          VALUES (@SoPhieu, @NgayPhuTroi, @HinhThuc, @SoGioPT, @HeSo)
                                      END";
                    using (SqlCommand cmd1 = new SqlCommand(query1, conn, transaction))
                    {
                        cmd1.Parameters.AddWithValue("@SoPhieu", soPhieu);
                        cmd1.Parameters.AddWithValue("@NgayPhuTroi", ngayPhuTroi);
                        cmd1.Parameters.AddWithValue("@HinhThuc", hinhThuc);
                        cmd1.Parameters.AddWithValue("@SoGioPT", soGioPT);
                        cmd1.Parameters.AddWithValue("@HeSo", heSo);
                        cmd1.ExecuteNonQuery();
                    }

                    // 2. Thêm vào bảng ChiTietPhieuPhuTroi
                    string query2 = @"INSERT INTO ChiTietPhieuPhuTroi (MaNV, SoPhieuGhiNhanPhuTroi, SoGioPhuTroiThamGia) 
                                      VALUES (@MaNV, @SoPhieu, @SoGioTG)";
                    using (SqlCommand cmd2 = new SqlCommand(query2, conn, transaction))
                    {
                        cmd2.Parameters.AddWithValue("@MaNV", maNV);
                        cmd2.Parameters.AddWithValue("@SoPhieu", soPhieu);
                        cmd2.Parameters.AddWithValue("@SoGioTG", soGioTG);
                        cmd2.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return true;
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }
        }

        // Xóa chi tiết phụ trội
        public bool DeletePhuTroi(string soPhieu, string maNV)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM ChiTietPhieuPhuTroi WHERE SoPhieuGhiNhanPhuTroi = @SoPhieu AND MaNV = @MaNV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoPhieu", soPhieu);
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}