﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class BaoHiemService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy danh sách sổ bảo hiểm nhân viên kèm tên nhân viên và loại bảo hiểm
        public DataTable GetAllSoBaoHiem()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"SELECT sbh.*, nv.HoTen, bh.TenBaoHiem, bh.PhanTramBaoHiem 
                                 FROM SoBaoHiem sbh
                                 JOIN NhanVien nv ON sbh.MaNV = nv.MaNV
                                 JOIN BaoHiem bh ON sbh.MaBaoHiem = bh.MaBaoHiem";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Nhân viên
        public DataTable GetDanhSachNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaNV, HoTen FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Loại Bảo hiểm
        public DataTable GetDanhSachBaoHiem()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaBaoHiem, TenBaoHiem FROM BaoHiem";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm sổ bảo hiểm mới
        public bool InsertSoBaoHiem(string maSoBH, DateTime ngayLap, string thoiHan, string maNV, string maBH)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"INSERT INTO SoBaoHiem (MaSoBaoHiem, NgayLapSoBaoHiem, ThoiHanSoBaoHiem, MaNV, MaBaoHiem) 
                                 VALUES (@MaSoBH, @NgayLap, @ThoiHan, @MaNV, @MaBH)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaSoBH", maSoBH);
                    cmd.Parameters.AddWithValue("@NgayLap", ngayLap);
                    cmd.Parameters.AddWithValue("@ThoiHan", thoiHan);
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    cmd.Parameters.AddWithValue("@MaBH", maBH);

                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Xóa sổ bảo hiểm
        public bool DeleteSoBaoHiem(string maSoBH)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM SoBaoHiem WHERE MaSoBaoHiem = @MaSoBH";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaSoBH", maSoBH);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}