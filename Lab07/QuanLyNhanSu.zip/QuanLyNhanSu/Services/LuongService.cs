﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class LuongService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy danh sách quyết định lương kèm thông tin nhân viên
        public DataTable GetAllQuyetDinhLuong()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"SELECT qdl.*, nv.HoTen 
                                 FROM QuyetDinhLuong qdl
                                 JOIN NhanVien nv ON qdl.MaNV = nv.MaNV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Nhân viên
        public DataTable GetDanhSachNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaNV, HoTen FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm quyết định lương
        public bool InsertQuyetDinhLuong(string soQDL, DateTime ngayQDL, decimal mucLuongCB, string maNV)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"INSERT INTO QuyetDinhLuong (SoQuyetDinhLuong, NgayQuyetDinhLuong, MucLuongCoBan, MaNV) 
                                 VALUES (@SoQDL, @NgayQDL, @MucLuongCB, @MaNV)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoQDL", soQDL);
                    cmd.Parameters.AddWithValue("@NgayQDL", ngayQDL);
                    cmd.Parameters.AddWithValue("@MucLuongCB", mucLuongCB);
                    cmd.Parameters.AddWithValue("@MaNV", maNV);

                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Xóa quyết định lương
        public bool DeleteQuyetDinhLuong(string soQDL)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM QuyetDinhLuong WHERE SoQuyetDinhLuong = @SoQDL";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoQDL", soQDL);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}