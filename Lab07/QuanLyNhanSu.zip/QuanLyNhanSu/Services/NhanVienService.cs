﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class NhanVienService
    {
        // Chuỗi kết nối đến SQL Server (Thay đổi tên Server tùy theo máy của bạn)
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy toàn bộ danh sách nhân viên
        public DataTable GetAllNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT * FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm nhân viên mới
        public bool InsertNhanVien(string maNV, string hoTen, string phai, DateTime ngaySinh, string diaChi, string dienThoai)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "INSERT INTO NhanVien (MaNV, HoTen, Phai, NgaySinh, DiaChiNV, DienThoaiNV) VALUES (@MaNV, @HoTen, @Phai, @NgaySinh, @DiaChi, @DienThoai)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    cmd.Parameters.AddWithValue("@HoTen", hoTen);
                    cmd.Parameters.AddWithValue("@Phai", phai);
                    cmd.Parameters.AddWithValue("@NgaySinh", ngaySinh);
                    cmd.Parameters.AddWithValue("@DiaChi", diaChi);
                    cmd.Parameters.AddWithValue("@DienThoai", dienThoai);

                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Cập nhật thông tin nhân viên
        public bool UpdateNhanVien(string maNV, string hoTen, string phai, DateTime ngaySinh, string diaChi, string dienThoai)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "UPDATE NhanVien SET HoTen = @HoTen, Phai = @Phai, NgaySinh = @NgaySinh, DiaChiNV = @DiaChi, DienThoaiNV = @DienThoai WHERE MaNV = @MaNV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    cmd.Parameters.AddWithValue("@HoTen", hoTen);
                    cmd.Parameters.AddWithValue("@Phai", phai);
                    cmd.Parameters.AddWithValue("@NgaySinh", ngaySinh);
                    cmd.Parameters.AddWithValue("@DiaChi", diaChi);
                    cmd.Parameters.AddWithValue("@DienThoai", dienThoai);

                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Xóa nhân viên
        public bool DeleteNhanVien(string maNV)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM NhanVien WHERE MaNV = @MaNV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}