﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class PhanCongService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy danh sách kế hoạch phân công kèm thông tin nhân viên và phòng ban
        public DataTable GetAllPhanCong()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                // Ở đây chúng ta liên kết bảng BangChamCong và ChiTietBangChamCong làm nền tảng phân công
                string query = @"SELECT ct.MaNV, nv.HoTen, bcc.MaBangChamCong, bcc.TuNgay, bcc.DenNgay, ct.SoGioLamViec 
                                 FROM ChiTietBangChamCong ct
                                 JOIN NhanVien nv ON ct.MaNV = nv.MaNV
                                 JOIN BangChamCong bcc ON ct.MaBangChamCong = bcc.MaBangChamCong";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Nhân viên
        public DataTable GetDanhSachNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaNV, HoTen FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Bảng chấm công / Kỳ phân công
        public DataTable GetDanhSachBangChamCong()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaBangChamCong, TuNgay, DenNgay FROM BangChamCong";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm kế hoạch phân công (Ghi nhận vào ChiTietBangChamCong)
        public bool InsertPhanCong(string maNV, string maBCC, float soGio)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"INSERT INTO ChiTietBangChamCong (MaNV, MaBangChamCong, SoGioLamViec) 
                                 VALUES (@MaNV, @MaBCC, @SoGio)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    cmd.Parameters.AddWithValue("@MaBCC", maBCC);
                    cmd.Parameters.AddWithValue("@SoGio", soGio);

                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Xóa phân công
        public bool DeletePhanCong(string maNV, string maBCC)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM ChiTietBangChamCong WHERE MaNV = @MaNV AND MaBangChamCong = @MaBCC";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    cmd.Parameters.AddWithValue("@MaBCC", maBCC);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}