﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class HopDongService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy danh sách hợp đồng kèm tên nhân viên và loại hợp đồng
        public DataTable GetAllHopDong()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"SELECT hd.*, nv.HoTen, lhd.TenLoaiHopDong 
                                 FROM HopDong hd
                                 JOIN NhanVien nv ON hd.MaNV = nv.MaNV
                                 JOIN LoaiHopDong lhd ON hd.MaLoaiHopDong = lhd.MaLoaiHopDong";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Nhân viên
        public DataTable GetDanhSachNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaNV, HoTen FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Loại hợp đồng
        public DataTable GetDanhSachLoaiHopDong()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaLoaiHopDong, TenLoaiHopDong FROM LoaiHopDong";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm hợp đồng lao động
        public bool InsertHopDong(string soHD, DateTime ngayLap, string noiDung, string maLoaiHD, string maNV)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"INSERT INTO HopDong (SoHopDong, NgayLapHopDong, NoiDungHopDong, MaLoaiHopDong, MaNV) 
                                 VALUES (@SoHD, @NgayLap, @NoiDung, @MaLoaiHD, @MaNV)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoHD", soHD);
                    cmd.Parameters.AddWithValue("@NgayLap", ngayLap);
                    cmd.Parameters.AddWithValue("@NoiDung", noiDung);
                    cmd.Parameters.AddWithValue("@MaLoaiHD", maLoaiHD);
                    cmd.Parameters.AddWithValue("@MaNV", maNV);

                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Xóa hợp đồng lao động
        public bool DeleteHopDong(string soHD)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM HopDong WHERE SoHopDong = @SoHD";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoHD", soHD);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}