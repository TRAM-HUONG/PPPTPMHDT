﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyNhanSu.Services
{
    public class TuyenDungService
    {
        private string connString = "Server=localhost;Database=QL_NhanSu_SonDongA;Trusted_Connection=True;";

        // Lấy danh sách quyết định tuyển dụng kèm tên nhân viên và phòng ban
        public DataTable GetAllQuyetDinhTuyenDung()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"SELECT qd.*, nv.HoTen, pb.TenPhongBan 
                                 FROM QuyetDinhTuyenDung qd
                                 JOIN NhanVien nv ON qd.MaNV = nv.MaNV
                                 JOIN PhongBan pb ON qd.MaPhongBan = pb.MaPhongBan";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Nhân viên để đổ vào ComboBox
        public DataTable GetDanhSachNhanVien()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaNV, HoTen FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Lấy danh sách Phòng ban để đổ vào ComboBox
        public DataTable GetDanhSachPhongBan()
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "SELECT MaPhongBan, TenPhongBan FROM PhongBan";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        return dt;
                    }
                }
            }
        }

        // Thêm quyết định tuyển dụng
        public bool InsertQuyetDinh(string soQD, DateTime ngayQD, int thoiGianTV, decimal mucLuongTV, string noiDung, string maNV, string maPB)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = @"INSERT INTO QuyetDinhTuyenDung (SoQuyetDinhTuyenDung, NgayQuyetDinhTuyenDung, ThoiGianThuViec, MucLuongThuViec, NoiDungQuyetDinh, MaNV, MaPhongBan) 
                                 VALUES (@SoQD, @NgayQD, @ThoiGianTV, @MucLuongTV, @NoiDung, @MaNV, @MaPB)";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoQD", soQD);
                    cmd.Parameters.AddWithValue("@NgayQD", ngayQD);
                    cmd.Parameters.AddWithValue("@ThoiGianTV", thoiGianTV);
                    cmd.Parameters.AddWithValue("@MucLuongTV", mucLuongTV);
                    cmd.Parameters.AddWithValue("@NoiDung", noiDung);
                    cmd.Parameters.AddWithValue("@MaNV", maNV);
                    cmd.Parameters.AddWithValue("@MaPB", maPB);

                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }

        // Xóa quyết định tuyển dụng
        public bool DeleteQuyetDinh(string soQD)
        {
            using (SqlConnection conn = new SqlConnection(connString))
            {
                string query = "DELETE FROM QuyetDinhTuyenDung WHERE SoQuyetDinhTuyenDung = @SoQD";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@SoQD", soQD);
                    conn.Open();
                    return cmd.ExecuteNonQuery() > 0;
                }
            }
        }
    }
}