﻿using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhNhan.Data;

namespace QuanLyHoSoBenhNhan.Services
{
    public class TraCuuService
    {
        // Tra cứu thông tin hồ sơ và lịch sử khám bệnh theo Mã hồ sơ hoặc Mã bệnh nhân
        public DataTable TraCuuHoSoVaLichSu(string tuKhoa)
        {
            string query = @"
                SELECT 
                    hs.MaHoSo, 
                    bn.MaBenhNhan, 
                    bn.HoTen, 
                    bn.NgaySinh, 
                    bn.DienThoai, 
                    hs.NgayLap, 
                    hs.TrangThaiLePhi,
                    pk.MaPhieuKham,
                    pk.NgayGioKham,
                    bs.HoTen AS TenBacSi,
                    k.TenKhoa,
                    pk.TrieuChung,
                    pk.LoaiKham
                FROM HoSoBenhAn hs
                JOIN BenhNhan bn ON hs.MaBenhNhan = bn.MaBenhNhan
                LEFT JOIN PhieuKhamBenh pk ON hs.MaHoSo = pk.MaHoSo
                LEFT JOIN BacSi bs ON pk.MaBacSi = bs.MaBacSi
                LEFT JOIN KhoaDieuTri k ON bs.MaKhoa = k.MaKhoa
                WHERE hs.MaHoSo LIKE @TuKhoa OR bn.MaBenhNhan LIKE @TuKhoa OR bn.HoTen LIKE @TuKhoa";

            SqlParameter[] parameters = {
                new SqlParameter("@TuKhoa", "%" + tuKhoa + "%")
            };

            return Db.Query(query, parameters);
        }
    }
}