﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhNhan.Data;

namespace QuanLyHoSoBenhNhan.Services
{
    public class KhamBenhService
    {
        // 1. Tra cứu lịch sử bệnh án theo mã hồ sơ
        public DataTable TraCuuLichSuBenhAn(string maHoSo)
        {
            string query = @"
                SELECT 
                    pk.MaPhieuKham, 
                    pk.MaHoSo, 
                    bs.HoTen AS TenBacSi, 
                    pk.NgayGioKham, 
                    pk.TrieuChung, 
                    pk.LoaiKham 
                FROM PhieuKhamBenh pk
                JOIN BacSi bs ON pk.MaBacSi = bs.MaBacSi
                WHERE pk.MaHoSo = @MaHoSo";

            SqlParameter[] parameters = {
                new SqlParameter("@MaHoSo", maHoSo)
            };

            return Db.Query(query, parameters);
        }

        // 2. Lưu thông tin phiếu khám bệnh (Bác sĩ thực hiện khám & chẩn đoán)
        public KetQuaXuLy LuuPhieuKham(string maPhieuKham, string maHoSo, string maBacSi, DateTime ngayGioKham, string trieuChung, string loaiKham)
        {
            if (string.IsNullOrEmpty(maPhieuKham) || string.IsNullOrEmpty(maHoSo) || string.IsNullOrEmpty(maBacSi))
            {
                return KetQuaXuLy.ThatBai("Mã phiếu khám, mã hồ sơ và mã bác sĩ không được để trống!");
            }

            try
            {
                string query = @"
                    INSERT INTO PhieuKhamBenh (MaPhieuKham, MaHoSo, MaBacSi, NgayGioKham, TrieuChung, LoaiKham) 
                    VALUES (@MaPhieuKham, @MaHoSo, @MaBacSi, @NgayGioKham, @TrieuChung, @LoaiKham)";

                SqlParameter[] parameters = {
                    new SqlParameter("@MaPhieuKham", maPhieuKham),
                    new SqlParameter("@MaHoSo", maHoSo),
                    new SqlParameter("@MaBacSi", maBacSi),
                    new SqlParameter("@NgayGioKham", ngayGioKham),
                    new SqlParameter("@TrieuChung", (object)trieuChung ?? DBNull.Value),
                    new SqlParameter("@LoaiKham", (object)loaiKham ?? "Khám thường")
                };

                int rows = Db.Execute(query, parameters);
                if (rows > 0)
                {
                    return KetQuaXuLy.ThnahCong("Lưu phiếu khám bệnh thành công!");
                }
                return KetQuaXuLy.ThatBai("Không thể lưu phiếu khám vào cơ sở dữ liệu.");
            }
            catch (Exception ex)
            {
                return KetQuaXuLy.ThatBai("Lỗi hệ thống: " + ex.Message);
            }
        }
    }
}