﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhNhan.Data;

namespace QuanLyHoSoBenhNhan.Services
{
    public class ToaThuocService
    {
        // 1. Lấy danh mục thuốc từ kho để bác sĩ chọn kê toa
        public DataTable LayDanhSachThuoc()
        {
            string query = "SELECT MaThuoc, TenThuoc, DonViTinh, DonGia, SoLuongTon FROM Thuoc";
            return Db.Query(query);
        }

        // 2. Xử lý logic lập toa thuốc và lưu chi tiết toa thuốc bằng Transaction
        public KetQuaXuLy LapToaThuoc(string maToaThuoc, string maPhieuKham, DateTime ngayLap, string loiDan, DataTable dtChiTiet)
        {
            if (string.IsNullOrEmpty(maToaThuoc) || string.IsNullOrEmpty(maPhieuKham))
            {
                return KetQuaXuLy.ThatBai("Mã toa thuốc và mã phiếu khám không được để trống!");
            }

            if (dtChiTiet == null || dtChiTiet.Rows.Count == 0)
            {
                return KetQuaXuLy.ThatBai("Toa thuốc phải có ít nhất một loại thuốc!");
            }

            using (SqlConnection conn = Db.OpenConnection())
            {
                SqlTransaction transaction = conn.BeginTransaction();

                try
                {
                    // Thêm thông tin Toa Thuốc
                    string queryToaThuoc = "INSERT INTO ToaThuoc (MaToaThuoc, MaPhieuKham, NgayLap, LoiDan) VALUES (@MaToaThuoc, @MaPhieuKham, @NgayLap, @LoiDan)";
                    using (SqlCommand cmd = new SqlCommand(queryToaThuoc, conn, transaction))
                    {
                        cmd.Parameters.AddWithValue("@MaToaThuoc", maToaThuoc);
                        cmd.Parameters.AddWithValue("@MaPhieuKham", maPhieuKham);
                        cmd.Parameters.AddWithValue("@NgayLap", ngayLap);
                        cmd.Parameters.AddWithValue("@LoiDan", (object)loiDan ?? DBNull.Value);
                        cmd.ExecuteNonQuery();
                    }

                    // Thêm danh sách Chi Tiết Toa Thuốc
                    foreach (DataRow row in dtChiTiet.Rows)
                    {
                        string maChiTiet = row["MaChiTiet"].ToString();
                        string maThuoc = row["MaThuoc"].ToString();
                        int soLuong = Convert.ToInt32(row["SoLuong"]);
                        string lieuDung = row["LieuDung"].ToString();

                        string queryChiTiet = "INSERT INTO ChiTietToaThuoc (MaChiTiet, MaToaThuoc, MaThuoc, SoLuong, LieuDung) VALUES (@MaChiTiet, @MaToaThuoc, @MaThuoc, @SoLuong, @LieuDung)";
                        using (SqlCommand cmdChiTiet = new SqlCommand(queryChiTiet, conn, transaction))
                        {
                            cmdChiTiet.Parameters.AddWithValue("@MaChiTiet", maChiTiet);
                            cmdChiTiet.Parameters.AddWithValue("@MaToaThuoc", maToaThuoc);
                            cmdChiTiet.Parameters.AddWithValue("@MaThuoc", maThuoc);
                            cmdChiTiet.Parameters.AddWithValue("@SoLuong", soLuong);
                            cmdChiTiet.Parameters.AddWithValue("@LieuDung", lieuDung);
                            cmdChiTiet.ExecuteNonQuery();
                        }
                    }

                    transaction.Commit();
                    return KetQuaXuLy.ThnahCong("Lập toa thuốc thành công!");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return KetQuaXuLy.ThatBai("Lỗi khi lập toa thuốc: " + ex.Message);
                }
            }
        }
    }
}