﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhNhan.Data;

namespace QuanLyHoSoBenhNhan.Services
{
    public class XetNghiemService
    {
        // 1. Lấy danh sách xét nghiệm (chưa có kết quả hoặc toàn bộ danh sách chỉ định)
        public DataTable LayDanhSachXetNghiem()
        {
            string query = @"
                SELECT 
                    xn.MaXetNghiem, 
                    xn.MaPhieuKham, 
                    pk.MaHoSo,
                    xn.TenXetNghiem, 
                    xn.KetQua, 
                    xn.NgayXetNghiem 
                FROM XetNghiem xn
                JOIN PhieuKhamBenh pk ON xn.MaPhieuKham = pk.MaPhieuKham";

            return Db.Query(query);
        }

        // 2. Cập nhật kết quả xét nghiệm (Nhân viên xét nghiệm thực hiện)
        public KetQuaXuLy CapNhatKetQuaXetNghiem(string maXetNghiem, string ketQua, DateTime ngayXetNghiem)
        {
            if (string.IsNullOrEmpty(maXetNghiem))
            {
                return KetQuaXuLy.ThatBai("Mã xét nghiệm không được để trống!");
            }

            try
            {
                string query = @"
                    UPDATE XetNghiem 
                    SET KetQua = @KetQua, NgayXetNghiem = @NgayXetNghiem 
                    WHERE MaXetNghiem = @MaXetNghiem";

                SqlParameter[] parameters = {
                    new SqlParameter("@MaXetNghiem", maXetNghiem),
                    new SqlParameter("@KetQua", (object)ketQua ?? DBNull.Value),
                    new SqlParameter("@NgayXetNghiem", ngayXetNghiem)
                };

                int rows = Db.Execute(query, parameters);
                if (rows > 0)
                {
                    return KetQuaXuLy.ThnahCong("Cập nhật kết quả xét nghiệm thành công!");
                }
                return KetQuaXuLy.ThatBai("Không tìm thấy mã xét nghiệm để cập nhật.");
            }
            catch (Exception ex)
            {
                return KetQuaXuLy.ThatBai("Lỗi hệ thống: " + ex.Message);
            }
        }
    }
}