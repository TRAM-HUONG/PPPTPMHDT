﻿using System;
using System.Data.SqlClient;
using QuanLyHoSoBenhNhan.Data;
using QuanLyHoSoBenhNhan.Services;


namespace QuanLyHoSoBenhNhan.Services
{
    public class BenhNhanService
    {
        public KetQuaXuLy DangKyVaCapHoSo(string maBenhNhan, string hoTen, string diaChi, DateTime ngaySinh, string dienThoai, string anh3x4)
        {
            if (string.IsNullOrEmpty(maBenhNhan) || string.IsNullOrEmpty(hoTen))
            {
                return KetQuaXuLy.ThatBai("Mã bệnh nhân và họ tên không được để trống!");
            }

            try
            {
                // Bước 1: Thêm bệnh nhân mới vào bảng BenhNhan
                string queryBenhNhan = "INSERT INTO BenhNhan (MaBenhNhan, HoTen, DiaChi, NgaySinh, DienThoai, Anh3x4) " +
                                       "VALUES (@MaBenhNhan, @HoTen, @DiaChi, @NgaySinh, @DienThoai, @Anh3x4)";
                SqlParameter[] pBenhNhan = {
                    new SqlParameter("@MaBenhNhan", maBenhNhan),
                    new SqlParameter("@HoTen", hoTen),
                    new SqlParameter("@DiaChi", (object)diaChi ?? DBNull.Value),
                    new SqlParameter("@NgaySinh", ngaySinh),
                    new SqlParameter("@DienThoai", (object)dienThoai ?? DBNull.Value),
                    new SqlParameter("@Anh3x4", (object)anh3x4 ?? DBNull.Value)
                };

                int rowBN = Db.Execute(queryBenhNhan, pBenhNhan);
                if (rowBN <= 0) return KetQuaXuLy.ThatBai("Không thể thêm thông tin bệnh nhân.");

                // Bước 2: Tự động cấp Hồ sơ bệnh án (HS + Mã bệnh nhân) và ghi nhận đã đóng lệ phí năm (BR01)
                string maHoSo = "HS_" + maBenhNhan;
                string queryHoSo = "INSERT INTO HoSoBenhAn (MaHoSo, MaBenhNhan, NgayLap, TrangThaiLePhi) " +
                                   "VALUES (@MaHoSo, @MaBenhNhan, @NgayLap, N'Đã đóng')";
                SqlParameter[] pHoSo = {
                    new SqlParameter("@MaHoSo", maHoSo),
                    new SqlParameter("@MaBenhNhan", maBenhNhan),
                    new SqlParameter("@NgayLap", DateTime.Now)
                };

                int rowHS = Db.Execute(queryHoSo, pHoSo);
                if (rowHS > 0)
                {
                    return KetQuaXuLy.ThnahCong($"Đăng ký thành công! Đã cấp mã hồ sơ: {maHoSo}");
                }

                return KetQuaXuLy.ThatBai("Đã thêm bệnh nhân nhưng lỗi khi cấp hồ sơ bệnh án.");
            }
            catch (Exception ex)
            {
                return KetQuaXuLy.ThatBai("Lỗi cơ sở dữ liệu: " + ex.Message);
            }
        }
    }
}