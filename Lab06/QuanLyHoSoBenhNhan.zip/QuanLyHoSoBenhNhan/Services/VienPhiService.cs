﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhNhan.Data;

namespace QuanLyHoSoBenhNhan.Services
{
    public class VienPhiService
    {
        // 1. Tính tổng tiền viện phí của đợt khám (bao gồm tiền khám, xét nghiệm và thuốc trong toa)
        public decimal TinhTongTienVienPhi(string maPhieuKham)
        {
            if (string.IsNullOrEmpty(maPhieuKham)) return 0;

            try
            {
                // Truy vấn tổng tiền thuốc trong toa của phiếu khám
                string queryThuoc = @"
                    SELECT ISNULL(SUM(ct.SoLuong * t.DonGia), 0) 
                    FROM ToaThuoc tt
                    JOIN ChiTietToaThuoc ct ON tt.MaToaThuoc = ct.MaToaThuoc
                    JOIN Thuoc t ON ct.MaThuoc = t.MaThuoc
                    WHERE tt.MaPhieuKham = @MaPhieuKham";

                SqlParameter[] parameters = { new SqlParameter("@MaPhieuKham", maPhieuKham) };
                object result = Db.Scalar(queryThuoc, parameters);

                decimal tienThuoc = result != null && result != DBNull.Value ? Convert.ToDecimal(result) : 0;

                // Giả định cộng thêm phí khám cơ bản (ví dụ: 100,000 VNĐ) và phí xét nghiệm nếu có
                decimal phiKhamCoBan = 100000;

                return tienThuoc + phiKhamCoBan;
            }
            catch (Exception)
            {
                return 0;
            }
        }

        // 2. Thanh toán viện phí, ghi nhận hóa đơn và hoàn tất xuất viện (BR04)
        public KetQuaXuLy ThanhToanVienPhi(string maHoaDon, string maPhieuKham, DateTime ngayThanhToan, decimal tongTien)
        {
            if (string.IsNullOrEmpty(maHoaDon) || string.IsNullOrEmpty(maPhieuKham))
            {
                return KetQuaXuLy.ThatBai("Mã hóa đơn và mã phiếu khám không được để trống!");
            }

            try
            {
                // Lưu thông tin hóa đơn thanh toán vào bảng HoaDon
                string queryHoaDon = @"
                    INSERT INTO HoaDon (MaHoaDon, MaPhieuKham, NgayThanhToan, TongTien) 
                    VALUES (@MaHoaDon, @MaPhieuKham, @NgayThanhToan, @TongTien)";

                SqlParameter[] parameters = {
                    new SqlParameter("@MaHoaDon", maHoaDon),
                    new SqlParameter("@MaPhieuKham", maPhieuKham),
                    new SqlParameter("@NgayThanhToan", ngayThanhToan),
                    new SqlParameter("@TongTien", tongTien)
                };

                int rows = Db.Execute(queryHoaDon, parameters);
                if (rows > 0)
                {
                    return KetQuaXuLy.ThnahCong("Thanh toán viện phí và hoàn tất thủ tục xuất viện thành công!");
                }

                return KetQuaXuLy.ThatBai("Không thể lưu thông tin hóa đơn vào cơ sở dữ liệu.");
            }
            catch (Exception ex)
            {
                return KetQuaXuLy.ThatBai("Lỗi hệ thống: " + ex.Message);
            }
        }
    }
}