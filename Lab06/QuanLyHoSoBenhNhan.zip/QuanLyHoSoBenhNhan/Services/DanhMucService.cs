﻿using QuanLyHoSoBenhNhan.Data; // Khớp với namespace của bạn
using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyHoSoBenhNhan.Services
{
    public class DanhMucService
    {
        public DataTable LayDanhSachKhoa()
        {
            string query = "SELECT MaKhoa, TenKhoa FROM KhoaDieuTri";
            return Db.Query(query); // Gọi trực tiếp hàm Query từ Data.cs
        }

        public DataTable LayDanhSachThuoc()
        {
            string query = "SELECT MaThuoc, TenThuoc, DonViTinh, DonGia, SoLuongTon FROM Thuoc";
            return Db.Query(query);
        }

        public KetQuaXuLy LuuKhoaDieuTri(string maKhoa, string tenKhoa)
        {
            if (string.IsNullOrEmpty(maKhoa) || string.IsNullOrEmpty(tenKhoa))
            {
                return KetQuaXuLy.ThatBai("Mã khoa và tên khoa không được để trống!");
            }

            try
            {
                string query = "IF EXISTS (SELECT 1 FROM KhoaDieuTri WHERE MaKhoa = @MaKhoa) " +
                               "UPDATE KhoaDieuTri SET TenKhoa = @TenKhoa WHERE MaKhoa = @MaKhoa " +
                               "ELSE " +
                               "INSERT INTO KhoaDieuTri (MaKhoa, TenKhoa) VALUES (@MaKhoa, @TenKhoa)";

                SqlParameter[] parameters = {
                    new SqlParameter("@MaKhoa", maKhoa),
                    new SqlParameter("@TenKhoa", tenKhoa)
                };

                int rows = Db.Execute(query, parameters); // Gọi trực tiếp hàm Execute từ Data.cs
                if (rows > 0)
                {
                    return KetQuaXuLy.ThnahCong("Lưu thông tin khoa điều trị thành công!");
                }
                return KetQuaXuLy.ThatBai("Không thể lưu thông tin vào cơ sở dữ liệu.");
            }
            catch (Exception ex)
            {
                return KetQuaXuLy.ThatBai("Lỗi hệ thống: " + ex.Message);
            }
        }
    }
}