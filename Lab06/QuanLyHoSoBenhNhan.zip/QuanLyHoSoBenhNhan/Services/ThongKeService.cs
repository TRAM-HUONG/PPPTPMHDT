﻿using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhNhan.Data;

namespace QuanLyHoSoBenhNhan.Services
{
    public class ThongKeService
    {
        // 1. Thống kê doanh thu viện phí theo hóa đơn
        public DataTable ThongKeDoanhThuVienPhi()
        {
            string query = @"
                SELECT 
                    hd.MaHoaDon, 
                    hd.MaPhieuKham, 
                    pk.MaHoSo, 
                    hd.NgayThanhToan, 
                    hd.TongTien 
                FROM HoaDon hd
                JOIN PhieuKhamBenh pk ON hd.MaPhieuKham = pk.MaPhieuKham";

            return  Db.Query(query);
        }

        // 2. Thống kê số lượng bệnh nhân và lượt khám theo bác sĩ/khoa
        public DataTable ThongKeLuotKhamTheoKhoa()
        {
            string query = @"
                SELECT 
                    k.MaKhoa, 
                    k.TenKhoa, 
                    COUNT(pk.MaPhieuKham) AS TongSoLuotKham 
                FROM KhoaDieuTri k
                LEFT JOIN BacSi bs ON k.MaKhoa = bs.MaKhoa
                LEFT JOIN PhieuKhamBenh pk ON bs.MaBacSi = pk.MaBacSi
                GROUP BY k.MaKhoa, k.TenKhoa";

            return Db.Query(query);
        }

        // 3. Thống kê kho thuốc tồn kho
        public DataTable ThongKeKhoThuoc()
        {
            string query = "SELECT MaThuoc, TenThuoc, DonViTinh, DonGia, SoLuongTon FROM Thuoc";
            return Db.Query(query);
        }
    }
}