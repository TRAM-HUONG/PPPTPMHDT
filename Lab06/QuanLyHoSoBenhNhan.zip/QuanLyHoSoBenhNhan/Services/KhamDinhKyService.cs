﻿using System;
using System.Data;
using System.Data.SqlClient;
using QuanLyHoSoBenhNhan.Data;

namespace QuanLyHoSoBenhNhan.Services
{
    public class KhamDinhKyService
    {
        // 1. Lấy danh sách hồ sơ bệnh án đủ điều kiện khám định kỳ
        public DataTable LayDanhSachHoSoDuDienKien()
        {
            string query = @"
                SELECT 
                    hs.MaHoSo, 
                    bn.MaBenhNhan, 
                    bn.HoTen, 
                    bn.DienThoai, 
                    hs.NgayLap, 
                    hs.TrangThaiLePhi 
                FROM HoSoBenhAn hs
                JOIN BenhNhan bn ON hs.MaBenhNhan = bn.MaBenhNhan
                WHERE hs.TrangThaiLePhi = N'Đã đóng'";

            return Db.Query(query);
        }

        // 2. Lấy danh sách bác sĩ thực tế từ CSDL để hiển thị lên ComboBox
        public DataTable LayDanhSachBacSi()
        {
            string query = "SELECT MaBacSi, HoTen, ChuyenKhoa FROM BacSi";
            return Db   .Query(query);
        }

        // 3. Đặt lịch hẹn khám định kỳ theo quý cho bệnh nhân với Mã bác sĩ chọn thực tế
        public KetQuaXuLy DatLichKhamDinhKy(string maHoSo, string maBacSi, DateTime ngayHen, string ghiChu)
        {
            if (string.IsNullOrEmpty(maHoSo))
            {
                return KetQuaXuLy.ThatBai("Mã hồ sơ không được để trống!");
            }

            if (string.IsNullOrEmpty(maBacSi))
            {
                return KetQuaXuLy.ThatBai("Vui lòng chọn bác sĩ phụ trách khám!");
            }

            try
            {
                string checkQuery = "SELECT TrangThaiLePhi FROM HoSoBenhAn WHERE MaHoSo = @MaHoSo";
                SqlParameter[] checkParams = { new SqlParameter("@MaHoSo", maHoSo) };
                DataTable dt = Db.Query(checkQuery, checkParams);

                if (dt.Rows.Count == 0)
                {
                    return KetQuaXuLy.ThatBai("Không tìm thấy mã hồ sơ bệnh án này trong hệ thống!");
                }

                string trangThai = dt.Rows[0]["TrangThaiLePhi"]?.ToString();
                if (trangThai != "Đã đóng")
                {
                    return KetQuaXuLy.ThatBai("Bệnh nhân chưa đóng lệ phí hằng năm, không đủ điều kiện khám định kỳ miễn phí!");
                }

                string maPhieuKham = "SDK_" + DateTime.Now.Ticks.ToString().Substring(12);
                string insertQuery = @"
                    INSERT INTO PhieuKhamBenh (MaPhieuKham, MaHoSo, MaBacSi, NgayGioKham, TrieuChung, LoaiKham) 
                    VALUES (@MaPhieuKham, @MaHoSo, @MaBacSi, @NgayGioKham, @GhiChu, N'Khám định kỳ')";

                SqlParameter[] parameters = {
                    new SqlParameter("@MaPhieuKham", maPhieuKham),
                    new SqlParameter("@MaHoSo", maHoSo),
                    new SqlParameter("@MaBacSi", maBacSi),
                    new SqlParameter("@NgayGioKham", ngayHen),
                    new SqlParameter("@GhiChu", (object)ghiChu ?? "Khám sức khỏe định kỳ theo quý")
                };

                int rows = Db.Execute(insertQuery, parameters);
                if (rows > 0)
                {
                    return KetQuaXuLy.ThnahCong("Đặt lịch khám sức khỏe định kỳ thành công!");
                }

                return KetQuaXuLy.ThatBai("Không thể tạo lịch hẹn khám định kỳ.");
            }
            catch (Exception ex)
            {
                return KetQuaXuLy.ThatBai("Lỗi hệ thống: " + ex.Message);
            }
        }
    }
}