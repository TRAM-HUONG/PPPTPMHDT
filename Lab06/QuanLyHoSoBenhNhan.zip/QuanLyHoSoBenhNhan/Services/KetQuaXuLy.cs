﻿namespace QuanLyHoSoBenhNhan.Services
{
    public class KetQuaXuLy
    {
        public bool ThanhCong { get; set; }
        public string ThongBao { get; set; }

        public static KetQuaXuLy ThnahCong(string message = "Thành công")
        {
            return new KetQuaXuLy { ThanhCong = true, ThongBao = message };
        }

        public static KetQuaXuLy ThatBai(string message = "Thất bại")
        {
            return new KetQuaXuLy { ThanhCong = false, ThongBao = message };
        }
    }
}