﻿namespace QuanLyHoSoBenhNhan.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabDanhMuc = new System.Windows.Forms.TabControl();
            this.tabKhoa = new System.Windows.Forms.TabPage();
            this.tabThuoc = new System.Windows.Forms.TabPage();
            this.dgvKhoa = new System.Windows.Forms.DataGridView();
            this.dgvThuoc = new System.Windows.Forms.DataGridView();
            this.lblMaKhoa = new System.Windows.Forms.Label();
            this.txtMaKhoa = new System.Windows.Forms.TextBox();
            this.lblTenKhoa = new System.Windows.Forms.Label();
            this.txtTenKhoa = new System.Windows.Forms.TextBox();
            this.btnLuuKhoa = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThuoc)).BeginInit();
            this.tabDanhMuc.SuspendLayout();
            this.tabKhoa.SuspendLayout();
            this.tabThuoc.SuspendLayout();
            this.SuspendLayout();

            // 
            // tabDanhMuc
            // 
            this.tabDanhMuc.Controls.Add(this.tabKhoa);
            this.tabDanhMuc.Controls.Add(this.tabThuoc);
            this.tabDanhMuc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabDanhMuc.Location = new System.Drawing.Point(0, 0);
            this.tabDanhMuc.Name = "tabDanhMuc";
            this.tabDanhMuc.SelectedIndex = 0;
            this.tabDanhMuc.Size = new System.Drawing.Size(800, 450);
            this.tabDanhMuc.TabIndex = 0;

            // 
            // tabKhoa
            // 
            this.tabKhoa.Controls.Add(this.btnLuuKhoa);
            this.tabKhoa.Controls.Add(this.txtTenKhoa);
            this.tabKhoa.Controls.Add(this.lblTenKhoa);
            this.tabKhoa.Controls.Add(this.txtMaKhoa);
            this.tabKhoa.Controls.Add(this.lblMaKhoa);
            this.tabKhoa.Controls.Add(this.dgvKhoa);
            this.tabKhoa.Location = new System.Drawing.Point(4, 25);
            this.tabKhoa.Name = "tabKhoa";
            this.tabKhoa.Padding = new System.Windows.Forms.Padding(3);
            this.tabKhoa.Size = new System.Drawing.Size(792, 421);
            this.tabKhoa.TabIndex = 0;
            this.tabKhoa.Text = "Danh mục Khoa điều trị";
            this.tabKhoa.UseVisualStyleBackColor = true;

            // 
            // tabThuoc
            // 
            this.tabThuoc.Controls.Add(this.dgvThuoc);
            this.tabThuoc.Location = new System.Drawing.Point(4, 25);
            this.tabThuoc.Name = "tabThuoc";
            this.tabThuoc.Padding = new System.Windows.Forms.Padding(3);
            this.tabThuoc.Size = new System.Drawing.Size(792, 421);
            this.tabThuoc.TabIndex = 1;
            this.tabThuoc.Text = "Danh mục Kho thuốc";
            this.tabThuoc.UseVisualStyleBackColor = true;

            // 
            // dgvKhoa
            // 
            this.dgvKhoa.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhoa.Location = new System.Drawing.Point(20, 20);
            this.dgvKhoa.Name = "dgvKhoa";
            this.dgvKhoa.RowHeadersWidth = 51;
            this.dgvKhoa.RowTemplate.Height = 24;
            this.dgvKhoa.Size = new System.Drawing.Size(480, 380);
            this.dgvKhoa.TabIndex = 0;

            // 
            // dgvThuoc
            // 
            this.dgvThuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThuoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvThuoc.Location = new System.Drawing.Point(3, 3);
            this.dgvThuoc.Name = "dgvThuoc";
            this.dgvThuoc.RowHeadersWidth = 51;
            this.dgvThuoc.RowTemplate.Height = 24;
            this.dgvThuoc.Size = new System.Drawing.Size(786, 415);
            this.dgvThuoc.TabIndex = 0;

            // 
            // lblMaKhoa
            // 
            this.lblMaKhoa.AutoSize = true;
            this.lblMaKhoa.Location = new System.Drawing.Point(520, 30);
            this.lblMaKhoa.Name = "lblMaKhoa";
            this.lblMaKhoa.Size = new System.Drawing.Size(62, 16);
            this.lblMaKhoa.TabIndex = 1;
            this.lblMaKhoa.Text = "Mã khoa:";

            // 
            // txtMaKhoa
            // 
            this.txtMaKhoa.Location = new System.Drawing.Point(523, 50);
            this.txtMaKhoa.Name = "txtMaKhoa";
            this.txtMaKhoa.Size = new System.Drawing.Size(240, 22);
            this.txtMaKhoa.TabIndex = 2;

            // 
            // lblTenKhoa
            // 
            this.lblTenKhoa.AutoSize = true;
            this.lblTenKhoa.Location = new System.Drawing.Point(520, 90);
            this.lblTenKhoa.Name = "lblTenKhoa";
            this.lblTenKhoa.Size = new System.Drawing.Size(67, 16);
            this.lblTenKhoa.TabIndex = 3;
            this.lblTenKhoa.Text = "Tên khoa:";

            // 
            // txtTenKhoa
            // 
            this.txtTenKhoa.Location = new System.Drawing.Point(523, 110);
            this.txtTenKhoa.Name = "txtTenKhoa";
            this.txtTenKhoa.Size = new System.Drawing.Size(240, 22);
            this.txtTenKhoa.TabIndex = 4;

            // 
            // btnLuuKhoa
            // 
            this.btnLuuKhoa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.btnLuuKhoa.ForeColor = System.Drawing.Color.White;
            this.btnLuuKhoa.Location = new System.Drawing.Point(523, 160);
            this.btnLuuKhoa.Name = "btnLuuKhoa";
            this.btnLuuKhoa.Size = new System.Drawing.Size(240, 35);
            this.btnLuuKhoa.TabIndex = 5;
            this.btnLuuKhoa.Text = "Lưu Khoa Điều Trị";
            this.btnLuuKhoa.UseVisualStyleBackColor = false;
            this.btnLuuKhoa.Click += new System.EventHandler(this.btnLuuKhoa_Click);

            // 
            // FrmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabDanhMuc);
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý Danh mục Hệ thống";
            this.Load += new System.EventHandler(this.FrmDanhMuc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThuoc)).EndInit();
            this.tabDanhMuc.ResumeLayout(false);
            this.tabKhoa.ResumeLayout(false);
            this.tabKhoa.PerformLayout();
            this.tabThuoc.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabDanhMuc;
        private System.Windows.Forms.TabPage tabKhoa;
        private System.Windows.Forms.TabPage tabThuoc;
        private System.Windows.Forms.DataGridView dgvKhoa;
        private System.Windows.Forms.DataGridView dgvThuoc;
        private System.Windows.Forms.Label lblMaKhoa;
        private System.Windows.Forms.TextBox txtMaKhoa;
        private System.Windows.Forms.Label lblTenKhoa;
        private System.Windows.Forms.TextBox txtTenKhoa;
        private System.Windows.Forms.Button btnLuuKhoa;
    }
}