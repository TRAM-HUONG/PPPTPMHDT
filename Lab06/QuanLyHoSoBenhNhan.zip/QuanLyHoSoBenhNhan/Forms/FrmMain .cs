﻿using System;
using System.Windows.Forms;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            FrmDanhMuc frm = new FrmDanhMuc();
            frm.ShowDialog();
        }

        private void btnTiepNhan_Click(object sender, EventArgs e)
        {
            FrmTiepNhan frm = new FrmTiepNhan();
            frm.ShowDialog();
        }

        private void btnTraCuu_Click(object sender, EventArgs e)
        {
            FrmTraCuuHoSo frm = new FrmTraCuuHoSo();
            frm.ShowDialog();
        }

        private void btnKhamBenh_Click(object sender, EventArgs e)
        {
            FrmKhamBenh frm = new FrmKhamBenh();
            frm.ShowDialog();
        }

        private void btnXetNghiem_Click(object sender, EventArgs e)
        {
            FrmXetNghiem frm = new FrmXetNghiem();
            frm.ShowDialog();
        }

        private void btnToaThuoc_Click(object sender, EventArgs e)
        {
            FrmToaThuoc frm = new FrmToaThuoc();
            frm.ShowDialog();
        }

        private void btnVienPhi_Click(object sender, EventArgs e)
        {
            FrmVienPhi frm = new FrmVienPhi();
            frm.ShowDialog();
        }

        private void btnKhamDinhKy_Click(object sender, EventArgs e)
        {
            FrmKhamDinhKy frm = new FrmKhamDinhKy();
            frm.ShowDialog();
        }

        private void btnThongKe_Click(object sender, EventArgs e)
        {
            FrmThongKeBaoCao frm = new FrmThongKeBaoCao();
            frm.ShowDialog();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}