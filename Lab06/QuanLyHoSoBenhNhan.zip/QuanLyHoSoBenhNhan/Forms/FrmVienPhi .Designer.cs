﻿namespace QuanLyHoSoBenhNhan.Forms
{
    partial class FrmVienPhi
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.grpThanhToan = new System.Windows.Forms.GroupBox();
            this.lblMaHoaDon = new System.Windows.Forms.Label();
            this.txtMaHoaDon = new System.Windows.Forms.TextBox();
            this.lblMaPhieuKham = new System.Windows.Forms.Label();
            this.txtMaPhieuKham = new System.Windows.Forms.TextBox();
            this.btnTinhTien = new System.Windows.Forms.Button();
            this.lblTongTien = new System.Windows.Forms.Label();
            this.txtTongTien = new System.Windows.Forms.TextBox();
            this.lblNgayThanhToan = new System.Windows.Forms.Label();
            this.dtpNgayThanhToan = new System.Windows.Forms.DateTimePicker();
            this.btnThanhToanVaXuatVien = new System.Windows.Forms.Button();

            this.grpThanhToan.SuspendLayout();
            this.SuspendLayout();

            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.lblTitle.Location = new System.Drawing.Point(210, 20);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(360, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "THANH TOÁN VIỆN PHÍ";

            // 
            // grpThanhToan
            // 
            this.grpThanhToan.Controls.Add(this.btnThanhToanVaXuatVien);
            this.grpThanhToan.Controls.Add(this.dtpNgayThanhToan);
            this.grpThanhToan.Controls.Add(this.lblNgayThanhToan);
            this.grpThanhToan.Controls.Add(this.txtTongTien);
            this.grpThanhToan.Controls.Add(this.lblTongTien);
            this.grpThanhToan.Controls.Add(this.btnTinhTien);
            this.grpThanhToan.Controls.Add(this.txtMaPhieuKham);
            this.grpThanhToan.Controls.Add(this.lblMaPhieuKham);
            this.grpThanhToan.Controls.Add(this.txtMaHoaDon);
            this.grpThanhToan.Controls.Add(this.lblMaHoaDon);
            this.grpThanhToan.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpThanhToan.Location = new System.Drawing.Point(50, 80);
            this.grpThanhToan.Name = "grpThanhToan";
            this.grpThanhToan.Size = new System.Drawing.Size(680, 420);
            this.grpThanhToan.TabIndex = 1;
            this.grpThanhToan.TabStop = false;
            this.grpThanhToan.Text = "Thông Tin Hóa Đơn & Xuất Viện";

            // 
            // lblMaHoaDon
            // 
            this.lblMaHoaDon.AutoSize = true;
            this.lblMaHoaDon.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaHoaDon.Location = new System.Drawing.Point(30, 45);
            this.lblMaHoaDon.Name = "lblMaHoaDon";
            this.lblMaHoaDon.Size = new System.Drawing.Size(92, 20);
            this.lblMaHoaDon.TabIndex = 0;
            this.lblMaHoaDon.Text = "Mã hóa đơn:";

            // 
            // txtMaHoaDon
            // 
            this.txtMaHoaDon.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaHoaDon.Location = new System.Drawing.Point(180, 42);
            this.txtMaHoaDon.Name = "txtMaHoaDon";
            this.txtMaHoaDon.Size = new System.Drawing.Size(460, 27);
            this.txtMaHoaDon.TabIndex = 1;

            // 
            // lblMaPhieuKham
            // 
            this.lblMaPhieuKham.AutoSize = true;
            this.lblMaPhieuKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaPhieuKham.Location = new System.Drawing.Point(30, 100);
            this.lblMaPhieuKham.Name = "lblMaPhieuKham";
            this.lblMaPhieuKham.Size = new System.Drawing.Size(113, 20);
            this.lblMaPhieuKham.TabIndex = 2;
            this.lblMaPhieuKham.Text = "Mã phiếu khám:";

            // 
            // txtMaPhieuKham
            // 
            this.txtMaPhieuKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaPhieuKham.Location = new System.Drawing.Point(180, 97);
            this.txtMaPhieuKham.Name = "txtMaPhieuKham";
            this.txtMaPhieuKham.Size = new System.Drawing.Size(320, 27);
            this.txtMaPhieuKham.TabIndex = 3;

            // 
            // btnTinhTien
            // 
            this.btnTinhTien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(167)))), ((int)(((byte)(69)))));
            this.btnTinhTien.ForeColor = System.Drawing.Color.White;
            this.btnTinhTien.Location = new System.Drawing.Point(515, 94);
            this.btnTinhTien.Name = "btnTinhTien";
            this.btnTinhTien.Size = new System.Drawing.Size(125, 32);
            this.btnTinhTien.TabIndex = 4;
            this.btnTinhTien.Text = "Tính Viện Phí";
            this.btnTinhTien.UseVisualStyleBackColor = false;
            this.btnTinhTien.Click += new System.EventHandler(this.btnTinhTien_Click);

            // 
            // lblTongTien
            // 
            this.lblTongTien.AutoSize = true;
            this.lblTongTien.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTongTien.Location = new System.Drawing.Point(30, 155);
            this.lblTongTien.Name = "lblTongTien";
            this.lblTongTien.Size = new System.Drawing.Size(113, 20);
            this.lblTongTien.TabIndex = 5;
            this.lblTongTien.Text = "Tổng viện phí:";

            // 
            // txtTongTien
            // 
            this.txtTongTien.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.txtTongTien.ForeColor = System.Drawing.Color.Red;
            this.txtTongTien.Location = new System.Drawing.Point(180, 150);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.ReadOnly = true;
            this.txtTongTien.Size = new System.Drawing.Size(460, 32);
            this.txtTongTien.TabIndex = 6;
            this.txtTongTien.Text = "0 VNĐ";

            // 
            // lblNgayThanhToan
            // 
            this.lblNgayThanhToan.AutoSize = true;
            this.lblNgayThanhToan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNgayThanhToan.Location = new System.Drawing.Point(30, 215);
            this.lblNgayThanhToan.Name = "lblNgayThanhToan";
            this.lblNgayThanhToan.Size = new System.Drawing.Size(123, 20);
            this.lblNgayThanhToan.TabIndex = 7;
            this.lblNgayThanhToan.Text = "Ngày thanh toán:";

            // 
            // dtpNgayThanhToan
            // 
            this.dtpNgayThanhToan.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dtpNgayThanhToan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpNgayThanhToan.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayThanhToan.Location = new System.Drawing.Point(180, 212);
            this.dtpNgayThanhToan.Name = "dtpNgayThanhToan";
            this.dtpNgayThanhToan.Size = new System.Drawing.Size(460, 27);
            this.dtpNgayThanhToan.TabIndex = 8;

            // 
            // btnThanhToanVaXuatVien
            // 
            this.btnThanhToanVaXuatVien.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.btnThanhToanVaXuatVien.ForeColor = System.Drawing.Color.White;
            this.btnThanhToanVaXuatVien.Location = new System.Drawing.Point(180, 280);
            this.btnThanhToanVaXuatVien.Name = "btnThanhToanVaXuatVien";
            this.btnThanhToanVaXuatVien.Size = new System.Drawing.Size(460, 45);
            this.btnThanhToanVaXuatVien.TabIndex = 9;
            this.btnThanhToanVaXuatVien.Text = "Thanh Toán & Hoàn Tất Xuất Viện";
            this.btnThanhToanVaXuatVien.UseVisualStyleBackColor = false;
            this.btnThanhToanVaXuatVien.Click += new System.EventHandler(this.btnThanhToanVaXuatVien_Click);

            // 
            // FrmVienPhi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 530);
            this.Controls.Add(this.grpThanhToan);
            this.Controls.Add(this.lblTitle);
            this.Name = "FrmVienPhi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần Mềm Quản Lý Thanh Toán Viện Phí & Xuất Viện";
            this.grpThanhToan.ResumeLayout(false);
            this.grpThanhToan.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox grpThanhToan;
        private System.Windows.Forms.Label lblMaHoaDon;
        private System.Windows.Forms.TextBox txtMaHoaDon;
        private System.Windows.Forms.Label lblMaPhieuKham;
        private System.Windows.Forms.TextBox txtMaPhieuKham;
        private System.Windows.Forms.Button btnTinhTien;
        private System.Windows.Forms.Label lblTongTien;
        private System.Windows.Forms.TextBox txtTongTien;
        private System.Windows.Forms.Label lblNgayThanhToan;
        private System.Windows.Forms.DateTimePicker dtpNgayThanhToan;
        private System.Windows.Forms.Button btnThanhToanVaXuatVien;
    }
}