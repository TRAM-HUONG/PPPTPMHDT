﻿namespace QuanLyHoSoBenhNhan.Forms
{
    partial class FrmToaThuoc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvDanhSachThuoc = new System.Windows.Forms.DataGridView();
            this.dgvToaThuocDaChon = new System.Windows.Forms.DataGridView();
            this.grpThongTinToa = new System.Windows.Forms.GroupBox();
            this.lblMaToaThuoc = new System.Windows.Forms.Label();
            this.txtMaToaThuoc = new System.Windows.Forms.TextBox();
            this.lblMaPhieuKham = new System.Windows.Forms.Label();
            this.txtMaPhieuKham = new System.Windows.Forms.TextBox();
            this.lblNgayLap = new System.Windows.Forms.Label();
            this.dtpNgayLap = new System.Windows.Forms.DateTimePicker();
            this.lblLoiDan = new System.Windows.Forms.Label();
            this.txtLoiDan = new System.Windows.Forms.TextBox();
            this.btnThemThuoc = new System.Windows.Forms.Button();
            this.btnLuuToaThuoc = new System.Windows.Forms.Button();
            this.lblKhoThuoc = new System.Windows.Forms.Label();
            this.lblToaThuocChiTiet = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachThuoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvToaThuocDaChon)).BeginInit();
            this.grpThongTinToa.SuspendLayout();
            this.SuspendLayout();

            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.lblTitle.Location = new System.Drawing.Point(420, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(260, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "LẬP TOA THUỐC";

            // 
            // lblKhoThuoc
            // 
            this.lblKhoThuoc.AutoSize = true;
            this.lblKhoThuoc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblKhoThuoc.Location = new System.Drawing.Point(30, 65);
            this.lblKhoThuoc.Name = "lblKhoThuoc";
            this.lblKhoThuoc.Size = new System.Drawing.Size(133, 20);
            this.lblKhoThuoc.TabIndex = 1;
            this.lblKhoThuoc.Text = "Danh Mục Thuốc:";

            // 
            // dgvDanhSachThuoc
            // 
            this.dgvDanhSachThuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachThuoc.Location = new System.Drawing.Point(30, 90);
            this.dgvDanhSachThuoc.Name = "dgvDanhSachThuoc";
            this.dgvDanhSachThuoc.RowHeadersWidth = 51;
            this.dgvDanhSachThuoc.RowTemplate.Height = 24;
            this.dgvDanhSachThuoc.Size = new System.Drawing.Size(550, 240);
            this.dgvDanhSachThuoc.TabIndex = 2;

            // 
            // btnThemThuoc
            // 
            this.btnThemThuoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(167)))), ((int)(((byte)(69)))));
            this.btnThemThuoc.ForeColor = System.Drawing.Color.White;
            this.btnThemThuoc.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnThemThuoc.Location = new System.Drawing.Point(430, 340);
            this.btnThemThuoc.Name = "btnThemThuoc";
            this.btnThemThuoc.Size = new System.Drawing.Size(150, 35);
            this.btnThemThuoc.TabIndex = 3;
            this.btnThemThuoc.Text = ">> Thêm Vào Toa >>";
            this.btnThemThuoc.UseVisualStyleBackColor = false;
            this.btnThemThuoc.Click += new System.EventHandler(this.btnThemThuoc_Click);

            // 
            // lblToaThuocChiTiet
            // 
            this.lblToaThuocChiTiet.AutoSize = true;
            this.lblToaThuocChiTiet.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblToaThuocChiTiet.Location = new System.Drawing.Point(30, 355);
            this.lblToaThuocChiTiet.Name = "lblToaThuocChiTiet";
            this.lblToaThuocChiTiet.Size = new System.Drawing.Size(161, 20);
            this.lblToaThuocChiTiet.TabIndex = 4;
            this.lblToaThuocChiTiet.Text = "Chi Tiết Toa Đã Chọn:";

            // 
            // dgvToaThuocDaChon
            // 
            this.dgvToaThuocDaChon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvToaThuocDaChon.Location = new System.Drawing.Point(30, 380);
            this.dgvToaThuocDaChon.Name = "dgvToaThuocDaChon";
            this.dgvToaThuocDaChon.RowHeadersWidth = 51;
            this.dgvToaThuocDaChon.RowTemplate.Height = 24;
            this.dgvToaThuocDaChon.Size = new System.Drawing.Size(550, 220);
            this.dgvToaThuocDaChon.TabIndex = 5;

            // 
            // grpThongTinToa
            // 
            this.grpThongTinToa.Controls.Add(this.btnLuuToaThuoc);
            this.grpThongTinToa.Controls.Add(this.txtLoiDan);
            this.grpThongTinToa.Controls.Add(this.lblLoiDan);
            this.grpThongTinToa.Controls.Add(this.dtpNgayLap);
            this.grpThongTinToa.Controls.Add(this.lblNgayLap);
            this.grpThongTinToa.Controls.Add(this.txtMaPhieuKham);
            this.grpThongTinToa.Controls.Add(this.lblMaPhieuKham);
            this.grpThongTinToa.Controls.Add(this.txtMaToaThuoc);
            this.grpThongTinToa.Controls.Add(this.lblMaToaThuoc);
            this.grpThongTinToa.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpThongTinToa.Location = new System.Drawing.Point(600, 90);
            this.grpThongTinToa.Name = "grpThongTinToa";
            this.grpThongTinToa.Size = new System.Drawing.Size(460, 510);
            this.grpThongTinToa.TabIndex = 6;
            this.grpThongTinToa.TabStop = false;
            this.grpThongTinToa.Text = "Thông Tin Toa Thuốc";

            // 
            // lblMaToaThuoc
            // 
            this.lblMaToaThuoc.AutoSize = true;
            this.lblMaToaThuoc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaToaThuoc.Location = new System.Drawing.Point(20, 40);
            this.lblMaToaThuoc.Name = "lblMaToaThuoc";
            this.lblMaToaThuoc.Size = new System.Drawing.Size(99, 20);
            this.lblMaToaThuoc.TabIndex = 0;
            this.lblMaToaThuoc.Text = "Mã toa thuốc:";

            // 
            // txtMaToaThuoc
            // 
            this.txtMaToaThuoc.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaToaThuoc.Location = new System.Drawing.Point(20, 65);
            this.txtMaToaThuoc.Name = "txtMaToaThuoc";
            this.txtMaToaThuoc.Size = new System.Drawing.Size(420, 27);
            this.txtMaToaThuoc.TabIndex = 1;

            // 
            // lblMaPhieuKham
            // 
            this.lblMaPhieuKham.AutoSize = true;
            this.lblMaPhieuKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaPhieuKham.Location = new System.Drawing.Point(20, 110);
            this.lblMaPhieuKham.Name = "lblMaPhieuKham";
            this.lblMaPhieuKham.Size = new System.Drawing.Size(113, 20);
            this.lblMaPhieuKham.TabIndex = 2;
            this.lblMaPhieuKham.Text = "Mã phiếu khám:";

            // 
            // txtMaPhieuKham
            // 
            this.txtMaPhieuKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaPhieuKham.Location = new System.Drawing.Point(20, 135);
            this.txtMaPhieuKham.Name = "txtMaPhieuKham";
            this.txtMaPhieuKham.Size = new System.Drawing.Size(420, 27);
            this.txtMaPhieuKham.TabIndex = 3;

            // 
            // lblNgayLap
            // 
            this.lblNgayLap.AutoSize = true;
            this.lblNgayLap.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNgayLap.Location = new System.Drawing.Point(20, 180);
            this.lblNgayLap.Name = "lblNgayLap";
            this.lblNgayLap.Size = new System.Drawing.Size(72, 20);
            this.lblNgayLap.TabIndex = 4;
            this.lblNgayLap.Text = "Ngày lập:";

            // 
            // dtpNgayLap
            // 
            this.dtpNgayLap.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dtpNgayLap.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpNgayLap.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayLap.Location = new System.Drawing.Point(20, 205);
            this.dtpNgayLap.Name = "dtpNgayLap";
            this.dtpNgayLap.Size = new System.Drawing.Size(420, 27);
            this.dtpNgayLap.TabIndex = 5;

            // 
            // lblLoiDan
            // 
            this.lblLoiDan.AutoSize = true;
            this.lblLoiDan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblLoiDan.Location = new System.Drawing.Point(20, 250);
            this.lblLoiDan.Name = "lblLoiDan";
            this.lblLoiDan.Size = new System.Drawing.Size(61, 20);
            this.lblLoiDan.TabIndex = 6;
            this.lblLoiDan.Text = "Lời dặn:";

            // 
            // txtLoiDan
            // 
            this.txtLoiDan.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtLoiDan.Location = new System.Drawing.Point(20, 275);
            this.txtLoiDan.Multiline = true;
            this.txtLoiDan.Name = "txtLoiDan";
            this.txtLoiDan.Size = new System.Drawing.Size(420, 120);
            this.txtLoiDan.TabIndex = 7;

            // 
            // btnLuuToaThuoc
            // 
            this.btnLuuToaThuoc.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.btnLuuToaThuoc.ForeColor = System.Drawing.Color.White;
            this.btnLuuToaThuoc.Location = new System.Drawing.Point(20, 430);
            this.btnLuuToaThuoc.Name = "btnLuuToaThuoc";
            this.btnLuuToaThuoc.Size = new System.Drawing.Size(420, 45);
            this.btnLuuToaThuoc.TabIndex = 8;
            this.btnLuuToaThuoc.Text = "Lưu Toa Thuốc";
            this.btnLuuToaThuoc.UseVisualStyleBackColor = false;
            this.btnLuuToaThuoc.Click += new System.EventHandler(this.btnLuuToaThuoc_Click);

            // 
            // FrmToaThuoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 630);
            this.Controls.Add(this.grpThongTinToa);
            this.Controls.Add(this.dgvToaThuocDaChon);
            this.Controls.Add(this.lblToaThuocChiTiet);
            this.Controls.Add(this.btnThemThuoc);
            this.Controls.Add(this.dgvDanhSachThuoc);
            this.Controls.Add(this.lblKhoThuoc);
            this.Controls.Add(this.lblTitle);
            this.Name = "FrmToaThuoc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần Mềm Quản Lý Lập Toa Thuốc";
            this.Load += new System.EventHandler(this.FrmToaThuoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachThuoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvToaThuocDaChon)).EndInit();
            this.grpThongTinToa.ResumeLayout(false);
            this.grpThongTinToa.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvDanhSachThuoc;
        private System.Windows.Forms.DataGridView dgvToaThuocDaChon;
        private System.Windows.Forms.GroupBox grpThongTinToa;
        private System.Windows.Forms.Label lblMaToaThuoc;
        private System.Windows.Forms.TextBox txtMaToaThuoc;
        private System.Windows.Forms.Label lblMaPhieuKham;
        private System.Windows.Forms.TextBox txtMaPhieuKham;
        private System.Windows.Forms.Label lblNgayLap;
        private System.Windows.Forms.DateTimePicker dtpNgayLap;
        private System.Windows.Forms.Label lblLoiDan;
        private System.Windows.Forms.TextBox txtLoiDan;
        private System.Windows.Forms.Button btnThemThuoc;
        private System.Windows.Forms.Button btnLuuToaThuoc;
        private System.Windows.Forms.Label lblKhoThuoc;
        private System.Windows.Forms.Label lblToaThuocChiTiet;
    }
}