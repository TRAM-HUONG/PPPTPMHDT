﻿namespace QuanLyHoSoBenhNhan.Forms
{
    partial class FrmXetNghiem
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvDanhSachXetNghiem = new System.Windows.Forms.DataGridView();
            this.grpCapNhat = new System.Windows.Forms.GroupBox();
            this.lblMaXetNghiem = new System.Windows.Forms.Label();
            this.txtMaXetNghiem = new System.Windows.Forms.TextBox();
            this.lblKetQua = new System.Windows.Forms.Label();
            this.txtKetQuaXetNghiem = new System.Windows.Forms.TextBox();
            this.lblNgayXetNghiem = new System.Windows.Forms.Label();
            this.dtpNgayXetNghiem = new System.Windows.Forms.DateTimePicker();
            this.btnCapNhatKetQua = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachXetNghiem)).BeginInit();
            this.grpCapNhat.SuspendLayout();
            this.SuspendLayout();

            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.lblTitle.Location = new System.Drawing.Point(340, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(320, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ XÉT NGHIỆM";

            // 
            // dgvDanhSachXetNghiem
            // 
            this.dgvDanhSachXetNghiem.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDanhSachXetNghiem.Location = new System.Drawing.Point(30, 70);
            this.dgvDanhSachXetNghiem.Name = "dgvDanhSachXetNghiem";
            this.dgvDanhSachXetNghiem.RowHeadersWidth = 51;
            this.dgvDanhSachXetNghiem.RowTemplate.Height = 24;
            this.dgvDanhSachXetNghiem.Size = new System.Drawing.Size(550, 450);
            this.dgvDanhSachXetNghiem.TabIndex = 1;
            this.dgvDanhSachXetNghiem.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDanhSachXetNghiem_CellClick);

            // 
            // grpCapNhat
            // 
            this.grpCapNhat.Controls.Add(this.btnCapNhatKetQua);
            this.grpCapNhat.Controls.Add(this.dtpNgayXetNghiem);
            this.grpCapNhat.Controls.Add(this.lblNgayXetNghiem);
            this.grpCapNhat.Controls.Add(this.txtKetQuaXetNghiem);
            this.grpCapNhat.Controls.Add(this.lblKetQua);
            this.grpCapNhat.Controls.Add(this.txtMaXetNghiem);
            this.grpCapNhat.Controls.Add(this.lblMaXetNghiem);
            this.grpCapNhat.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpCapNhat.Location = new System.Drawing.Point(600, 70);
            this.grpCapNhat.Name = "grpCapNhat";
            this.grpCapNhat.Size = new System.Drawing.Size(370, 450);
            this.grpCapNhat.TabIndex = 2;
            this.grpCapNhat.TabStop = false;
            this.grpCapNhat.Text = "Cập Nhật Kết Quả Xét Nghiệm";

            // 
            // lblMaXetNghiem
            // 
            this.lblMaXetNghiem.AutoSize = true;
            this.lblMaXetNghiem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaXetNghiem.Location = new System.Drawing.Point(20, 45);
            this.lblMaXetNghiem.Name = "lblMaXetNghiem";
            this.lblMaXetNghiem.Size = new System.Drawing.Size(107, 20);
            this.lblMaXetNghiem.TabIndex = 0;
            this.lblMaXetNghiem.Text = "Mã xét nghiệm:";

            // 
            // txtMaXetNghiem
            // 
            this.txtMaXetNghiem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaXetNghiem.Location = new System.Drawing.Point(20, 70);
            this.txtMaXetNghiem.Name = "txtMaXetNghiem";
            this.txtMaXetNghiem.ReadOnly = true;
            this.txtMaXetNghiem.Size = new System.Drawing.Size(330, 27);
            this.txtMaXetNghiem.TabIndex = 1;

            // 
            // lblKetQua
            // 
            this.lblKetQua.AutoSize = true;
            this.lblKetQua.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblKetQua.Location = new System.Drawing.Point(20, 115);
            this.lblKetQua.Name = "lblKetQua";
            this.lblKetQua.Size = new System.Drawing.Size(147, 20);
            this.lblKetQua.TabIndex = 2;
            this.lblKetQua.Text = "Kết quả xét nghiệm:";

            // 
            // txtKetQuaXetNghiem
            // 
            this.txtKetQuaXetNghiem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtKetQuaXetNghiem.Location = new System.Drawing.Point(20, 140);
            this.txtKetQuaXetNghiem.Multiline = true;
            this.txtKetQuaXetNghiem.Name = "txtKetQuaXetNghiem";
            this.txtKetQuaXetNghiem.Size = new System.Drawing.Size(330, 120);
            this.txtKetQuaXetNghiem.TabIndex = 3;

            // 
            // lblNgayXetNghiem
            // 
            this.lblNgayXetNghiem.AutoSize = true;
            this.lblNgayXetNghiem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNgayXetNghiem.Location = new System.Drawing.Point(20, 280);
            this.lblNgayXetNghiem.Name = "lblNgayXetNghiem";
            this.lblNgayXetNghiem.Size = new System.Drawing.Size(126, 20);
            this.lblNgayXetNghiem.TabIndex = 4;
            this.lblNgayXetNghiem.Text = "Ngày xét nghiệm:";

            // 
            // dtpNgayXetNghiem
            // 
            this.dtpNgayXetNghiem.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dtpNgayXetNghiem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpNgayXetNghiem.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayXetNghiem.Location = new System.Drawing.Point(20, 305);
            this.dtpNgayXetNghiem.Name = "dtpNgayXetNghiem";
            this.dtpNgayXetNghiem.Size = new System.Drawing.Size(330, 27);
            this.dtpNgayXetNghiem.TabIndex = 5;

            // 
            // btnCapNhatKetQua
            // 
            this.btnCapNhatKetQua.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.btnCapNhatKetQua.ForeColor = System.Drawing.Color.White;
            this.btnCapNhatKetQua.Location = new System.Drawing.Point(20, 370);
            this.btnCapNhatKetQua.Name = "btnCapNhatKetQua";
            this.btnCapNhatKetQua.Size = new System.Drawing.Size(330, 40);
            this.btnCapNhatKetQua.TabIndex = 6;
            this.btnCapNhatKetQua.Text = "Cập Nhật Kết Quả";
            this.btnCapNhatKetQua.UseVisualStyleBackColor = false;
            this.btnCapNhatKetQua.Click += new System.EventHandler(this.btnCapNhatKetQua_Click);

            // 
            // FrmXetNghiem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 550);
            this.Controls.Add(this.grpCapNhat);
            this.Controls.Add(this.dgvDanhSachXetNghiem);
            this.Controls.Add(this.lblTitle);
            this.Name = "FrmXetNghiem";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần Mềm Quản Lý Xét Nghiệm & Cận Lâm Sàng";
            this.Load += new System.EventHandler(this.FrmXetNghiem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDanhSachXetNghiem)).EndInit();
            this.grpCapNhat.ResumeLayout(false);
            this.grpCapNhat.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvDanhSachXetNghiem;
        private System.Windows.Forms.GroupBox grpCapNhat;
        private System.Windows.Forms.Label lblMaXetNghiem;
        private System.Windows.Forms.TextBox txtMaXetNghiem;
        private System.Windows.Forms.Label lblKetQua;
        private System.Windows.Forms.TextBox txtKetQuaXetNghiem;
        private System.Windows.Forms.Label lblNgayXetNghiem;
        private System.Windows.Forms.DateTimePicker dtpNgayXetNghiem;
        private System.Windows.Forms.Button btnCapNhatKetQua;
    }
}