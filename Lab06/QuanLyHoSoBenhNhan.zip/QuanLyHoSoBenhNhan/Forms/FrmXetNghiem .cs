﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmXetNghiem : Form
    {
        private XetNghiemService _xetNghiemService;

        public FrmXetNghiem()
        {
            InitializeComponent();
            _xetNghiemService = new XetNghiemService();
        }

        private void FrmXetNghiem_Load(object sender, EventArgs e)
        {
            LoadDanhSachXetNghiem();
        }

        private void LoadDanhSachXetNghiem()
        {
            // Form gọi Service lấy dữ liệu nạp lên DataGridView
            dgvDanhSachXetNghiem.DataSource = _xetNghiemService.LayDanhSachXetNghiem();
        }

        private void dgvDanhSachXetNghiem_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvDanhSachXetNghiem.Rows[e.RowIndex];
                txtMaXetNghiem.Text = row.Cells["MaXetNghiem"].Value?.ToString();
                txtKetQuaXetNghiem.Text = row.Cells["KetQua"].Value?.ToString();

                if (row.Cells["NgayXetNghiem"].Value != DBNull.Value && row.Cells["NgayXetNghiem"].Value != null)
                {
                    dtpNgayXetNghiem.Value = Convert.ToDateTime(row.Cells["NgayXetNghiem"].Value);
                }
            }
        }

        private void btnCapNhatKetQua_Click(object sender, EventArgs e)
        {
            // 1. Lấy dữ liệu từ giao diện Form
            string maXetNghiem = txtMaXetNghiem.Text.Trim();
            string ketQua = txtKetQuaXetNghiem.Text.Trim();
            DateTime ngayXetNghiem = dtpNgayXetNghiem.Value;

            // 2. Gọi Service xử lý nghiệp vụ cập nhật kết quả xét nghiệm
            KetQuaXuLy ketQuaXuLy = _xetNghiemService.CapNhatKetQuaXetNghiem(maXetNghiem, ketQua, ngayXetNghiem);

            // 3. Form chỉ hiển thị thông báo và nạp lại dữ liệu theo đúng kiến trúc
            MessageBox.Show(ketQuaXuLy.ThongBao, "Thông báo hệ thống", MessageBoxButtons.OK, ketQuaXuLy.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (ketQuaXuLy.ThanhCong)
            {
                // Nạp lại danh sách dữ liệu trên lưới
                LoadDanhSachXetNghiem();

                // Làm sạch form cập nhật
                txtMaXetNghiem.Clear();
                txtKetQuaXetNghiem.Clear();
            }
        }
    }
}