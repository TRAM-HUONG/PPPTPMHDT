﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmToaThuoc : Form
    {
        private ToaThuocService _toaThuocService;
        private DataTable _dtChiTietTam; // Bảng lưu tạm các thuốc bác sĩ chọn kê trong toa

        public FrmToaThuoc()
        {
            InitializeComponent();
            _toaThuocService = new ToaThuocService();
        }

        private void FrmToaThuoc_Load(object sender, EventArgs e)
        {
            LoadDanhMucThuoc();
            KhoiTaoBangChiTietTam();
        }

        private void LoadDanhMucThuoc()
        {
            // Form gọi Service lấy danh mục thuốc từ kho
            dgvDanhSachThuoc.DataSource = _toaThuocService.LayDanhSachThuoc();
        }

        private void KhoiTaoBangChiTietTam()
        {
            _dtChiTietTam = new DataTable();
            _dtChiTietTam.Columns.Add("MaChiTiet", typeof(string));
            _dtChiTietTam.Columns.Add("MaThuoc", typeof(string));
            _dtChiTietTam.Columns.Add("TenThuoc", typeof(string));
            _dtChiTietTam.Columns.Add("SoLuong", typeof(int));
            _dtChiTietTam.Columns.Add("LieuDung", typeof(string));
            dgvToaThuocDaChon.DataSource = _dtChiTietTam;
        }

        private void btnThemThuoc_Click(object sender, EventArgs e)
        {
            if (dgvDanhSachThuoc.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dgvDanhSachThuoc.SelectedRows[0];
                string maThuoc = row.Cells["MaThuoc"].Value.ToString();
                string tenThuoc = row.Cells["TenThuoc"].Value.ToString();

                // Tạo mã chi tiết ngẫu nhiên dựa trên thời gian
                string maChiTiet = "CT_" + DateTime.Now.Ticks.ToString().Substring(12);

                // Thêm vào danh sách tạm trên giao diện (có thể thay đổi số lượng/liều dùng sau)
                _dtChiTietTam.Rows.Add(maChiTiet, maThuoc, tenThuoc, 1, "Sáng 1 viên, Chiều 1 viên");
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một loại thuốc từ kho để thêm vào toa!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnLuuToaThuoc_Click(object sender, EventArgs e)
        {
            // 1. Lấy dữ liệu từ giao diện Form
            string maToaThuoc = txtMaToaThuoc.Text.Trim();
            string maPhieuKham = txtMaPhieuKham.Text.Trim();
            DateTime ngayLap = dtpNgayLap.Value;
            string loiDan = txtLoiDan.Text.Trim();

            // 2. Gọi Service xử lý nghiệp vụ lưu toa thuốc và chi tiết giao dịch
            KetQuaXuLy ketQua = _toaThuocService.LapToaThuoc(maToaThuoc, maPhieuKham, ngayLap, loiDan, _dtChiTietTam);

            // 3. Form chỉ hiển thị thông báo và nạp lại dữ liệu theo đúng kiến trúc
            MessageBox.Show(ketQua.ThongBao, "Thông báo hệ thống", MessageBoxButtons.OK, ketQua.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (ketQua.ThanhCong)
            {
                // Làm sạch form và danh sách tạm
                _dtChiTietTam.Clear();
                txtMaToaThuoc.Clear();
                txtMaPhieuKham.Clear();
                txtLoiDan.Clear();
                LoadDanhMucThuoc();
            }
        }
    }
}