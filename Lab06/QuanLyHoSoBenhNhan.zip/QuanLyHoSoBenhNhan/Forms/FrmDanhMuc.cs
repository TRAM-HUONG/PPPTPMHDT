﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmDanhMuc : Form
    {
        private DanhMucService _danhMucService;

        public FrmDanhMuc()
        {
            InitializeComponent();
            _danhMucService = new DanhMucService();
        }

        private void FrmDanhMuc_Load(object sender, EventArgs e)
        {
            LoadDuLieu();
        }

        // Hàm nạp lại dữ liệu cho các bảng danh mục
        private void LoadDuLieu()
        {
            dgvKhoa.DataSource = _danhMucService.LayDanhSachKhoa();
            dgvThuoc.DataSource = _danhMucService.LayDanhSachThuoc();
        }

        private void btnLuuKhoa_Click(object sender, EventArgs e)
        {
            // 1. Lấy dữ liệu từ giao diện
            string maKhoa = txtMaKhoa.Text.Trim();
            string tenKhoa = txtTenKhoa.Text.Trim();

            // 2. Gọi Service xử lý nghiệp vụ
            KetQuaXuLy ketQua = _danhMucService.LuuKhoaDieuTri(maKhoa, tenKhoa);

            // 3. Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(ketQua.ThongBao, "Thông báo", MessageBoxButtons.OK, ketQua.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (ketQua.ThanhCong)
            {
                txtMaKhoa.Clear();
                txtTenKhoa.Clear();
                LoadDuLieu(); // Nạp lại dữ liệu
            }
        }
    }
}