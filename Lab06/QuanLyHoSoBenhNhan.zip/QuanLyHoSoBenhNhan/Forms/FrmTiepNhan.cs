﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmTiepNhan : Form
    {
        private BenhNhanService _benhNhanService;

        public FrmTiepNhan()
        {
            InitializeComponent();
            _benhNhanService = new BenhNhanService();
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            // 1. Lấy dữ liệu từ giao diện Form
            string maBenhNhan = txtMaBenhNhan.Text.Trim();
            string hoTen = txtHoTen.Text.Trim();
            string diaChi = txtDiaChi.Text.Trim();
            DateTime ngaySinh = dtpNgaySinh.Value;
            string dienThoai = txtDienThoai.Text.Trim();
            string anh3x4 = txtAnh3x4.Text.Trim();

            // 2. Gọi Service xử lý nghiệp vụ
            KetQuaXuLy ketQua = _benhNhanService.DangKyVaCapHoSo(maBenhNhan, hoTen, diaChi, ngaySinh, dienThoai, anh3x4);

            // 3. Form chỉ hiển thị thông báo và xử lý làm sạch giao diện theo kết quả trả về
            MessageBox.Show(ketQua.ThongBao, "Thông báo hệ thống", MessageBoxButtons.OK, ketQua.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (ketQua.ThanhCong)
            {
                ClearForm();
            }
        }

        private void ClearForm()
        {
            txtMaBenhNhan.Clear();
            txtHoTen.Clear();
            txtDiaChi.Clear();
            txtDienThoai.Clear();
            txtAnh3x4.Clear();
            txtMaBenhNhan.Focus();
        }
    }
}