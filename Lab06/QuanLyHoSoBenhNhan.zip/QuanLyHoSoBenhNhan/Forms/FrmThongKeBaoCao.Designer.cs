﻿namespace QuanLyHoSoBenhNhan.Forms
{
    partial class FrmThongKeBaoCao
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.tabThongKe = new System.Windows.Forms.TabControl();
            this.tabDoanhThu = new System.Windows.Forms.TabPage();
            this.dgvDoanhThu = new System.Windows.Forms.DataGridView();
            this.tabLuotKham = new System.Windows.Forms.TabPage();
            this.dgvLuotKham = new System.Windows.Forms.DataGridView();
            this.tabKhoThuoc = new System.Windows.Forms.TabPage();
            this.dgvKhoThuoc = new System.Windows.Forms.DataGridView();
            this.btnXuatBaoCao = new System.Windows.Forms.Button();

            this.tabThongKe.SuspendLayout();
            this.tabDoanhThu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).BeginInit();
            this.tabLuotKham.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuotKham)).BeginInit();
            this.tabKhoThuoc.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoThuoc)).BeginInit();
            this.SuspendLayout();

            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.lblTitle.Location = new System.Drawing.Point(340, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(320, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "THỐNG KÊ & BÁO CÁO";

            // 
            // tabThongKe
            // 
            this.tabThongKe.Controls.Add(this.tabDoanhThu);
            this.tabThongKe.Controls.Add(this.tabLuotKham);
            this.tabThongKe.Controls.Add(this.tabKhoThuoc);
            this.tabThongKe.Location = new System.Drawing.Point(30, 70);
            this.tabThongKe.Name = "tabThongKe";
            this.tabThongKe.SelectedIndex = 0;
            this.tabThongKe.Size = new System.Drawing.Size(950, 430);
            this.tabThongKe.TabIndex = 1;

            // 
            // tabDoanhThu
            // 
            this.tabDoanhThu.Controls.Add(this.dgvDoanhThu);
            this.tabDoanhThu.Location = new System.Drawing.Point(4, 25);
            this.tabDoanhThu.Name = "tabDoanhThu";
            this.tabDoanhThu.Padding = new System.Windows.Forms.Padding(3);
            this.tabDoanhThu.Size = new System.Drawing.Size(942, 401);
            this.tabDoanhThu.TabIndex = 0;
            this.tabDoanhThu.Text = "Doanh Thu Viện Phí";
            this.tabDoanhThu.UseVisualStyleBackColor = true;

            // 
            // dgvDoanhThu
            // 
            this.dgvDoanhThu.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoanhThu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvDoanhThu.Location = new System.Drawing.Point(3, 3);
            this.dgvDoanhThu.Name = "dgvDoanhThu";
            this.dgvDoanhThu.RowHeadersWidth = 51;
            this.dgvDoanhThu.RowTemplate.Height = 24;
            this.dgvDoanhThu.Size = new System.Drawing.Size(936, 395);
            this.dgvDoanhThu.TabIndex = 0;

            // 
            // tabLuotKham
            // 
            this.tabLuotKham.Controls.Add(this.dgvLuotKham);
            this.tabLuotKham.Location = new System.Drawing.Point(4, 25);
            this.tabLuotKham.Name = "tabLuotKham";
            this.tabLuotKham.Padding = new System.Windows.Forms.Padding(3);
            this.tabLuotKham.Size = new System.Drawing.Size(942, 401);
            this.tabLuotKham.TabIndex = 1;
            this.tabLuotKham.Text = "Lượt Khám Theo Khoa";
            this.tabLuotKham.UseVisualStyleBackColor = true;

            // 
            // dgvLuotKham
            // 
            this.dgvLuotKham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLuotKham.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvLuotKham.Location = new System.Drawing.Point(3, 3);
            this.dgvLuotKham.Name = "dgvLuotKham";
            this.dgvLuotKham.RowHeadersWidth = 51;
            this.dgvLuotKham.RowTemplate.Height = 24;
            this.dgvLuotKham.Size = new System.Drawing.Size(936, 395);
            this.dgvLuotKham.TabIndex = 0;

            // 
            // tabKhoThuoc
            // 
            this.tabKhoThuoc.Controls.Add(this.dgvKhoThuoc);
            this.tabKhoThuoc.Location = new System.Drawing.Point(4, 25);
            this.tabKhoThuoc.Name = "tabKhoThuoc";
            this.tabKhoThuoc.Padding = new System.Windows.Forms.Padding(3);
            this.tabKhoThuoc.Size = new System.Drawing.Size(942, 401);
            this.tabKhoThuoc.TabIndex = 2;
            this.tabKhoThuoc.Text = "Tình Hình Kho Thuốc";
            this.tabKhoThuoc.UseVisualStyleBackColor = true;

            // 
            // dgvKhoThuoc
            // 
            this.dgvKhoThuoc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhoThuoc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvKhoThuoc.Location = new System.Drawing.Point(3, 3);
            this.dgvKhoThuoc.Name = "dgvKhoThuoc";
            this.dgvKhoThuoc.RowHeadersWidth = 51;
            this.dgvKhoThuoc.RowTemplate.Height = 24;
            this.dgvKhoThuoc.Size = new System.Drawing.Size(936, 395);
            this.dgvKhoThuoc.TabIndex = 0;

            // 
            // btnXuatBaoCao
            // 
            this.btnXuatBaoCao.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.btnXuatBaoCao.ForeColor = System.Drawing.Color.White;
            this.btnXuatBaoCao.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnXuatBaoCao.Location = new System.Drawing.Point(810, 510);
            this.btnXuatBaoCao.Name = "btnXuatBaoCao";
            this.btnXuatBaoCao.Size = new System.Drawing.Size(170, 40);
            this.btnXuatBaoCao.TabIndex = 2;
            this.btnXuatBaoCao.Text = "Làm Mới Dữ Liệu";
            this.btnXuatBaoCao.UseVisualStyleBackColor = false;
            this.btnXuatBaoCao.Click += new System.EventHandler(this.btnXuatBaoCao_Click);

            // 
            // FrmThongKeBaoCao
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 570);
            this.Controls.Add(this.btnXuatBaoCao);
            this.Controls.Add(this.tabThongKe);
            this.Controls.Add(this.lblTitle);
            this.Name = "FrmThongKeBaoCao";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần Mềm Thống Kê & Báo Cáo";
            this.Load += new System.EventHandler(this.FrmThongKeBaoCao_Load);
            this.tabThongKe.ResumeLayout(false);
            this.tabDoanhThu.ResumeLayout(false);
            this.tabDoanhThu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoanhThu)).EndInit();
            this.tabLuotKham.ResumeLayout(false);
            this.tabLuotKham.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuotKham)).EndInit();
            this.tabKhoThuoc.ResumeLayout(false);
            this.tabKhoThuoc.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhoThuoc)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.TabControl tabThongKe;
        private System.Windows.Forms.TabPage tabDoanhThu;
        private System.Windows.Forms.DataGridView dgvDoanhThu;
        private System.Windows.Forms.TabPage tabLuotKham;
        private System.Windows.Forms.DataGridView dgvLuotKham;
        private System.Windows.Forms.TabPage tabKhoThuoc;
        private System.Windows.Forms.DataGridView dgvKhoThuoc;
        private System.Windows.Forms.Button btnXuatBaoCao;
    }
}