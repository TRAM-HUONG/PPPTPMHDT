﻿namespace QuanLyHoSoBenhNhan.Forms
{
    partial class FrmKhamBenh
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblMaHoSoTraCuu = new System.Windows.Forms.Label();
            this.txtMaHoSoTraCuu = new System.Windows.Forms.TextBox();
            this.btnTraCuu = new System.Windows.Forms.Button();
            this.dgvLichSuKham = new System.Windows.Forms.DataGridView();
            this.grpLapPhieu = new System.Windows.Forms.GroupBox();
            this.lblMaPhieuKham = new System.Windows.Forms.Label();
            this.txtMaPhieuKham = new System.Windows.Forms.TextBox();
            this.lblMaHoSo = new System.Windows.Forms.Label();
            this.txtMaHoSo = new System.Windows.Forms.TextBox();
            this.lblMaBacSi = new System.Windows.Forms.Label();
            this.txtMaBacSi = new System.Windows.Forms.TextBox();
            this.lblNgayGioKham = new System.Windows.Forms.Label();
            this.dtpNgayGioKham = new System.Windows.Forms.DateTimePicker();
            this.lblTrieuChung = new System.Windows.Forms.Label();
            this.txtTrieuChung = new System.Windows.Forms.TextBox();
            this.lblLoaiKham = new System.Windows.Forms.Label();
            this.cbLoaiKham = new System.Windows.Forms.ComboBox();
            this.btnLuuPhieuKham = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSuKham)).BeginInit();
            this.grpLapPhieu.SuspendLayout();
            this.SuspendLayout();

            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.lblTitle.Location = new System.Drawing.Point(340, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(320, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ KHÁM BỆNH";

            // 
            // lblMaHoSoTraCuu
            // 
            this.lblMaHoSoTraCuu.AutoSize = true;
            this.lblMaHoSoTraCuu.Location = new System.Drawing.Point(30, 70);
            this.lblMaHoSoTraCuu.Name = "lblMaHoSoTraCuu";
            this.lblMaHoSoTraCuu.Size = new System.Drawing.Size(109, 16);
            this.lblMaHoSoTraCuu.TabIndex = 1;
            this.lblMaHoSoTraCuu.Text = "Nhập Mã Hồ Sơ:";

            // 
            // txtMaHoSoTraCuu
            // 
            this.txtMaHoSoTraCuu.Location = new System.Drawing.Point(150, 67);
            this.txtMaHoSoTraCuu.Name = "txtMaHoSoTraCuu";
            this.txtMaHoSoTraCuu.Size = new System.Drawing.Size(250, 22);
            this.txtMaHoSoTraCuu.TabIndex = 2;

            // 
            // btnTraCuu
            // 
            this.btnTraCuu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.btnTraCuu.ForeColor = System.Drawing.Color.White;
            this.btnTraCuu.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.btnTraCuu.Location = new System.Drawing.Point(420, 63);
            this.btnTraCuu.Name = "btnTraCuu";
            this.btnTraCuu.Size = new System.Drawing.Size(110, 30);
            this.btnTraCuu.TabIndex = 3;
            this.btnTraCuu.Text = "Tra Cứu Hồ Sơ";
            this.btnTraCuu.UseVisualStyleBackColor = false;
            this.btnTraCuu.Click += new System.EventHandler(this.btnTraCuu_Click);

            // 
            // dgvLichSuKham
            // 
            this.dgvLichSuKham.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvLichSuKham.Location = new System.Drawing.Point(30, 110);
            this.dgvLichSuKham.Name = "dgvLichSuKham";
            this.dgvLichSuKham.RowHeadersWidth = 51;
            this.dgvLichSuKham.RowTemplate.Height = 24;
            this.dgvLichSuKham.Size = new System.Drawing.Size(500, 420);
            this.dgvLichSuKham.TabIndex = 4;

            // 
            // grpLapPhieu
            // 
            this.grpLapPhieu.Controls.Add(this.btnLuuPhieuKham);
            this.grpLapPhieu.Controls.Add(this.cbLoaiKham);
            this.grpLapPhieu.Controls.Add(this.lblLoaiKham);
            this.grpLapPhieu.Controls.Add(this.txtTrieuChung);
            this.grpLapPhieu.Controls.Add(this.lblTrieuChung);
            this.grpLapPhieu.Controls.Add(this.dtpNgayGioKham);
            this.grpLapPhieu.Controls.Add(this.lblNgayGioKham);
            this.grpLapPhieu.Controls.Add(this.txtMaBacSi);
            this.grpLapPhieu.Controls.Add(this.lblMaBacSi);
            this.grpLapPhieu.Controls.Add(this.txtMaHoSo);
            this.grpLapPhieu.Controls.Add(this.lblMaHoSo);
            this.grpLapPhieu.Controls.Add(this.txtMaPhieuKham);
            this.grpLapPhieu.Controls.Add(this.lblMaPhieuKham);
            this.grpLapPhieu.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpLapPhieu.Location = new System.Drawing.Point(550, 110);
            this.grpLapPhieu.Name = "grpLapPhieu";
            this.grpLapPhieu.Size = new System.Drawing.Size(420, 420);
            this.grpLapPhieu.TabIndex = 5;
            this.grpLapPhieu.TabStop = false;
            this.grpLapPhieu.Text = "Lập Phiếu Khám Bệnh / Chẩn Đoán";

            // 
            // lblMaPhieuKham
            // 
            this.lblMaPhieuKham.AutoSize = true;
            this.lblMaPhieuKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaPhieuKham.Location = new System.Drawing.Point(20, 35);
            this.lblMaPhieuKham.Name = "lblMaPhieuKham";
            this.lblMaPhieuKham.Size = new System.Drawing.Size(113, 20);
            this.lblMaPhieuKham.TabIndex = 0;
            this.lblMaPhieuKham.Text = "Mã phiếu khám:";

            // 
            // txtMaPhieuKham
            // 
            this.txtMaPhieuKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaPhieuKham.Location = new System.Drawing.Point(140, 32);
            this.txtMaPhieuKham.Name = "txtMaPhieuKham";
            this.txtMaPhieuKham.Size = new System.Drawing.Size(255, 27);
            this.txtMaPhieuKham.TabIndex = 1;

            // 
            // lblMaHoSo
            // 
            this.lblMaHoSo.AutoSize = true;
            this.lblMaHoSo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaHoSo.Location = new System.Drawing.Point(20, 80);
            this.lblMaHoSo.Name = "lblMaHoSo";
            this.lblMaHoSo.Size = new System.Drawing.Size(73, 20);
            this.lblMaHoSo.TabIndex = 2;
            this.lblMaHoSo.Text = "Mã hồ sơ:";

            // 
            // txtMaHoSo
            // 
            this.txtMaHoSo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaHoSo.Location = new System.Drawing.Point(140, 77);
            this.txtMaHoSo.Name = "txtMaHoSo";
            this.txtMaHoSo.Size = new System.Drawing.Size(255, 27);
            this.txtMaHoSo.TabIndex = 3;

            // 
            // lblMaBacSi
            // 
            this.lblMaBacSi.AutoSize = true;
            this.lblMaBacSi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaBacSi.Location = new System.Drawing.Point(20, 125);
            this.lblMaBacSi.Name = "lblMaBacSi";
            this.lblMaBacSi.Size = new System.Drawing.Size(77, 20);
            this.lblMaBacSi.TabIndex = 4;
            this.lblMaBacSi.Text = "Mã bác sĩ:";

            // 
            // txtMaBacSi
            // 
            this.txtMaBacSi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaBacSi.Location = new System.Drawing.Point(140, 122);
            this.txtMaBacSi.Name = "txtMaBacSi";
            this.txtMaBacSi.Size = new System.Drawing.Size(255, 27);
            this.txtMaBacSi.TabIndex = 5;

            // 
            // lblNgayGioKham
            // 
            this.lblNgayGioKham.AutoSize = true;
            this.lblNgayGioKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNgayGioKham.Location = new System.Drawing.Point(20, 170);
            this.lblNgayGioKham.Name = "lblNgayGioKham";
            this.lblNgayGioKham.Size = new System.Drawing.Size(107, 20);
            this.lblNgayGioKham.TabIndex = 6;
            this.lblNgayGioKham.Text = "Ngày giờ khám:";

            // 
            // dtpNgayGioKham
            // 
            this.dtpNgayGioKham.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dtpNgayGioKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpNgayGioKham.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayGioKham.Location = new System.Drawing.Point(140, 167);
            this.dtpNgayGioKham.Name = "dtpNgayGioKham";
            this.dtpNgayGioKham.Size = new System.Drawing.Size(255, 27);
            this.dtpNgayGioKham.TabIndex = 7;

            // 
            // lblTrieuChung
            // 
            this.lblTrieuChung.AutoSize = true;
            this.lblTrieuChung.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblTrieuChung.Location = new System.Drawing.Point(20, 215);
            this.lblTrieuChung.Name = "lblTrieuChung";
            this.lblTrieuChung.Size = new System.Drawing.Size(91, 20);
            this.lblTrieuChung.TabIndex = 8;
            this.lblTrieuChung.Text = "Triệu chứng:";

            // 
            // txtTrieuChung
            // 
            this.txtTrieuChung.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtTrieuChung.Location = new System.Drawing.Point(140, 212);
            this.txtTrieuChung.Multiline = true;
            this.txtTrieuChung.Name = "txtTrieuChung";
            this.txtTrieuChung.Size = new System.Drawing.Size(255, 60);
            this.txtTrieuChung.TabIndex = 9;

            // 
            // lblLoaiKham
            // 
            this.lblLoaiKham.AutoSize = true;
            this.lblLoaiKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblLoaiKham.Location = new System.Drawing.Point(20, 290);
            this.lblLoaiKham.Name = "lblLoaiKham";
            this.lblLoaiKham.Size = new System.Drawing.Size(81, 20);
            this.lblLoaiKham.TabIndex = 10;
            this.lblLoaiKham.Text = "Loại khám:";

            // 
            // cbLoaiKham
            // 
            this.cbLoaiKham.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbLoaiKham.FormattingEnabled = true;
            this.cbLoaiKham.Items.AddRange(new object[] {
            "Khám thường",
            "Khám định kỳ",
            "Cấp cứu"});
            this.cbLoaiKham.Location = new System.Drawing.Point(140, 287);
            this.cbLoaiKham.Name = "cbLoaiKham";
            this.cbLoaiKham.Size = new System.Drawing.Size(255, 28);
            this.cbLoaiKham.TabIndex = 11;
            this.cbLoaiKham.Text = "Khám thường";

            // 
            // btnLuuPhieuKham
            // 
            this.btnLuuPhieuKham.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.btnLuuPhieuKham.ForeColor = System.Drawing.Color.White;
            this.btnLuuPhieuKham.Location = new System.Drawing.Point(140, 340);
            this.btnLuuPhieuKham.Name = "btnLuuPhieuKham";
            this.btnLuuPhieuKham.Size = new System.Drawing.Size(255, 40);
            this.btnLuuPhieuKham.TabIndex = 12;
            this.btnLuuPhieuKham.Text = "Lưu Phiếu Khám Bệnh";
            this.btnLuuPhieuKham.UseVisualStyleBackColor = false;
            this.btnLuuPhieuKham.Click += new System.EventHandler(this.btnLuuPhieuKham_Click);

            // 
            // FrmKhamBenh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 560);
            this.Controls.Add(this.grpLapPhieu);
            this.Controls.Add(this.dgvLichSuKham);
            this.Controls.Add(this.btnTraCuu);
            this.Controls.Add(this.txtMaHoSoTraCuu);
            this.Controls.Add(this.lblMaHoSoTraCuu);
            this.Controls.Add(this.lblTitle);
            this.Name = "FrmKhamBenh";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần Mềm Quản Lý Khám Bệnh & Chẩn Đoán";
            ((System.ComponentModel.ISupportInitialize)(this.dgvLichSuKham)).EndInit();
            this.grpLapPhieu.ResumeLayout(false);
            this.grpLapPhieu.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblMaHoSoTraCuu;
        private System.Windows.Forms.TextBox txtMaHoSoTraCuu;
        private System.Windows.Forms.Button btnTraCuu;
        private System.Windows.Forms.DataGridView dgvLichSuKham;
        private System.Windows.Forms.GroupBox grpLapPhieu;
        private System.Windows.Forms.Label lblMaPhieuKham;
        private System.Windows.Forms.TextBox txtMaPhieuKham;
        private System.Windows.Forms.Label lblMaHoSo;
        private System.Windows.Forms.TextBox txtMaHoSo;
        private System.Windows.Forms.Label lblMaBacSi;
        private System.Windows.Forms.TextBox txtMaBacSi;
        private System.Windows.Forms.Label lblNgayGioKham;
        private System.Windows.Forms.DateTimePicker dtpNgayGioKham;
        private System.Windows.Forms.Label lblTrieuChung;
        private System.Windows.Forms.TextBox txtTrieuChung;
        private System.Windows.Forms.Label lblLoaiKham;
        private System.Windows.Forms.ComboBox cbLoaiKham;
        private System.Windows.Forms.Button btnLuuPhieuKham;
    }
}