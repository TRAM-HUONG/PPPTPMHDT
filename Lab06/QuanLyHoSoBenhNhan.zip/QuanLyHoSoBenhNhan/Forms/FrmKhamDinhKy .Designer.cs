﻿namespace QuanLyHoSoBenhNhan.Forms
{
    partial class FrmKhamDinhKy
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.dgvHoSoHopLe = new System.Windows.Forms.DataGridView();
            this.grpDatLich = new System.Windows.Forms.GroupBox();
            this.lblMaHoSo = new System.Windows.Forms.Label();
            this.txtMaHoSo = new System.Windows.Forms.TextBox();
            this.lblMaBacSi = new System.Windows.Forms.Label();
            this.cbBacSi = new System.Windows.Forms.ComboBox();
            this.lblNgayHen = new System.Windows.Forms.Label();
            this.dtpNgayHen = new System.Windows.Forms.DateTimePicker();
            this.lblGhiChu = new System.Windows.Forms.Label();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.btnDatLich = new System.Windows.Forms.Button();
            this.lblDanhSach = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.dgvHoSoHopLe)).BeginInit();
            this.grpDatLich.SuspendLayout();
            this.SuspendLayout();

            // 
            // lblTitle
            // 
            this.lblTitle.AutoSize = true;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.lblTitle.Location = new System.Drawing.Point(320, 15);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(400, 37);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "QUẢN LÝ KHÁM ĐỊNH KỲ QUÝ";

            // 
            // lblDanhSach
            // 
            this.lblDanhSach.AutoSize = true;
            this.lblDanhSach.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblDanhSach.Location = new System.Drawing.Point(30, 70);
            this.lblDanhSach.Name = "lblDanhSach";
            this.lblDanhSach.Size = new System.Drawing.Size(262, 20);
            this.lblDanhSach.TabIndex = 1;
            this.lblDanhSach.Text = "Danh Sách Hồ Sơ Đủ Điều Kiện Quý:";

            // 
            // dgvHoSoHopLe
            // 
            this.dgvHoSoHopLe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoSoHopLe.Location = new System.Drawing.Point(30, 95);
            this.dgvHoSoHopLe.Name = "dgvHoSoHopLe";
            this.dgvHoSoHopLe.RowHeadersWidth = 51;
            this.dgvHoSoHopLe.RowTemplate.Height = 24;
            this.dgvHoSoHopLe.Size = new System.Drawing.Size(560, 420);
            this.dgvHoSoHopLe.TabIndex = 2;
            this.dgvHoSoHopLe.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvHoSoHopLe_CellClick);

            // 
            // grpDatLich
            // 
            this.grpDatLich.Controls.Add(this.btnDatLich);
            this.grpDatLich.Controls.Add(this.txtGhiChu);
            this.grpDatLich.Controls.Add(this.lblGhiChu);
            this.grpDatLich.Controls.Add(this.dtpNgayHen);
            this.grpDatLich.Controls.Add(this.lblNgayHen);
            this.grpDatLich.Controls.Add(this.cbBacSi);
            this.grpDatLich.Controls.Add(this.lblMaBacSi);
            this.grpDatLich.Controls.Add(this.txtMaHoSo);
            this.grpDatLich.Controls.Add(this.lblMaHoSo);
            this.grpDatLich.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.grpDatLich.Location = new System.Drawing.Point(610, 95);
            this.grpDatLich.Name = "grpDatLich";
            this.grpDatLich.Size = new System.Drawing.Size(370, 420);
            this.grpDatLich.TabIndex = 3;
            this.grpDatLich.TabStop = false;
            this.grpDatLich.Text = "Đặt Lịch Hẹn Khám Sức Khỏe Định Kỳ";

            // 
            // lblMaHoSo
            // 
            this.lblMaHoSo.AutoSize = true;
            this.lblMaHoSo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaHoSo.Location = new System.Drawing.Point(20, 30);
            this.lblMaHoSo.Name = "lblMaHoSo";
            this.lblMaHoSo.Size = new System.Drawing.Size(73, 20);
            this.lblMaHoSo.TabIndex = 0;
            this.lblMaHoSo.Text = "Mã hồ sơ:";

            // 
            // txtMaHoSo
            // 
            this.txtMaHoSo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtMaHoSo.Location = new System.Drawing.Point(20, 53);
            this.txtMaHoSo.Name = "txtMaHoSo";
            this.txtMaHoSo.ReadOnly = true;
            this.txtMaHoSo.Size = new System.Drawing.Size(330, 27);
            this.txtMaHoSo.TabIndex = 1;

            // 
            // lblMaBacSi
            // 
            this.lblMaBacSi.AutoSize = true;
            this.lblMaBacSi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblMaBacSi.Location = new System.Drawing.Point(20, 90);
            this.lblMaBacSi.Name = "lblMaBacSi";
            this.lblMaBacSi.Size = new System.Drawing.Size(91, 20);
            this.lblMaBacSi.TabIndex = 2;
            this.lblMaBacSi.Text = "Bác sĩ khám:";

            // 
            // cbBacSi
            // 
            this.cbBacSi.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.cbBacSi.FormattingEnabled = true;
            this.cbBacSi.Location = new System.Drawing.Point(20, 113);
            this.cbBacSi.Name = "cbBacSi";
            this.cbBacSi.Size = new System.Drawing.Size(330, 28);
            this.cbBacSi.TabIndex = 3;

            // 
            // lblNgayHen
            // 
            this.lblNgayHen.AutoSize = true;
            this.lblNgayHen.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNgayHen.Location = new System.Drawing.Point(20, 150);
            this.lblNgayHen.Name = "lblNgayHen";
            this.lblNgayHen.Size = new System.Drawing.Size(130, 20);
            this.lblNgayHen.TabIndex = 4;
            this.lblNgayHen.Text = "Ngày giờ hẹn khám:";

            // 
            // dtpNgayHen
            // 
            this.dtpNgayHen.CustomFormat = "yyyy-MM-dd HH:mm";
            this.dtpNgayHen.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.dtpNgayHen.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgayHen.Location = new System.Drawing.Point(20, 173);
            this.dtpNgayHen.Name = "dtpNgayHen";
            this.dtpNgayHen.Size = new System.Drawing.Size(330, 27);
            this.dtpNgayHen.TabIndex = 5;

            // 
            // lblGhiChu
            // 
            this.lblGhiChu.AutoSize = true;
            this.lblGhiChu.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblGhiChu.Location = new System.Drawing.Point(20, 210);
            this.lblGhiChu.Name = "lblGhiChu";
            this.lblGhiChu.Size = new System.Drawing.Size(61, 20);
            this.lblGhiChu.TabIndex = 6;
            this.lblGhiChu.Text = "Ghi chú:";

            // 
            // txtGhiChu
            // 
            this.txtGhiChu.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtGhiChu.Location = new System.Drawing.Point(20, 233);
            this.txtGhiChu.Multiline = true;
            this.txtGhiChu.Name = "txtGhiChu";
            this.txtGhiChu.Size = new System.Drawing.Size(330, 85);
            this.txtGhiChu.TabIndex = 7;

            // 
            // btnDatLich
            // 
            this.btnDatLich.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(54)))), ((int)(((byte)(93)))));
            this.btnDatLich.ForeColor = System.Drawing.Color.White;
            this.btnDatLich.Location = new System.Drawing.Point(20, 340);
            this.btnDatLich.Name = "btnDatLich";
            this.btnDatLich.Size = new System.Drawing.Size(330, 45);
            this.btnDatLich.TabIndex = 8;
            this.btnDatLich.Text = "Xác Nhận Đặt Lịch Hẹn";
            this.btnDatLich.UseVisualStyleBackColor = false;
            this.btnDatLich.Click += new System.EventHandler(this.btnDatLich_Click);

            // 
            // FrmKhamDinhKy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1010, 550);
            this.Controls.Add(this.grpDatLich);
            this.Controls.Add(this.dgvHoSoHopLe);
            this.Controls.Add(this.lblDanhSach);
            this.Controls.Add(this.lblTitle);
            this.Name = "FrmKhamDinhKy";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phần Mềm Quản Lý Khám Sức Khỏe Định Kỳ Quý";
            this.Load += new System.EventHandler(this.FrmKhamDinhKy_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoSoHopLe)).EndInit();
            this.grpDatLich.ResumeLayout(false);
            this.grpDatLich.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.DataGridView dgvHoSoHopLe;
        private System.Windows.Forms.GroupBox grpDatLich;
        private System.Windows.Forms.Label lblMaHoSo;
        private System.Windows.Forms.TextBox txtMaHoSo;
        private System.Windows.Forms.Label lblMaBacSi;
        private System.Windows.Forms.ComboBox cbBacSi;
        private System.Windows.Forms.Label lblNgayHen;
        private System.Windows.Forms.DateTimePicker dtpNgayHen;
        private System.Windows.Forms.Label lblGhiChu;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Button btnDatLich;
        private System.Windows.Forms.Label lblDanhSach;
    }
}