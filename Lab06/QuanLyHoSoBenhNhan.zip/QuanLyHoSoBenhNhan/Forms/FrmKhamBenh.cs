﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmKhamBenh : Form
    {
        private KhamBenhService _khamBenhService;

        public FrmKhamBenh()
        {
            InitializeComponent();
            _khamBenhService = new KhamBenhService();
        }

        private void btnTraCuu_Click(object sender, EventArgs e)
        {
            string maHoSo = txtMaHoSoTraCuu.Text.Trim();
            if (string.IsNullOrEmpty(maHoSo))
            {
                MessageBox.Show("Vui lòng nhập mã hồ sơ để tra cứu lịch sử!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Form gọi Service lấy dữ liệu lịch sử khám và nạp vào DataGridView
            dgvLichSuKham.DataSource = _khamBenhService.TraCuuLichSuBenhAn(maHoSo);

            // Tự động điền mã hồ sơ sang ô lập phiếu để bác sĩ thao tác nhanh
            txtMaHoSo.Text = maHoSo;
        }

        private void btnLuuPhieuKham_Click(object sender, EventArgs e)
        {
            // 1. Lấy dữ liệu từ giao diện Form
            string maPhieuKham = txtMaPhieuKham.Text.Trim();
            string maHoSo = txtMaHoSo.Text.Trim();
            string maBacSi = txtMaBacSi.Text.Trim();
            DateTime ngayGioKham = dtpNgayGioKham.Value;
            string trieuChung = txtTrieuChung.Text.Trim();
            string loaiKham = cbLoaiKham.SelectedItem?.ToString() ?? "Khám thường";

            // 2. Gọi Service xử lý nghiệp vụ lưu phiếu khám
            KetQuaXuLy ketQua = _khamBenhService.LuuPhieuKham(maPhieuKham, maHoSo, maBacSi, ngayGioKham, trieuChung, loaiKham);

            // 3. Form chỉ hiển thị thông báo và nạp lại dữ liệu theo đúng kiến trúc
            MessageBox.Show(ketQua.ThongBao, "Thông báo hệ thống", MessageBoxButtons.OK, ketQua.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (ketQua.ThanhCong)
            {
                // Nạp lại dữ liệu lưới lịch sử khám bệnh
                txtMaHoSoTraCuu.Text = maHoSo;
                btnTraCuu_Click(sender, e);

                // Làm sạch form lập phiếu
                txtMaPhieuKham.Clear();
                txtTrieuChung.Clear();
                txtMaPhieuKham.Focus();
            }
        }
    }
}