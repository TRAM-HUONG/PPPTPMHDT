﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmTraCuuHoSo : Form
    {
        private TraCuuService _traCuuService;

        public FrmTraCuuHoSo()
        {
            InitializeComponent();
            _traCuuService = new TraCuuService();
        }

        private void FrmTraCuuHoSo_Load(object sender, EventArgs e)
        {
            // Tải toàn bộ danh sách ban đầu khi mở form
            LoadDuLieu("");
        }

        private void btnTraCuu_Click(object sender, EventArgs e)
        {
            string tuKhoa = txtTuKhoa.Text.Trim();
            LoadDuLieu(tuKhoa);
        }

        private void LoadDuLieu(string tuKhoa)
        {
            // Form gọi Service lấy dữ liệu và hiển thị lên DataGridView
            dgvKetQua.DataSource = _traCuuService.TraCuuHoSoVaLichSu(tuKhoa);
        }
    }
}