﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmKhamDinhKy : Form
    {
        private KhamDinhKyService _khamDinhKyService;

        public FrmKhamDinhKy()
        {
            InitializeComponent();
            _khamDinhKyService = new KhamDinhKyService();
        }

        private void FrmKhamDinhKy_Load(object sender, EventArgs e)
        {
            LoadDanhSachHoSo();
            LoadDanhSachBacSi();
        }

        private void LoadDanhSachHoSo()
        {
            dgvHoSoHopLe.DataSource = _khamDinhKyService.LayDanhSachHoSoDuDienKien();
        }

        private void LoadDanhSachBacSi()
        {
            // Nạp danh sách bác sĩ từ CSDL vào ComboBox
            cbBacSi.DataSource = _khamDinhKyService.LayDanhSachBacSi();
            cbBacSi.DisplayMember = "HoTen";   // Hiển thị tên bác sĩ cho người dùng dễ chọn
            cbBacSi.ValueMember = "MaBacSi";     // Giá trị ngầm là Mã bác sĩ để lưu vào CSDL
        }

        private void dgvHoSoHopLe_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvHoSoHopLe.Rows[e.RowIndex];
                txtMaHoSo.Text = row.Cells["MaHoSo"].Value?.ToString();
            }
        }

        private void btnDatLich_Click(object sender, EventArgs e)
        {
            string maHoSo = txtMaHoSo.Text.Trim();
            string maBacSi = cbBacSi.SelectedValue?.ToString(); // Lấy MaBacSi thực tế từ ComboBox
            DateTime ngayHen = dtpNgayHen.Value;
            string ghiChu = txtGhiChu.Text.Trim();

            // Gọi Service xử lý đặt lịch với mã bác sĩ thật
            KetQuaXuLy ketQua = _khamDinhKyService.DatLichKhamDinhKy(maHoSo, maBacSi, ngayHen, ghiChu);

            MessageBox.Show(ketQua.ThongBao, "Thông báo hệ thống", MessageBoxButtons.OK, ketQua.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (ketQua.ThanhCong)
            {
                txtMaHoSo.Clear();
                txtGhiChu.Clear();
                LoadDanhSachHoSo();
            }
        }
    }
}