﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmVienPhi : Form
    {
        private VienPhiService _vienPhiService;

        public FrmVienPhi()
        {
            InitializeComponent();
            _vienPhiService = new VienPhiService();
        }

        private void btnTinhTien_Click(object sender, EventArgs e)
        {
            string maPhieuKham = txtMaPhieuKham.Text.Trim();
            if (string.IsNullOrEmpty(maPhieuKham))
            {
                MessageBox.Show("Vui lòng nhập mã phiếu khám để tính viện phí!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Form gọi Service tính tổng viện phí
            decimal tongTien = _vienPhiService.TinhTongTienVienPhi(maPhieuKham);
            txtTongTien.Text = tongTien.ToString("N0") + " VNĐ";
        }

        private void btnThanhToanVaXuatVien_Click(object sender, EventArgs e)
        {
            // 1. Lấy dữ liệu từ giao diện Form
            string maHoaDon = txtMaHoaDon.Text.Trim();
            string maPhieuKham = txtMaPhieuKham.Text.Trim();
            DateTime ngayThanhToan = dtpNgayThanhToan.Value;

            string tongTienStr = txtTongTien.Text.Replace(" VNĐ", "").Replace(",", "").Trim();
            if (!decimal.TryParse(tongTienStr, out decimal tongTien) || tongTien <= 0)
            {
                MessageBox.Show("Vui lòng tính tổng tiền viện phí trước khi thanh toán!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 2. Gọi Service xử lý nghiệp vụ thanh toán viện phí và xuất viện
            KetQuaXuLy ketQua = _vienPhiService.ThanhToanVienPhi(maHoaDon, maPhieuKham, ngayThanhToan, tongTien);

            // 3. Form chỉ hiển thị thông báo và làm sạch form theo đúng kiến trúc
            MessageBox.Show(ketQua.ThongBao, "Thông báo hệ thống", MessageBoxButtons.OK, ketQua.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (ketQua.ThanhCong)
            {
                txtMaHoaDon.Clear();
                txtMaPhieuKham.Clear();
                txtTongTien.Text = "0 VNĐ";
                txtMaHoaDon.Focus();
            }
        }
    }
}