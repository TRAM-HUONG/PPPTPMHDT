﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Services;

namespace QuanLyHoSoBenhNhan.Forms
{
    public partial class FrmThongKeBaoCao : Form
    {
        private ThongKeService _thongKeService;

        public FrmThongKeBaoCao()
        {
            InitializeComponent();
            _thongKeService = new ThongKeService();
        }

        private void FrmThongKeBaoCao_Load(object sender, EventArgs e)
        {
            LoadDuLieuThongKe();
        }

        private void LoadDuLieuThongKe()
        {
            // Form gọi Service nạp dữ liệu thống kê lên các tab tương ứng
            dgvDoanhThu.DataSource = _thongKeService.ThongKeDoanhThuVienPhi();
            dgvLuotKham.DataSource = _thongKeService.ThongKeLuotKhamTheoKhoa();
            dgvKhoThuoc.DataSource = _thongKeService.ThongKeKhoThuoc();
        }

        private void btnXuatBaoCao_Click(object sender, EventArgs e)
        {
            LoadDuLieuThongKe();
            MessageBox.Show("Đã làm mới và cập nhật số liệu báo cáo thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}