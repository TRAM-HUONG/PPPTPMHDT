﻿using System;
using System.Windows.Forms;
using QuanLyHoSoBenhNhan.Forms; // Khớp với namespace của bạn

namespace QuanLyHoSoBenhNhan
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Khởi chạy FrmMain làm màn hình gốc của ứng dụng
            Application.Run(new FrmMain());
        }
    }
}