﻿
namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmPhanCongHDV
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtMaPC = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboHDV = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboLoai = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.cboDoiTuong = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.numThuLao = new System.Windows.Forms.NumericUpDown();
            this.btnPhanCong = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.numThuLao)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();

            this.label1.AutoSize = true; this.label1.Location = new System.Drawing.Point(30, 25); this.label1.Text = "Mã phân công:";
            this.txtMaPC.Location = new System.Drawing.Point(140, 22); this.txtMaPC.Size = new System.Drawing.Size(150, 22);

            this.label2.AutoSize = true; this.label2.Location = new System.Drawing.Point(330, 25); this.label2.Text = "Hướng dẫn viên:";
            this.cboHDV.Location = new System.Drawing.Point(450, 22); this.cboHDV.Size = new System.Drawing.Size(280, 24);
            this.cboHDV.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.label3.AutoSize = true; this.label3.Location = new System.Drawing.Point(30, 70); this.label3.Text = "Loại đối tượng:";
            this.cboLoai.Location = new System.Drawing.Point(140, 67); this.cboLoai.Size = new System.Drawing.Size(150, 24);
            this.cboLoai.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoai.SelectedIndexChanged += new System.EventHandler(this.cboLoai_SelectedIndexChanged);

            this.label4.AutoSize = true; this.label4.Location = new System.Drawing.Point(330, 70); this.label4.Text = "Chuyến / đoàn:";
            this.cboDoiTuong.Location = new System.Drawing.Point(450, 67); this.cboDoiTuong.Size = new System.Drawing.Size(280, 24);
            this.cboDoiTuong.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.label5.AutoSize = true; this.label5.Location = new System.Drawing.Point(30, 115); this.label5.Text = "Thù lao tour:";
            this.numThuLao.Location = new System.Drawing.Point(140, 112); this.numThuLao.Size = new System.Drawing.Size(150, 22);
            this.numThuLao.Increment = new decimal(new int[] { 200000, 0, 0, 0 });
            this.numThuLao.Maximum = new decimal(new int[] { 50000000, 0, 0, 0 });
            this.numThuLao.Value = new decimal(new int[] { 1500000, 0, 0, 0 });

            this.btnPhanCong.Location = new System.Drawing.Point(760, 60); this.btnPhanCong.Size = new System.Drawing.Size(140, 40);
            this.btnPhanCong.Text = "Phân công"; this.btnPhanCong.Click += new System.EventHandler(this.btnPhanCong_Click);

            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.Location = new System.Drawing.Point(30, 160); this.dgv.Size = new System.Drawing.Size(924, 430);

            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(834, 610); this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.Text = "Đóng"; this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 660);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.btnPhanCong);
            this.Controls.Add(this.numThuLao);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.cboDoiTuong);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cboLoai);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboHDV);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMaPC);
            this.Controls.Add(this.label1);
            this.Name = "FrmPhanCongHDV";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phân công hướng dẫn viên";
            this.Load += new System.EventHandler(this.FrmPhanCongHDV_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numThuLao)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMaPC;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboHDV;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboLoai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cboDoiTuong;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numThuLao;
        private System.Windows.Forms.Button btnPhanCong;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnDong;
    }
}