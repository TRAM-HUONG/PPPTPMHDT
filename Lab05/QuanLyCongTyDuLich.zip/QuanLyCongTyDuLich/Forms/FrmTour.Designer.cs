﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmTour
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.labelSelectTour = new System.Windows.Forms.Label();
            this.cboTour = new System.Windows.Forms.ComboBox();
            this.tabTour = new System.Windows.Forms.TabControl();
            this.tabTourItem = new System.Windows.Forms.TabPage();
            this.dgvTour = new System.Windows.Forms.DataGridView();
            this.tabDiemDungPage = new System.Windows.Forms.TabPage();
            this.dgvDiemDung = new System.Windows.Forms.DataGridView();
            this.tabChangPT = new System.Windows.Forms.TabPage();
            this.dgvChang = new System.Windows.Forms.DataGridView();
            this.tabDTQ = new System.Windows.Forms.TabPage();
            this.dgvTQ = new System.Windows.Forms.DataGridView();

            // Các control nhập liệu thêm Tour
            this.labelMa = new System.Windows.Forms.Label();
            this.txtMaTour = new System.Windows.Forms.TextBox();
            this.labelTen = new System.Windows.Forms.Label();
            this.txtTenTour = new System.Windows.Forms.TextBox();
            this.labelSoNgay = new System.Windows.Forms.Label();
            this.nudSoNgay = new System.Windows.Forms.NumericUpDown();
            this.labelSoDem = new System.Windows.Forms.Label();
            this.numDem = new System.Windows.Forms.NumericUpDown();
            this.labelGia = new System.Windows.Forms.Label();
            this.txtDonGia = new System.Windows.Forms.TextBox();
            this.labelMoTa = new System.Windows.Forms.Label();
            this.txtMoTa = new System.Windows.Forms.TextBox();
            this.btnThemTour = new System.Windows.Forms.Button();
            this.btnDong = new System.Windows.Forms.Button();

            this.tabTour.SuspendLayout();
            this.tabTourItem.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTour)).BeginInit();
            this.tabDiemDungPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiemDung)).BeginInit();
            this.tabChangPT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvChang)).BeginInit();
            this.tabDTQ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoNgay)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDem)).BeginInit();
            this.SuspendLayout();

            // --- ComboBox chọn tour phía trên ---
            this.labelSelectTour.AutoSize = true;
            this.labelSelectTour.Location = new System.Drawing.Point(20, 25);
            this.labelSelectTour.Size = new System.Drawing.Size(235, 17);
            this.labelSelectTour.Text = "Tour đang chọn (cho các tab hành trình):";

            this.cboTour.FormattingEnabled = true;
            this.cboTour.Location = new System.Drawing.Point(270, 22);
            this.cboTour.Size = new System.Drawing.Size(300, 24);
            this.cboTour.SelectedIndexChanged += new System.EventHandler(this.cboTour_SelectedIndexChanged);

            // --- TabControl ---
            this.tabTour.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabTour.Controls.Add(this.tabTourItem);
            this.tabTour.Controls.Add(this.tabDiemDungPage);
            this.tabTour.Controls.Add(this.tabChangPT);
            this.tabTour.Controls.Add(this.tabDTQ);
            this.tabTour.Location = new System.Drawing.Point(20, 65);
            this.tabTour.Name = "tabTour";
            this.tabTour.SelectedIndex = 0;
            this.tabTour.Size = new System.Drawing.Size(944, 430);
            this.tabTour.TabIndex = 2;

            // --- Tab 1: Tour ---
            this.tabTourItem.Controls.Add(this.dgvTour);
            this.tabTourItem.Location = new System.Drawing.Point(4, 25);
            this.tabTourItem.Name = "tabTourItem";
            this.tabTourItem.Size = new System.Drawing.Size(936, 401);
            this.tabTourItem.Text = "Tour";
            this.tabTourItem.UseVisualStyleBackColor = true;

            this.dgvTour.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTour.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTour.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTour.Location = new System.Drawing.Point(15, 15);
            this.dgvTour.Name = "dgvTour";
            this.dgvTour.Size = new System.Drawing.Size(905, 370);

            // --- Tab 2: Điểm dừng ---
            this.tabDiemDungPage.Controls.Add(this.dgvDiemDung);
            this.tabDiemDungPage.Location = new System.Drawing.Point(4, 25);
            this.tabDiemDungPage.Name = "tabDiemDungPage";
            this.tabDiemDungPage.Size = new System.Drawing.Size(936, 401);
            this.tabDiemDungPage.Text = "Điểm dừng";
            this.tabDiemDungPage.UseVisualStyleBackColor = true;

            this.dgvDiemDung.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDiemDung.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDiemDung.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDiemDung.Location = new System.Drawing.Point(15, 15);
            this.dgvDiemDung.Name = "dgvDiemDung";
            this.dgvDiemDung.Size = new System.Drawing.Size(905, 370);

            // --- Tab 3: Phương tiện theo chặng ---
            this.tabChangPT.Controls.Add(this.dgvChang);
            this.tabChangPT.Location = new System.Drawing.Point(4, 25);
            this.tabChangPT.Name = "tabChangPT";
            this.tabChangPT.Size = new System.Drawing.Size(936, 401);
            this.tabChangPT.Text = "Phương tiện theo chặng";
            this.tabChangPT.UseVisualStyleBackColor = true;

            this.dgvChang.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvChang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvChang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvChang.Location = new System.Drawing.Point(15, 15);
            this.dgvChang.Name = "dgvChang";
            this.dgvChang.Size = new System.Drawing.Size(905, 370);

            // --- Tab 4: Điểm tham quan ---
            this.tabDTQ.Controls.Add(this.dgvTQ);
            this.tabDTQ.Location = new System.Drawing.Point(4, 25);
            this.tabDTQ.Name = "tabDTQ";
            this.tabDTQ.Size = new System.Drawing.Size(936, 401);
            this.tabDTQ.Text = "Điểm tham quan";
            this.tabDTQ.UseVisualStyleBackColor = true;

            this.dgvTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTQ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTQ.Location = new System.Drawing.Point(15, 15);
            this.dgvTQ.Name = "dgvTQ";
            this.dgvTQ.Size = new System.Drawing.Size(905, 370);

            // --- Nhập liệu thêm Tour (Phần dưới form) ---
            this.labelMa.AutoSize = true;
            this.labelMa.Location = new System.Drawing.Point(20, 520);
            this.labelMa.Text = "Mã tour:";

            this.txtMaTour.Location = new System.Drawing.Point(120, 517);
            this.txtMaTour.Size = new System.Drawing.Size(125, 22);

            this.labelTen.AutoSize = true;
            this.labelTen.Location = new System.Drawing.Point(275, 520);
            this.labelTen.Text = "Tên tour:";

            this.txtTenTour.Location = new System.Drawing.Point(340, 517);
            this.txtTenTour.Size = new System.Drawing.Size(365, 22);

            this.labelSoNgay.AutoSize = true;
            this.labelSoNgay.Location = new System.Drawing.Point(20, 565);
            this.labelSoNgay.Text = "Số ngày:";

            this.nudSoNgay.Location = new System.Drawing.Point(120, 563);
            this.nudSoNgay.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.nudSoNgay.Size = new System.Drawing.Size(60, 22);
            this.nudSoNgay.Value = new decimal(new int[] { 3, 0, 0, 0 });

            this.labelSoDem.AutoSize = true;
            this.labelSoDem.Location = new System.Drawing.Point(275, 565);
            this.labelSoDem.Text = "Số đêm:";

            this.numDem.Location = new System.Drawing.Point(340, 563);
            this.numDem.Size = new System.Drawing.Size(60, 22);
            this.numDem.Value = new decimal(new int[] { 2, 0, 0, 0 });

            this.labelGia.AutoSize = true;
            this.labelGia.Location = new System.Drawing.Point(440, 565);
            this.labelGia.Text = "Đơn giá / khách:";

            this.txtDonGia.Location = new System.Drawing.Point(555, 563);
            this.txtDonGia.Size = new System.Drawing.Size(150, 22);
            this.txtDonGia.Text = "5500000";

            this.labelMoTa.AutoSize = true;
            this.labelMoTa.Location = new System.Drawing.Point(20, 610);
            this.labelMoTa.Text = "Mô tả:";

            this.txtMoTa.Location = new System.Drawing.Point(120, 607);
            this.txtMoTa.Size = new System.Drawing.Size(585, 22);

            this.btnThemTour.Location = new System.Drawing.Point(740, 598);
            this.btnThemTour.Size = new System.Drawing.Size(130, 35);
            this.btnThemTour.Text = "Thêm tour";
            this.btnThemTour.UseVisualStyleBackColor = true;
            this.btnThemTour.Click += new System.EventHandler(this.btnThemTour_Click);

            // --- Nút Đóng ---
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(844, 655);
            this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // --- Cấu hình Form ---
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 702);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.btnThemTour);
            this.Controls.Add(this.txtMoTa);
            this.Controls.Add(this.labelMoTa);
            this.Controls.Add(this.txtDonGia);
            this.Controls.Add(this.labelGia);
            this.Controls.Add(this.numDem);
            this.Controls.Add(this.labelSoDem);
            this.Controls.Add(this.nudSoNgay);
            this.Controls.Add(this.labelSoNgay);
            this.Controls.Add(this.txtTenTour);
            this.Controls.Add(this.labelTen);
            this.Controls.Add(this.txtMaTour);
            this.Controls.Add(this.labelMa);
            this.Controls.Add(this.tabTour);
            this.Controls.Add(this.cboTour);
            this.Controls.Add(this.labelSelectTour);
            this.Name = "FrmTour";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tour - hành trình";
            this.Load += new System.EventHandler(this.FrmTour_Load);

            this.tabTour.ResumeLayout(false);
            this.tabTourItem.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTour)).EndInit();
            this.tabDiemDungPage.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDiemDung)).EndInit();
            this.tabChangPT.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvChang)).EndInit();
            this.tabDTQ.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSoNgay)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDem)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label labelSelectTour;
        private System.Windows.Forms.ComboBox cboTour;
        private System.Windows.Forms.TabControl tabTour;
        private System.Windows.Forms.TabPage tabTourItem;
        private System.Windows.Forms.TabPage tabDiemDungPage;
        private System.Windows.Forms.TabPage tabChangPT;
        private System.Windows.Forms.TabPage tabDTQ;

        private System.Windows.Forms.DataGridView dgvTour;
        private System.Windows.Forms.DataGridView dgvDiemDung;
        private System.Windows.Forms.DataGridView dgvChang;
        private System.Windows.Forms.DataGridView dgvTQ;

        private System.Windows.Forms.Label labelMa;
        private System.Windows.Forms.TextBox txtMaTour;
        private System.Windows.Forms.Label labelTen;
        private System.Windows.Forms.TextBox txtTenTour;
        private System.Windows.Forms.Label labelSoNgay;
        private System.Windows.Forms.NumericUpDown nudSoNgay;
        private System.Windows.Forms.Label labelSoDem;
        private System.Windows.Forms.NumericUpDown numDem;
        private System.Windows.Forms.Label labelGia;
        private System.Windows.Forms.TextBox txtDonGia;
        private System.Windows.Forms.Label labelMoTa;
        private System.Windows.Forms.TextBox txtMoTa;
        private System.Windows.Forms.Button btnThemTour;
        private System.Windows.Forms.Button btnDong;
    }
}