﻿
namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmKetThucKhaoSat
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabKT = new System.Windows.Forms.TabControl();

            // Tab 1: Thanh toán đoàn
            this.tabThanhToan = new System.Windows.Forms.TabPage();
            this.dgvDoan = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSoTT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSoDK = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtTT = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.numTien = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.txtGhiChu = new System.Windows.Forms.TextBox();
            this.btnThanhToan = new System.Windows.Forms.Button();

            // Tab 2: Khảo sát khách hàng
            this.tabKhaoSat = new System.Windows.Forms.TabPage();
            this.label6 = new System.Windows.Forms.Label();
            this.cboLoaiKS = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.cboDangKy = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMaKS = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.dtGui = new System.Windows.Forms.DateTimePicker();
            this.btnGui = new System.Windows.Forms.Button();
            this.dgvKS = new System.Windows.Forms.DataGridView();
            this.label10 = new System.Windows.Forms.Label();
            this.txtKSChon = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dtPH = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.numDiem = new System.Windows.Forms.NumericUpDown();
            this.label13 = new System.Windows.Forms.Label();
            this.txtGopY = new System.Windows.Forms.TextBox();
            this.btnGhiPH = new System.Windows.Forms.Button();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabKT.SuspendLayout();
            this.tabThanhToan.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTien)).BeginInit();
            this.tabKhaoSat.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDiem)).BeginInit();
            this.SuspendLayout();

            this.tabKT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.tabKT.Controls.Add(this.tabThanhToan);
            this.tabKT.Controls.Add(this.tabKhaoSat);
            this.tabKT.Location = new System.Drawing.Point(12, 12);
            this.tabKT.Name = "tabKT";
            this.tabKT.SelectedIndex = 0;
            this.tabKT.Size = new System.Drawing.Size(960, 600);

            // --- Tab 1 ---
            this.tabThanhToan.Controls.Add(this.btnThanhToan);
            this.tabThanhToan.Controls.Add(this.txtGhiChu); this.tabThanhToan.Controls.Add(this.label5);
            this.tabThanhToan.Controls.Add(this.numTien); this.tabThanhToan.Controls.Add(this.label4);
            this.tabThanhToan.Controls.Add(this.dtTT); this.tabThanhToan.Controls.Add(this.label3);
            this.tabThanhToan.Controls.Add(this.txtSoDK); this.tabThanhToan.Controls.Add(this.label2);
            this.tabThanhToan.Controls.Add(this.txtSoTT); this.tabThanhToan.Controls.Add(this.label1);
            this.tabThanhToan.Controls.Add(this.dgvDoan);
            this.tabThanhToan.Text = "Thanh toán sau tour (đoàn)";
            this.tabThanhToan.UseVisualStyleBackColor = true;

            this.dgvDoan.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDoan.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDoan.Location = new System.Drawing.Point(20, 20); this.dgvDoan.Size = new System.Drawing.Size(912, 360);
            this.dgvDoan.SelectionChanged += new System.EventHandler(this.dgvDoan_SelectionChanged);

            this.label1.AutoSize = true; this.label1.Location = new System.Drawing.Point(20, 400); this.label1.Text = "Số thanh toán:";
            this.txtSoTT.Location = new System.Drawing.Point(135, 397); this.txtSoTT.Size = new System.Drawing.Size(120, 22);

            this.label2.AutoSize = true; this.label2.Location = new System.Drawing.Point(280, 400); this.label2.Text = "Phiếu đoàn:";
            this.txtSoDK.Location = new System.Drawing.Point(375, 397); this.txtSoDK.Size = new System.Drawing.Size(120, 22); this.txtSoDK.ReadOnly = true;

            this.label3.AutoSize = true; this.label3.Location = new System.Drawing.Point(520, 400); this.label3.Text = "Ngày thanh toán:";
            this.dtTT.Location = new System.Drawing.Point(645, 397); this.dtTT.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.label4.AutoSize = true; this.label4.Location = new System.Drawing.Point(20, 445); this.label4.Text = "Số tiền:";
            this.numTien.Location = new System.Drawing.Point(135, 442); this.numTien.Size = new System.Drawing.Size(150, 22);
            this.numTien.Increment = new decimal(new int[] { 1000000, 0, 0, 0 }); this.numTien.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });

            this.label5.AutoSize = true; this.label5.Location = new System.Drawing.Point(320, 445); this.label5.Text = "Ghi chú:";
            this.txtGhiChu.Location = new System.Drawing.Point(395, 442); this.txtGhiChu.Size = new System.Drawing.Size(370, 22);

            this.btnThanhToan.Location = new System.Drawing.Point(790, 435); this.btnThanhToan.Size = new System.Drawing.Size(140, 35);
            this.btnThanhToan.Text = "Ghi nhận thanh toán"; this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);

            // --- Tab 2 ---
            this.tabKhaoSat.Controls.Add(this.btnGhiPH); this.tabKhaoSat.Controls.Add(this.txtGopY); this.tabKhaoSat.Controls.Add(this.label13);
            this.tabKhaoSat.Controls.Add(this.numDiem); this.tabKhaoSat.Controls.Add(this.label12);
            this.tabKhaoSat.Controls.Add(this.dtPH); this.tabKhaoSat.Controls.Add(this.label11);
            this.tabKhaoSat.Controls.Add(this.txtKSChon); this.tabKhaoSat.Controls.Add(this.label10);
            this.tabKhaoSat.Controls.Add(this.dgvKS);
            this.tabKhaoSat.Controls.Add(this.btnGui); this.tabKhaoSat.Controls.Add(this.dtGui); this.tabKhaoSat.Controls.Add(this.label9);
            this.tabKhaoSat.Controls.Add(this.txtMaKS); this.tabKhaoSat.Controls.Add(this.label8);
            this.tabKhaoSat.Controls.Add(this.cboDangKy); this.tabKhaoSat.Controls.Add(this.label7);
            this.tabKhaoSat.Controls.Add(this.cboLoaiKS); this.tabKhaoSat.Controls.Add(this.label6);
            this.tabKhaoSat.Text = "Khảo sát khách hàng";
            this.tabKhaoSat.UseVisualStyleBackColor = true;

            this.label6.AutoSize = true; this.label6.Location = new System.Drawing.Point(20, 20); this.label6.Text = "Loại khách:";
            this.cboLoaiKS.Location = new System.Drawing.Point(110, 17); this.cboLoaiKS.Size = new System.Drawing.Size(100, 24);
            this.cboLoaiKS.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboLoaiKS.SelectedIndexChanged += new System.EventHandler(this.cboLoaiKS_SelectedIndexChanged);

            this.label7.AutoSize = true; this.label7.Location = new System.Drawing.Point(230, 20); this.label7.Text = "Đăng ký đã kết thúc:";
            this.cboDangKy.Location = new System.Drawing.Point(370, 17); this.cboDangKy.Size = new System.Drawing.Size(250, 24);
            this.cboDangKy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.label8.AutoSize = true; this.label8.Location = new System.Drawing.Point(640, 20); this.label8.Text = "Mã KS:";
            this.txtMaKS.Location = new System.Drawing.Point(700, 17); this.txtMaKS.Size = new System.Drawing.Size(90, 22);

            this.btnGui.Location = new System.Drawing.Point(810, 12); this.btnGui.Size = new System.Drawing.Size(120, 32);
            this.btnGui.Text = "Gửi phiếu khảo sát"; this.btnGui.Click += new System.EventHandler(this.btnGui_Click);

            this.dgvKS.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvKS.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKS.Location = new System.Drawing.Point(20, 60); this.dgvKS.Size = new System.Drawing.Size(912, 280);
            this.dgvKS.SelectionChanged += new System.EventHandler(this.dgvKS_SelectionChanged);

            this.label10.AutoSize = true; this.label10.Location = new System.Drawing.Point(20, 360); this.label10.Text = "Phiếu chọn:";
            this.txtKSChon.Location = new System.Drawing.Point(110, 357); this.txtKSChon.Size = new System.Drawing.Size(100, 22); this.txtKSChon.ReadOnly = true;

            this.label11.AutoSize = true; this.label11.Location = new System.Drawing.Point(230, 360); this.label11.Text = "Ngày phản hồi:";
            this.dtPH.Location = new System.Drawing.Point(340, 357); this.dtPH.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.label12.AutoSize = true; this.label12.Location = new System.Drawing.Point(500, 360); this.label12.Text = "Điểm (1-5):";
            this.numDiem.Location = new System.Drawing.Point(590, 357); this.numDiem.Size = new System.Drawing.Size(60, 22);
            this.numDiem.Minimum = new decimal(new int[] { 1, 0, 0, 0 }); this.numDiem.Maximum = new decimal(new int[] { 5, 0, 0, 0 }); this.numDiem.Value = new decimal(new int[] { 5, 0, 0, 0 });

            this.label13.AutoSize = true; this.label13.Location = new System.Drawing.Point(20, 400); this.label13.Text = "Góp ý:";
            this.txtGopY.Location = new System.Drawing.Point(110, 397); this.txtGopY.Size = new System.Drawing.Size(660, 22);

            this.btnGhiPH.Location = new System.Drawing.Point(790, 390); this.btnGhiPH.Size = new System.Drawing.Size(140, 35);
            this.btnGhiPH.Text = "Ghi nhận góp ý"; this.btnGhiPH.Click += new System.EventHandler(this.btnGhiPH_Click);

            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(852, 625); this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.Text = "Đóng"; this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 672);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabKT);
            this.Name = "FrmKetThucKhaoSat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kết thúc tour - thanh toán đoàn - khảo sát";
            this.Load += new System.EventHandler(this.FrmKetThucKhaoSat_Load);
            this.tabKT.ResumeLayout(false);
            this.tabThanhToan.ResumeLayout(false);
            this.tabThanhToan.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numTien)).EndInit();
            this.tabKhaoSat.ResumeLayout(false);
            this.tabKhaoSat.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numDiem)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabKT;
        private System.Windows.Forms.TabPage tabThanhToan;
        private System.Windows.Forms.DataGridView dgvDoan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSoTT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSoDK;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtTT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numTien;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtGhiChu;
        private System.Windows.Forms.Button btnThanhToan;

        private System.Windows.Forms.TabPage tabKhaoSat;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboLoaiKS;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cboDangKy;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtMaKS;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtGui;
        private System.Windows.Forms.Button btnGui;
        private System.Windows.Forms.DataGridView dgvKS;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtKSChon;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.DateTimePicker dtPH;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown numDiem;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtGopY;
        private System.Windows.Forms.Button btnGhiPH;

        private System.Windows.Forms.Button btnDong;
    }
}