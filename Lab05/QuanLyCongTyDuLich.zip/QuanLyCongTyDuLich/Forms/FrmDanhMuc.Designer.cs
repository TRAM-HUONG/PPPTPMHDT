﻿namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmDanhMuc
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabDanhMuc = new System.Windows.Forms.TabControl();

            // --- Tab 1: Phương tiện ---
            this.tabPT = new System.Windows.Forms.TabPage();
            this.dgvPT = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.txtPTMa = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtPTTen = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtPTGhiChu = new System.Windows.Forms.TextBox();
            this.btnThemPT = new System.Windows.Forms.Button();

            // --- Tab 2: Điểm bán vé ---
            this.tabDB = new System.Windows.Forms.TabPage();
            this.dgvDB = new System.Windows.Forms.DataGridView();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDBMa = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDBTen = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtDBDiaChi = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtDBDT = new System.Windows.Forms.TextBox();
            this.btnThemDB = new System.Windows.Forms.Button();

            // --- Tab 3: Hướng dẫn viên ---
            this.tabHDV = new System.Windows.Forms.TabPage();
            this.dgvHDV = new System.Windows.Forms.DataGridView();
            this.label8 = new System.Windows.Forms.Label();
            this.txtHDVMa = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtHDVTen = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtHDVDT = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.numLuong = new System.Windows.Forms.NumericUpDown();
            this.btnThemHDV = new System.Windows.Forms.Button();

            // --- Tab 4: Điểm tham quan ---
            this.tabDTQ = new System.Windows.Forms.TabPage();
            this.dgvDTQ = new System.Windows.Forms.DataGridView();
            this.label12 = new System.Windows.Forms.Label();
            this.txtDTQMa = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtDTQTen = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtDTQDiaDiem = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDTQNoiDung = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtDTQYNghia = new System.Windows.Forms.TextBox();
            this.btnThemDTQ = new System.Windows.Forms.Button();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabDanhMuc.SuspendLayout();
            this.tabPT.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPT)).BeginInit();
            this.tabDB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDB)).BeginInit();
            this.tabHDV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHDV)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLuong)).BeginInit();
            this.tabDTQ.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDTQ)).BeginInit();
            this.SuspendLayout();

            // --- TabControl chung ---
            this.tabDanhMuc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabDanhMuc.Controls.Add(this.tabPT);
            this.tabDanhMuc.Controls.Add(this.tabDB);
            this.tabDanhMuc.Controls.Add(this.tabHDV);
            this.tabDanhMuc.Controls.Add(this.tabDTQ);
            this.tabDanhMuc.Location = new System.Drawing.Point(12, 12);
            this.tabDanhMuc.Name = "tabDanhMuc";
            this.tabDanhMuc.SelectedIndex = 0;
            this.tabDanhMuc.Size = new System.Drawing.Size(960, 600);
            this.tabDanhMuc.TabIndex = 0;

            // ================= TAB 1: Phương tiện =================
            this.tabPT.Controls.Add(this.btnThemPT);
            this.tabPT.Controls.Add(this.txtPTGhiChu);
            this.tabPT.Controls.Add(this.label3);
            this.tabPT.Controls.Add(this.txtPTTen);
            this.tabPT.Controls.Add(this.label2);
            this.tabPT.Controls.Add(this.txtPTMa);
            this.tabPT.Controls.Add(this.label1);
            this.tabPT.Controls.Add(this.dgvPT);
            this.tabPT.Location = new System.Drawing.Point(4, 25);
            this.tabPT.Name = "tabPT";
            this.tabPT.Padding = new System.Windows.Forms.Padding(3);
            this.tabPT.Size = new System.Drawing.Size(952, 571);
            this.tabPT.Text = "Phương tiện";
            this.tabPT.UseVisualStyleBackColor = true;

            this.dgvPT.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvPT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPT.Location = new System.Drawing.Point(20, 20);
            this.dgvPT.Name = "dgvPT";
            this.dgvPT.Size = new System.Drawing.Size(912, 420);

            this.label1.Location = new System.Drawing.Point(35, 465);
            this.label1.Size = new System.Drawing.Size(52, 17);
            this.label1.Text = "Mã PT:";

            this.txtPTMa.Location = new System.Drawing.Point(135, 462);
            this.txtPTMa.Size = new System.Drawing.Size(160, 22);

            this.label2.Location = new System.Drawing.Point(440, 465);
            this.label2.Size = new System.Drawing.Size(58, 17);
            this.label2.Text = "Tên PT:";

            this.txtPTTen.Location = new System.Drawing.Point(525, 462);
            this.txtPTTen.Size = new System.Drawing.Size(320, 22);

            this.label3.Location = new System.Drawing.Point(35, 518);
            this.label3.Size = new System.Drawing.Size(54, 17);
            this.label3.Text = "Ghi chú:";

            this.txtPTGhiChu.Location = new System.Drawing.Point(135, 515);
            this.txtPTGhiChu.Size = new System.Drawing.Size(490, 22);

            this.btnThemPT.Location = new System.Drawing.Point(735, 510);
            this.btnThemPT.Size = new System.Drawing.Size(110, 35);
            this.btnThemPT.Text = "Thêm";
            this.btnThemPT.UseVisualStyleBackColor = true;
            this.btnThemPT.Click += new System.EventHandler(this.btnThemPT_Click);

            // ================= TAB 2: Điểm bán vé =================
            this.tabDB.Controls.Add(this.btnThemDB);
            this.tabDB.Controls.Add(this.txtDBDT);
            this.tabDB.Controls.Add(this.label7);
            this.tabDB.Controls.Add(this.txtDBDiaChi);
            this.tabDB.Controls.Add(this.label6);
            this.tabDB.Controls.Add(this.txtDBTen);
            this.tabDB.Controls.Add(this.label5);
            this.tabDB.Controls.Add(this.txtDBMa);
            this.tabDB.Controls.Add(this.label4);
            this.tabDB.Controls.Add(this.dgvDB);
            this.tabDB.Location = new System.Drawing.Point(4, 25);
            this.tabDB.Name = "tabDB";
            this.tabDB.Size = new System.Drawing.Size(952, 571);
            this.tabDB.Text = "Điểm bán vé";
            this.tabDB.UseVisualStyleBackColor = true;

            this.dgvDB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDB.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDB.Location = new System.Drawing.Point(20, 20);
            this.dgvDB.Size = new System.Drawing.Size(912, 420);

            this.label4.Location = new System.Drawing.Point(35, 465);
            this.label4.Size = new System.Drawing.Size(58, 17);
            this.label4.Text = "Mã điểm:";

            this.txtDBMa.Location = new System.Drawing.Point(135, 462);
            this.txtDBMa.Size = new System.Drawing.Size(160, 22);

            this.label5.Location = new System.Drawing.Point(440, 465);
            this.label5.Size = new System.Drawing.Size(64, 17);
            this.label5.Text = "Tên điểm:";

            this.txtDBTen.Location = new System.Drawing.Point(525, 462);
            this.txtDBTen.Size = new System.Drawing.Size(320, 22);

            this.label6.Location = new System.Drawing.Point(35, 518);
            this.label6.Size = new System.Drawing.Size(55, 17);
            this.label6.Text = "Địa chỉ:";

            this.txtDBDiaChi.Location = new System.Drawing.Point(135, 515);
            this.txtDBDiaChi.Size = new System.Drawing.Size(260, 22);

            this.label7.Location = new System.Drawing.Point(440, 518);
            this.label7.Size = new System.Drawing.Size(76, 17);
            this.label7.Text = "Điện thoại:";

            this.txtDBDT.Location = new System.Drawing.Point(525, 515);
            this.txtDBDT.Size = new System.Drawing.Size(160, 22);

            this.btnThemDB.Location = new System.Drawing.Point(735, 510);
            this.btnThemDB.Size = new System.Drawing.Size(110, 35);
            this.btnThemDB.Text = "Thêm";
            this.btnThemDB.Click += new System.EventHandler(this.btnThemDB_Click);

            // ================= TAB 3: Hướng dẫn viên =================
            this.tabHDV.Controls.Add(this.numLuong);
            this.tabHDV.Controls.Add(this.btnThemHDV);
            this.tabHDV.Controls.Add(this.txtHDVDT);
            this.tabHDV.Controls.Add(this.label10);
            this.tabHDV.Controls.Add(this.label9);
            this.tabHDV.Controls.Add(this.txtHDVTen);
            this.tabHDV.Controls.Add(this.label8);
            this.tabHDV.Controls.Add(this.txtHDVMa);
            this.tabHDV.Controls.Add(this.label11);
            this.tabHDV.Controls.Add(this.dgvHDV);
            this.tabHDV.Location = new System.Drawing.Point(4, 25);
            this.tabHDV.Name = "tabHDV";
            this.tabHDV.Size = new System.Drawing.Size(952, 571);
            this.tabHDV.Text = "Hướng dẫn viên";
            this.tabHDV.UseVisualStyleBackColor = true;

            this.dgvHDV.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvHDV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvHDV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHDV.Location = new System.Drawing.Point(20, 20);
            this.dgvHDV.Size = new System.Drawing.Size(912, 420);

            this.label11.Location = new System.Drawing.Point(35, 465);
            this.label11.Size = new System.Drawing.Size(65, 17);
            this.label11.Text = "Mã HDV:";

            this.txtHDVMa.Location = new System.Drawing.Point(135, 462);
            this.txtHDVMa.Size = new System.Drawing.Size(160, 22);

            this.label8.Location = new System.Drawing.Point(440, 465);
            this.label8.Size = new System.Drawing.Size(54, 17);
            this.label8.Text = "Họ tên:";

            this.txtHDVTen.Location = new System.Drawing.Point(525, 462);
            this.txtHDVTen.Size = new System.Drawing.Size(320, 22);

            this.label9.Location = new System.Drawing.Point(35, 518);
            this.label9.Size = new System.Drawing.Size(52, 17);
            this.label9.Text = "Lương:";

            this.numLuong.Location = new System.Drawing.Point(135, 515);
            this.numLuong.Maximum = new decimal(new int[] { 100000000, 0, 0, 0 });
            this.numLuong.Size = new System.Drawing.Size(160, 22);
            this.numLuong.Value = new decimal(new int[] { 8000000, 0, 0, 0 });

            this.label10.Location = new System.Drawing.Point(440, 518);
            this.label10.Size = new System.Drawing.Size(76, 17);
            this.label10.Text = "Điện thoại:";

            this.txtHDVDT.Location = new System.Drawing.Point(525, 515);
            this.txtHDVDT.Size = new System.Drawing.Size(160, 22);

            this.btnThemHDV.Location = new System.Drawing.Point(735, 510);
            this.btnThemHDV.Size = new System.Drawing.Size(110, 35);
            this.btnThemHDV.Text = "Thêm";
            this.btnThemHDV.Click += new System.EventHandler(this.btnThemHDV_Click);

            // ================= TAB 4: Điểm tham quan =================
            this.tabDTQ.Controls.Add(this.txtDTQYNghia);
            this.tabDTQ.Controls.Add(this.label16);
            this.tabDTQ.Controls.Add(this.txtDTQNoiDung);
            this.tabDTQ.Controls.Add(this.label15);
            this.tabDTQ.Controls.Add(this.txtDTQDiaDiem);
            this.tabDTQ.Controls.Add(this.label14);
            this.tabDTQ.Controls.Add(this.btnThemDTQ);
            this.tabDTQ.Controls.Add(this.txtDTQTen);
            this.tabDTQ.Controls.Add(this.label12);
            this.tabDTQ.Controls.Add(this.txtDTQMa);
            this.tabDTQ.Controls.Add(this.label13);
            this.tabDTQ.Controls.Add(this.dgvDTQ);
            this.tabDTQ.Location = new System.Drawing.Point(4, 25);
            this.tabDTQ.Name = "tabDTQ";
            this.tabDTQ.Size = new System.Drawing.Size(952, 571);
            this.tabDTQ.Text = "Điểm tham quan";
            this.tabDTQ.UseVisualStyleBackColor = true;

            this.dgvDTQ.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left)
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvDTQ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvDTQ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDTQ.Location = new System.Drawing.Point(20, 20);
            this.dgvDTQ.Size = new System.Drawing.Size(912, 400);

            this.label13.Location = new System.Drawing.Point(35, 435);
            this.label13.Size = new System.Drawing.Size(65, 17);
            this.label13.Text = "Mã điểm:";

            this.txtDTQMa.Location = new System.Drawing.Point(135, 432);
            this.txtDTQMa.Size = new System.Drawing.Size(160, 22);

            this.label12.Location = new System.Drawing.Point(35, 475);
            this.label12.Size = new System.Drawing.Size(71, 17);
            this.label12.Text = "Tên điểm:";

            this.txtDTQTen.Location = new System.Drawing.Point(135, 472);
            this.txtDTQTen.Size = new System.Drawing.Size(260, 22);

            this.label14.Location = new System.Drawing.Point(440, 435);
            this.label14.Size = new System.Drawing.Size(67, 17);
            this.label14.Text = "Địa điểm:";

            this.txtDTQDiaDiem.Location = new System.Drawing.Point(525, 432);
            this.txtDTQDiaDiem.Size = new System.Drawing.Size(200, 22);

            this.label15.Location = new System.Drawing.Point(35, 515);
            this.label15.Size = new System.Drawing.Size(69, 17);
            this.label15.Text = "Nội dung:";

            this.txtDTQNoiDung.Location = new System.Drawing.Point(135, 512);
            this.txtDTQNoiDung.Size = new System.Drawing.Size(260, 22);

            this.label16.Location = new System.Drawing.Point(440, 475);
            this.label16.Size = new System.Drawing.Size(55, 17);
            this.label16.Text = "Ý nghĩa:";

            this.txtDTQYNghia.Location = new System.Drawing.Point(525, 472);
            this.txtDTQYNghia.Size = new System.Drawing.Size(200, 22);

            this.btnThemDTQ.Location = new System.Drawing.Point(760, 500);
            this.btnThemDTQ.Size = new System.Drawing.Size(110, 35);
            this.btnThemDTQ.Text = "Thêm";
            this.btnThemDTQ.Click += new System.EventHandler(this.btnThemDTQ_Click);

            // ================= Nút Đóng chung =================
            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(852, 625);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.Text = "Đóng";
            this.btnDong.UseVisualStyleBackColor = true;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            // ================= Cấu hình Form =================
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 672);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabDanhMuc);
            this.Name = "FrmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh mục";
            this.Load += new System.EventHandler(this.FrmDanhMuc_Load);

            this.tabDanhMuc.ResumeLayout(false);
            this.tabPT.ResumeLayout(false);
            this.tabPT.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPT)).EndInit();
            this.tabDB.ResumeLayout(false);
            this.tabDB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDB)).EndInit();
            this.tabHDV.ResumeLayout(false);
            this.tabHDV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHDV)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numLuong)).EndInit();
            this.tabDTQ.ResumeLayout(false);
            this.tabDTQ.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDTQ)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabDanhMuc;
        private System.Windows.Forms.TabPage tabPT;
        private System.Windows.Forms.TabPage tabDB;
        private System.Windows.Forms.TabPage tabHDV;
        private System.Windows.Forms.TabPage tabDTQ;

        // Phương tiện
        private System.Windows.Forms.DataGridView dgvPT;
        private System.Windows.Forms.TextBox txtPTMa;
        private System.Windows.Forms.TextBox txtPTTen;
        private System.Windows.Forms.TextBox txtPTGhiChu;
        private System.Windows.Forms.Button btnThemPT;

        // Điểm bán vé
        private System.Windows.Forms.DataGridView dgvDB;
        private System.Windows.Forms.TextBox txtDBMa;
        private System.Windows.Forms.TextBox txtDBTen;
        private System.Windows.Forms.TextBox txtDBDiaChi;
        private System.Windows.Forms.TextBox txtDBDT;
        private System.Windows.Forms.Button btnThemDB;

        // Hướng dẫn viên
        private System.Windows.Forms.DataGridView dgvHDV;
        private System.Windows.Forms.TextBox txtHDVMa;
        private System.Windows.Forms.TextBox txtHDVTen;
        private System.Windows.Forms.TextBox txtHDVDT;
        private System.Windows.Forms.NumericUpDown numLuong;
        private System.Windows.Forms.Button btnThemHDV;

        // Điểm tham quan
        private System.Windows.Forms.DataGridView dgvDTQ;
        private System.Windows.Forms.TextBox txtDTQMa;
        private System.Windows.Forms.TextBox txtDTQTen;
        private System.Windows.Forms.TextBox txtDTQDiaDiem;
        private System.Windows.Forms.TextBox txtDTQNoiDung;
        private System.Windows.Forms.TextBox txtDTQYNghia;
        private System.Windows.Forms.Button btnThemDTQ;

        private System.Windows.Forms.Button btnDong;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
    }
}