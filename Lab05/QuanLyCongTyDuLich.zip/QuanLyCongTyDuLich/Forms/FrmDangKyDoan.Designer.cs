﻿
namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmDangKyDoan
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.grpDoan = new System.Windows.Forms.GroupBox();
            this.txtMaDoan = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtTenCQ = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtDT = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDaiDien = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();

            this.grpDangKy = new System.Windows.Forms.GroupBox();
            this.txtSo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cboTour = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dtDi = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.numNguoi = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDon = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.numCoc = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.chkBH = new System.Windows.Forms.CheckBox();
            this.lblKetThuc = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblTong = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();

            this.dgvThanhVien = new System.Windows.Forms.DataGridView();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.btnHuy = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            this.grpDoan.SuspendLayout();
            this.grpDangKy.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNguoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThanhVien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();

            // Group thông tin đoàn
            this.grpDoan.Controls.Add(this.txtDaiDien); this.grpDoan.Controls.Add(this.label5);
            this.grpDoan.Controls.Add(this.txtDT); this.grpDoan.Controls.Add(this.label4);
            this.grpDoan.Controls.Add(this.txtDiaChi); this.grpDoan.Controls.Add(this.label3);
            this.grpDoan.Controls.Add(this.txtTenCQ); this.grpDoan.Controls.Add(this.label2);
            this.grpDoan.Controls.Add(this.txtMaDoan); this.grpDoan.Controls.Add(this.label1);
            this.grpDoan.Location = new System.Drawing.Point(20, 15); this.grpDoan.Size = new System.Drawing.Size(460, 230);
            this.grpDoan.Text = "Thông tin đoàn khách";

            this.label1.AutoSize = true; this.label1.Location = new System.Drawing.Point(20, 30); this.label1.Text = "Mã đoàn:";
            this.txtMaDoan.Location = new System.Drawing.Point(140, 27); this.txtMaDoan.Size = new System.Drawing.Size(290, 22);

            this.label2.AutoSize = true; this.label2.Location = new System.Drawing.Point(20, 70); this.label2.Text = "Cơ quan / gia đình:";
            this.txtTenCQ.Location = new System.Drawing.Point(140, 67); this.txtTenCQ.Size = new System.Drawing.Size(290, 22);

            this.label3.AutoSize = true; this.label3.Location = new System.Drawing.Point(20, 110); this.label3.Text = "Địa chỉ:";
            this.txtDiaChi.Location = new System.Drawing.Point(140, 107); this.txtDiaChi.Size = new System.Drawing.Size(290, 22);

            this.label4.AutoSize = true; this.label4.Location = new System.Drawing.Point(20, 150); this.label4.Text = "Điện thoại:";
            this.txtDT.Location = new System.Drawing.Point(140, 147); this.txtDT.Size = new System.Drawing.Size(290, 22);

            this.label5.AutoSize = true; this.label5.Location = new System.Drawing.Point(20, 190); this.label5.Text = "Người đại diện:";
            this.txtDaiDien.Location = new System.Drawing.Point(140, 187); this.txtDaiDien.Size = new System.Drawing.Size(290, 22);

            // Group đăng ký tour
            this.grpDangKy.Controls.Add(this.lblTong); this.grpDangKy.Controls.Add(this.label13);
            this.grpDangKy.Controls.Add(this.lblKetThuc); this.grpDangKy.Controls.Add(this.label12);
            this.grpDangKy.Controls.Add(this.chkBH); this.grpDangKy.Controls.Add(this.numCoc); this.grpDangKy.Controls.Add(this.label11);
            this.grpDangKy.Controls.Add(this.txtDon); this.grpDangKy.Controls.Add(this.label10);
            this.grpDangKy.Controls.Add(this.numNguoi); this.grpDangKy.Controls.Add(this.label9);
            this.grpDangKy.Controls.Add(this.dtDi); this.grpDangKy.Controls.Add(this.label8);
            this.grpDangKy.Controls.Add(this.cboTour); this.grpDangKy.Controls.Add(this.label7);
            this.grpDangKy.Controls.Add(this.txtSo); this.grpDangKy.Controls.Add(this.label6);
            this.grpDangKy.Location = new System.Drawing.Point(500, 15); this.grpDangKy.Size = new System.Drawing.Size(464, 230);
            this.grpDangKy.Text = "Đăng ký tour";

            this.label6.AutoSize = true; this.label6.Location = new System.Drawing.Point(20, 30); this.label6.Text = "Số phiếu:";
            this.txtSo.Location = new System.Drawing.Point(130, 27); this.txtSo.Size = new System.Drawing.Size(120, 22);

            this.label7.AutoSize = true; this.label7.Location = new System.Drawing.Point(260, 30); this.label7.Text = "Tour:";
            this.cboTour.Location = new System.Drawing.Point(305, 27); this.cboTour.Size = new System.Drawing.Size(140, 24);
            this.cboTour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboTour.SelectedIndexChanged += new System.EventHandler(this.TinhTong);

            this.label8.AutoSize = true; this.label8.Location = new System.Drawing.Point(20, 70); this.label8.Text = "Ngày đi:";
            this.dtDi.Location = new System.Drawing.Point(130, 67); this.dtDi.Size = new System.Drawing.Size(120, 22);
            this.dtDi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDi.ValueChanged += new System.EventHandler(this.TinhTong);

            this.label9.AutoSize = true; this.label9.Location = new System.Drawing.Point(260, 70); this.label9.Text = "Số người (>12):";
            this.numNguoi.Location = new System.Drawing.Point(375, 67); this.numNguoi.Size = new System.Drawing.Size(70, 22);
            this.numNguoi.Minimum = new decimal(new int[] { 13, 0, 0, 0 }); this.numNguoi.Maximum = new decimal(new int[] { 1000, 0, 0, 0 }); this.numNguoi.Value = new decimal(new int[] { 15, 0, 0, 0 });
            this.numNguoi.ValueChanged += new System.EventHandler(this.TinhTong);

            this.label10.AutoSize = true; this.label10.Location = new System.Drawing.Point(20, 110); this.label10.Text = "Địa điểm đón:";
            this.txtDon.Location = new System.Drawing.Point(130, 107); this.txtDon.Size = new System.Drawing.Size(315, 22);

            this.label11.AutoSize = true; this.label11.Location = new System.Drawing.Point(20, 150); this.label11.Text = "Tiền cọc:";
            this.numCoc.Location = new System.Drawing.Point(130, 147); this.numCoc.Size = new System.Drawing.Size(120, 22);
            this.numCoc.Increment = new decimal(new int[] { 1000000, 0, 0, 0 }); this.numCoc.Maximum = new decimal(new int[] { 1000000000, 0, 0, 0 });

            this.chkBH.AutoSize = true; this.chkBH.Location = new System.Drawing.Point(265, 148); this.chkBH.Text = "Mua bảo hiểm";
            this.chkBH.CheckedChanged += new System.EventHandler(this.chkBH_CheckedChanged);

            this.label12.AutoSize = true; this.label12.Location = new System.Drawing.Point(20, 190); this.label12.Text = "Kết thúc DK:";
            this.lblKetThuc.AutoSize = true; this.lblKetThuc.Location = new System.Drawing.Point(130, 190); this.lblKetThuc.Text = "-";

            this.label13.AutoSize = true; this.label13.Location = new System.Drawing.Point(230, 190); this.label13.Text = "Tổng dự kiến:";
            this.lblTong.AutoSize = true; this.lblTong.Location = new System.Drawing.Point(330, 190); this.lblTong.Text = "0 đ";
            this.lblTong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold); this.lblTong.ForeColor = System.Drawing.Color.Maroon;

            // Danh sách thành viên đoàn
            this.dgvThanhVien.Location = new System.Drawing.Point(20, 255); this.dgvThanhVien.Size = new System.Drawing.Size(944, 110);
            this.dgvThanhVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            this.btnDangKy.Location = new System.Drawing.Point(710, 375); this.btnDangKy.Size = new System.Drawing.Size(120, 35);
            this.btnDangKy.Text = "Lập phiếu đăng ký"; this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);

            this.btnHuy.Location = new System.Drawing.Point(844, 375); this.btnHuy.Size = new System.Drawing.Size(120, 35);
            this.btnHuy.Text = "Hủy phiếu (mất cọc)"; this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);

            // Grid danh sách phiếu đoàn
            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.Location = new System.Drawing.Point(20, 420); this.dgv.Size = new System.Drawing.Size(944, 185);

            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(844, 615); this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.Text = "Đóng"; this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 665);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.btnHuy);
            this.Controls.Add(this.btnDangKy);
            this.Controls.Add(this.dgvThanhVien);
            this.Controls.Add(this.grpDangKy);
            this.Controls.Add(this.grpDoan);
            this.Name = "FrmDangKyDoan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Phiếu đăng ký theo đoàn";
            this.Load += new System.EventHandler(this.FrmDangKyDoan_Load);
            this.grpDoan.ResumeLayout(false);
            this.grpDoan.PerformLayout();
            this.grpDangKy.ResumeLayout(false);
            this.grpDangKy.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNguoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThanhVien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.GroupBox grpDoan;
        private System.Windows.Forms.TextBox txtMaDoan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtTenCQ;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtDT;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDaiDien;
        private System.Windows.Forms.Label label5;

        private System.Windows.Forms.GroupBox grpDangKy;
        private System.Windows.Forms.TextBox txtSo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cboTour;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtDi;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown numNguoi;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDon;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numCoc;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckBox chkBH;
        private System.Windows.Forms.Label lblKetThuc;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblTong;
        private System.Windows.Forms.Label label13;

        private System.Windows.Forms.DataGridView dgvThanhVien;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.Button btnHuy;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnDong;
    }
}