﻿
namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmDangKyLe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtSo = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboChuyen = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cboDiemBan = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtTen = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDT = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.numNguoi = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.lblThanhTien = new System.Windows.Forms.Label();
            this.btnDangKy = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.numNguoi)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();

            this.label1.AutoSize = true; this.label1.Location = new System.Drawing.Point(30, 25); this.label1.Text = "Số đăng ký:";
            this.txtSo.Location = new System.Drawing.Point(140, 22); this.txtSo.Size = new System.Drawing.Size(150, 22);

            this.label2.AutoSize = true; this.label2.Location = new System.Drawing.Point(320, 25); this.label2.Text = "Chuyến:";
            this.cboChuyen.Location = new System.Drawing.Point(400, 22); this.cboChuyen.Size = new System.Drawing.Size(350, 24);
            this.cboChuyen.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cboChuyen.SelectedIndexChanged += new System.EventHandler(this.TinhTien);

            this.label3.AutoSize = true; this.label3.Location = new System.Drawing.Point(30, 70); this.label3.Text = "Điểm bán vé:";
            this.cboDiemBan.Location = new System.Drawing.Point(140, 67); this.cboDiemBan.Size = new System.Drawing.Size(150, 24);
            this.cboDiemBan.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.label4.AutoSize = true; this.label4.Location = new System.Drawing.Point(320, 70); this.label4.Text = "Người đăng ký:";
            this.txtTen.Location = new System.Drawing.Point(440, 67); this.txtTen.Size = new System.Drawing.Size(180, 22);

            this.label5.AutoSize = true; this.label5.Location = new System.Drawing.Point(640, 70); this.label5.Text = "Điện thoại:";
            this.txtDT.Location = new System.Drawing.Point(730, 67); this.txtDT.Size = new System.Drawing.Size(140, 22);

            this.label6.AutoSize = true; this.label6.Location = new System.Drawing.Point(30, 115); this.label6.Text = "Số người (<12):";
            this.numNguoi.Location = new System.Drawing.Point(140, 112); this.numNguoi.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            this.numNguoi.Maximum = new decimal(new int[] { 11, 0, 0, 0 }); this.numNguoi.Value = new decimal(new int[] { 1, 0, 0, 0 });
            this.numNguoi.ValueChanged += new System.EventHandler(this.TinhTien);

            this.label7.AutoSize = true; this.label7.Location = new System.Drawing.Point(320, 115); this.label7.Text = "Thành tiền:";
            this.lblThanhTien.AutoSize = true; this.lblThanhTien.Location = new System.Drawing.Point(410, 115); this.lblThanhTien.Text = "0 đ";
            this.lblThanhTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold);
            this.lblThanhTien.ForeColor = System.Drawing.Color.Maroon;

            this.btnDangKy.Location = new System.Drawing.Point(760, 105); this.btnDangKy.Size = new System.Drawing.Size(190, 35);
            this.btnDangKy.Text = "Đăng ký và thanh toán vé"; this.btnDangKy.Click += new System.EventHandler(this.btnDangKy_Click);

            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.Location = new System.Drawing.Point(30, 160); this.dgv.Size = new System.Drawing.Size(924, 430);

            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(834, 610); this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.Text = "Đóng"; this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 660);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.btnDangKy);
            this.Controls.Add(this.lblThanhTien);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.numNguoi);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtDT);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtTen);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cboDiemBan);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboChuyen);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtSo);
            this.Controls.Add(this.label1);
            this.Name = "FrmDangKyLe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đăng ký khách lẻ theo chuyến";
            this.Load += new System.EventHandler(this.FrmDangKyLe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numNguoi)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboChuyen;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cboDiemBan;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTen;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDT;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numNguoi;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblThanhTien;
        private System.Windows.Forms.Button btnDangKy;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnDong;
    }
}