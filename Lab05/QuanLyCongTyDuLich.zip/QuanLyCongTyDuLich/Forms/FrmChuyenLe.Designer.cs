﻿
namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmChuyenLe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtMa = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cboTour = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dtDi = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.lblNgayVe = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDon = new System.Windows.Forms.TextBox();
            this.btnThem = new System.Windows.Forms.Button();
            this.btnDongDK = new System.Windows.Forms.Button();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.btnDong = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();

            this.label1.AutoSize = true; this.label1.Location = new System.Drawing.Point(30, 25); this.label1.Text = "Mã chuyến:";
            this.txtMa.Location = new System.Drawing.Point(130, 22); this.txtMa.Size = new System.Drawing.Size(150, 22);

            this.label2.AutoSize = true; this.label2.Location = new System.Drawing.Point(320, 25); this.label2.Text = "Tour:";
            this.cboTour.Location = new System.Drawing.Point(380, 22); this.cboTour.Size = new System.Drawing.Size(300, 24);
            this.cboTour.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;

            this.label3.AutoSize = true; this.label3.Location = new System.Drawing.Point(30, 70); this.label3.Text = "Ngày đi:";
            this.dtDi.Location = new System.Drawing.Point(130, 67); this.dtDi.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDi.ValueChanged += new System.EventHandler(this.TinhNgayVe);

            this.label4.AutoSize = true; this.label4.Location = new System.Drawing.Point(320, 70); this.label4.Text = "Ngày về:";
            this.lblNgayVe.AutoSize = true; this.lblNgayVe.Location = new System.Drawing.Point(380, 70); this.lblNgayVe.Text = "-";
            this.lblNgayVe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold);

            this.label5.AutoSize = true; this.label5.Location = new System.Drawing.Point(30, 115); this.label5.Text = "Địa điểm đón:";
            this.txtDon.Location = new System.Drawing.Point(130, 112); this.txtDon.Size = new System.Drawing.Size(550, 22);

            this.btnThem.Location = new System.Drawing.Point(710, 20); this.btnThem.Size = new System.Drawing.Size(110, 35);
            this.btnThem.Text = "Tạo chuyến"; this.btnThem.Click += new System.EventHandler(this.btnThem_Click);

            this.btnDongDK.Location = new System.Drawing.Point(710, 70); this.btnDongDK.Size = new System.Drawing.Size(110, 35);
            this.btnDongDK.Text = "Đóng đăng ký"; this.btnDongDK.Click += new System.EventHandler(this.btnDongDK_Click);

            this.dgv.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgv.Location = new System.Drawing.Point(30, 160); this.dgv.Size = new System.Drawing.Size(924, 430);

            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(834, 610); this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.Text = "Đóng"; this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 660);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.btnDongDK);
            this.Controls.Add(this.btnThem);
            this.Controls.Add(this.txtDon);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblNgayVe);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dtDi);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.cboTour);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtMa);
            this.Controls.Add(this.label1);
            this.Name = "FrmChuyenLe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lịch chuyến khách lẻ";
            this.Load += new System.EventHandler(this.FrmChuyenLe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtMa;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cboTour;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtDi;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblNgayVe;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDon;
        private System.Windows.Forms.Button btnThem;
        private System.Windows.Forms.Button btnDongDK;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Button btnDong;
    }
}