﻿
namespace QuanLyCongTyDuLich.Forms
{
    partial class FrmLuongThongKe
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.tabTK = new System.Windows.Forms.TabControl();

            // Tab 1: Lương HDV
            this.tabLuong = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.numThang = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.numNam = new System.Windows.Forms.NumericUpDown();
            this.btnLuong = new System.Windows.Forms.Button();
            this.labelInfo = new System.Windows.Forms.Label();
            this.dgvLuong = new System.Windows.Forms.DataGridView();

            // Tab 2: Thống kê tổng hợp
            this.tabTongHop = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.dtTu = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.dtDen = new System.Windows.Forms.DateTimePicker();
            this.btnTongHop = new System.Windows.Forms.Button();
            this.dgvTongHop = new System.Windows.Forms.DataGridView();

            this.btnDong = new System.Windows.Forms.Button();

            this.tabTK.SuspendLayout();
            this.tabLuong.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThang)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNam)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuong)).BeginInit();
            this.tabTongHop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTongHop)).BeginInit();
            this.SuspendLayout();

            this.tabTK.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.tabTK.Controls.Add(this.tabLuong);
            this.tabTK.Controls.Add(this.tabTongHop);
            this.tabTK.Location = new System.Drawing.Point(12, 12);
            this.tabTK.Name = "tabTK";
            this.tabTK.SelectedIndex = 0;
            this.tabTK.Size = new System.Drawing.Size(960, 600);

            // --- Tab 1 ---
            this.tabLuong.Controls.Add(this.dgvLuong);
            this.tabLuong.Controls.Add(this.labelInfo);
            this.tabLuong.Controls.Add(this.btnLuong);
            this.tabLuong.Controls.Add(this.numNam); this.tabLuong.Controls.Add(this.label2);
            this.tabLuong.Controls.Add(this.numThang); this.tabLuong.Controls.Add(this.label1);
            this.tabLuong.Text = "Lương hướng dẫn viên";
            this.tabLuong.UseVisualStyleBackColor = true;

            this.label1.AutoSize = true; this.label1.Location = new System.Drawing.Point(25, 25); this.label1.Text = "Tháng:";
            this.numThang.Location = new System.Drawing.Point(85, 22); this.numThang.Size = new System.Drawing.Size(60, 22);
            this.numThang.Minimum = new decimal(new int[] { 1, 0, 0, 0 }); this.numThang.Maximum = new decimal(new int[] { 12, 0, 0, 0 });

            this.label2.AutoSize = true; this.label2.Location = new System.Drawing.Point(170, 25); this.label2.Text = "Năm:";
            this.numNam.Location = new System.Drawing.Point(220, 22); this.numNam.Size = new System.Drawing.Size(80, 22);
            this.numNam.Minimum = new decimal(new int[] { 2020, 0, 0, 0 }); this.numNam.Maximum = new decimal(new int[] { 2050, 0, 0, 0 });

            this.btnLuong.Location = new System.Drawing.Point(330, 15); this.btnLuong.Size = new System.Drawing.Size(120, 35);
            this.btnLuong.Text = "Tính lương"; this.btnLuong.Click += new System.EventHandler(this.btnLuong_Click);

            this.labelInfo.AutoSize = true; this.labelInfo.Location = new System.Drawing.Point(480, 25);
            this.labelInfo.Text = "Lương = lương căn bản + thù lao các tour kết thúc trong tháng";
            this.labelInfo.ForeColor = System.Drawing.Color.DimGray;

            this.dgvLuong.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLuong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvLuong.Location = new System.Drawing.Point(20, 70); this.dgvLuong.Size = new System.Drawing.Size(912, 480);

            // --- Tab 2 ---
            this.tabTongHop.Controls.Add(this.dgvTongHop);
            this.tabTongHop.Controls.Add(this.btnTongHop);
            this.tabTongHop.Controls.Add(this.dtDen); this.tabTongHop.Controls.Add(this.label4);
            this.tabTongHop.Controls.Add(this.dtTu); this.tabTongHop.Controls.Add(this.label3);
            this.tabTongHop.Text = "Thống kê tổng hợp";
            this.tabTongHop.UseVisualStyleBackColor = true;

            this.label3.AutoSize = true; this.label3.Location = new System.Drawing.Point(25, 25); this.label3.Text = "Từ ngày:";
            this.dtTu.Location = new System.Drawing.Point(95, 22); this.dtTu.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.label4.AutoSize = true; this.label4.Location = new System.Drawing.Point(245, 25); this.label4.Text = "Đến ngày:";
            this.dtDen.Location = new System.Drawing.Point(325, 22); this.dtDen.Format = System.Windows.Forms.DateTimePickerFormat.Short;

            this.btnTongHop.Location = new System.Drawing.Point(450, 15); this.btnTongHop.Size = new System.Drawing.Size(120, 35);
            this.btnTongHop.Text = "Thống kê"; this.btnTongHop.Click += new System.EventHandler(this.btnTongHop_Click);

            this.dgvTongHop.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
            | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvTongHop.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTongHop.Location = new System.Drawing.Point(20, 70); this.dgvTongHop.Size = new System.Drawing.Size(912, 480);

            this.btnDong.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDong.Location = new System.Drawing.Point(852, 625); this.btnDong.Size = new System.Drawing.Size(120, 35);
            this.btnDong.Text = "Đóng"; this.btnDong.Click += new System.EventHandler(this.btnDong_Click);

            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 672);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.tabTK);
            this.Name = "FrmLuongThongKe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lương hướng dẫn viên - thống kê";
            this.Load += new System.EventHandler(this.FrmLuongThongKe_Load);
            this.tabTK.ResumeLayout(false);
            this.tabLuong.ResumeLayout(false);
            this.tabLuong.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numThang)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNam)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLuong)).EndInit();
            this.tabTongHop.ResumeLayout(false);
            this.tabTongHop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTongHop)).EndInit();
            this.ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabTK;
        private System.Windows.Forms.TabPage tabLuong;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numThang;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numNam;
        private System.Windows.Forms.Button btnLuong;
        private System.Windows.Forms.Label labelInfo;
        private System.Windows.Forms.DataGridView dgvLuong;

        private System.Windows.Forms.TabPage tabTongHop;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dtTu;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dtDen;
        private System.Windows.Forms.Button btnTongHop;
        private System.Windows.Forms.DataGridView dgvTongHop;

        private System.Windows.Forms.Button btnDong;
    }
}
