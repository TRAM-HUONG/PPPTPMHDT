﻿using System;
using System.Windows.Forms;
using QuanLyCongTyDuLich.Services;

namespace QuanLyCongTyDuLich.Forms
{
    public partial class FrmTour : Form
    {
        private readonly TourService svc = new TourService();
        private readonly DanhMucService dm = new DanhMucService();

        public FrmTour()
        {
            InitializeComponent();
        }

        private void FrmTour_Load(object sender, EventArgs e)
        {
            TaiTour();
        }

        private void TaiTour()
        {
            dgvTour.DataSource = svc.LayTour();
            FormHelper.Nap(cboTour, svc.LayTour(), "TenTour", "MaTour");
            TaiChiTiet();
        }

        private void TaiChiTiet()
        {
            string ma = FormHelper.Gia(cboTour);
            dgvDiemDung.DataSource = svc.LayDiemDung(ma);
            dgvChang.DataSource = svc.LayChang(ma);
            dgvTQ.DataSource = svc.LayDiemTQTour(ma);
        }

        private void cboTour_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboTour.ValueMember == "MaTour" || cboTour.SelectedValue != null)
            {
                TaiChiTiet();
            }
        }

        private void btnThemTour_Click(object sender, EventArgs e)
        {
            decimal donGia = 0;
            decimal.TryParse(txtDonGia.Text, out donGia);
            int soNgay = (int)nudSoNgay.Value;
            int soDem = soNgay > 1 ? soNgay - 1 : 0;

            if (FormHelper.Bao(svc.ThemTour(txtMaTour.Text, txtTenTour.Text, soNgay, soDem, donGia, txtMoTa.Text)))
            {
                TaiTour();
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}