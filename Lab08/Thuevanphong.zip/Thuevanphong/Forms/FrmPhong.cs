﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmPhong : Form
    {
        private PhongService phongService;

        public FrmPhong()
        {
            InitializeComponent();
            phongService = new PhongService();
        }

        private void FrmPhong_Load(object sender, EventArgs e)
        {
            LoadDuLieuPhong();
        }

        private void LoadDuLieuPhong()
        {
            try
            {
                DataTable dt = phongService.LayDanhSachPhong();
                dgvPhong.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu phòng: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string maPhong = txtMaPhong.Text.Trim();

            if (string.IsNullOrEmpty(maPhong))
            {
                MessageBox.Show("Vui lòng nhập mã phòng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtTang.Text.Trim(), out int tang) || !float.TryParse(txtDienTich.Text.Trim(), out float dienTich))
            {
                MessageBox.Show("Tầng và Diện tích phải là số hợp lệ!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi Service xử lý
            KetQuaXuLy kq = phongService.ThemPhong(maPhong, tang, dienTich);

            // Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Lỗi", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (kq.ThanhCong)
            {
                LoadDuLieuPhong();
                txtMaPhong.Clear();
                txtTang.Clear();
                txtDienTich.Clear();
            }
        }
    }
}