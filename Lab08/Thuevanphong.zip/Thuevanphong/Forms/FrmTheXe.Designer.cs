﻿namespace QuanLyCaoOc.Forms
{
    partial class FrmTheXe
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvTheXe;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.TextBox txtMaThe;
        private System.Windows.Forms.TextBox txtMSNV;
        private System.Windows.Forms.TextBox txtBienSo;
        private System.Windows.Forms.ComboBox cboLoaiXe;
        private System.Windows.Forms.Label lblMaThe;
        private System.Windows.Forms.Label lblMSNV;
        private System.Windows.Forms.Label lblBienSo;
        private System.Windows.Forms.Label lblLoaiXe;
        private System.Windows.Forms.Button btnCapThe;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvTheXe = new System.Windows.Forms.DataGridView();
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.txtMaThe = new System.Windows.Forms.TextBox();
            this.txtMSNV = new System.Windows.Forms.TextBox();
            this.txtBienSo = new System.Windows.Forms.TextBox();
            this.cboLoaiXe = new System.Windows.Forms.ComboBox();
            this.lblMaThe = new System.Windows.Forms.Label();
            this.lblMSNV = new System.Windows.Forms.Label();
            this.lblBienSo = new System.Windows.Forms.Label();
            this.lblLoaiXe = new System.Windows.Forms.Label();
            this.btnCapThe = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheXe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvTheXe
            // 
            this.dgvTheXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTheXe.Location = new System.Drawing.Point(30, 220);
            this.dgvTheXe.Name = "dgvTheXe";
            this.dgvTheXe.RowHeadersWidth = 51;
            this.dgvTheXe.Size = new System.Drawing.Size(430, 220);
            this.dgvTheXe.TabIndex = 0;
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Location = new System.Drawing.Point(480, 220);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.RowHeadersWidth = 51;
            this.dgvNhanVien.Size = new System.Drawing.Size(400, 220);
            this.dgvNhanVien.TabIndex = 1;
            this.dgvNhanVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvNhanVien_CellClick);
            // 
            // txtMaThe
            // 
            this.txtMaThe.Location = new System.Drawing.Point(140, 30);
            this.txtMaThe.Name = "txtMaThe";
            this.txtMaThe.Size = new System.Drawing.Size(200, 22);
            this.txtMaThe.TabIndex = 2;
            // 
            // txtMSNV
            // 
            this.txtMSNV.Location = new System.Drawing.Point(140, 75);
            this.txtMSNV.Name = "txtMSNV";
            this.txtMSNV.Size = new System.Drawing.Size(200, 22);
            this.txtMSNV.TabIndex = 3;
            // 
            // txtBienSo
            // 
            this.txtBienSo.Location = new System.Drawing.Point(520, 30);
            this.txtBienSo.Name = "txtBienSo";
            this.txtBienSo.Size = new System.Drawing.Size(200, 22);
            this.txtBienSo.TabIndex = 4;
            // 
            // cboLoaiXe
            // 
            this.cboLoaiXe.FormattingEnabled = true;
            this.cboLoaiXe.Items.AddRange(new object[] {
            "Xe máy",
            "Xe đạp",
            "Ô tô"});
            this.cboLoaiXe.Location = new System.Drawing.Point(520, 75);
            this.cboLoaiXe.Name = "cboLoaiXe";
            this.cboLoaiXe.Size = new System.Drawing.Size(200, 24);
            this.cboLoaiXe.TabIndex = 5;
            this.cboLoaiXe.Text = "Xe máy";
            // 
            // lblMaThe
            // 
            this.lblMaThe.AutoSize = true;
            this.lblMaThe.Location = new System.Drawing.Point(30, 33);
            this.lblMaThe.Name = "lblMaThe";
            this.lblMaThe.Size = new System.Drawing.Size(51, 16);
            this.lblMaThe.Text = "Mã Thẻ";
            // 
            // lblMSNV
            // 
            this.lblMSNV.AutoSize = true;
            this.lblMSNV.Location = new System.Drawing.Point(30, 78);
            this.lblMSNV.Name = "lblMSNV";
            this.lblMSNV.Size = new System.Drawing.Size(90, 16);
            this.lblMSNV.Text = "Chọn MSNV";
            // 
            // lblBienSo
            // 
            this.lblBienSo.AutoSize = true;
            this.lblBienSo.Location = new System.Drawing.Point(420, 33);
            this.lblBienSo.Name = "lblBienSo";
            this.lblBienSo.Size = new System.Drawing.Size(76, 16);
            this.lblBienSo.Text = "Biển Số Xe";
            // 
            // lblLoaiXe
            // 
            this.lblLoaiXe.AutoSize = true;
            this.lblLoaiXe.Location = new System.Drawing.Point(420, 78);
            this.lblLoaiXe.Name = "lblLoaiXe";
            this.lblLoaiXe.Size = new System.Drawing.Size(52, 16);
            this.lblLoaiXe.Text = "Loại Xe";
            // 
            // btnCapThe
            // 
            this.btnCapThe.Location = new System.Drawing.Point(520, 130);
            this.btnCapThe.Name = "btnCapThe";
            this.btnCapThe.Size = new System.Drawing.Size(200, 35);
            this.btnCapThe.TabIndex = 6;
            this.btnCapThe.Text = "Cấp Thẻ Giữ Xe";
            this.btnCapThe.UseVisualStyleBackColor = true;
            this.btnCapThe.Click += new System.EventHandler(this.btnCapThe_Click);
            // 
            // FrmTheXe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 470);
            this.Controls.Add(this.btnCapThe);
            this.Controls.Add(this.lblLoaiXe);
            this.Controls.Add(this.lblBienSo);
            this.Controls.Add(this.lblMSNV);
            this.Controls.Add(this.lblMaThe);
            this.Controls.Add(this.cboLoaiXe);
            this.Controls.Add(this.txtBienSo);
            this.Controls.Add(this.txtMSNV);
            this.Controls.Add(this.txtMaThe);
            this.Controls.Add(this.dgvNhanVien);
            this.Controls.Add(this.dgvTheXe);
            this.Name = "FrmTheXe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Cấp Thẻ Giữ Xe Cho Nhân Viên";
            this.Load += new System.EventHandler(this.FrmTheXe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTheXe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}