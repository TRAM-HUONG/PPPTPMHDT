﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmThanhToan : Form
    {
        private ThanhToanService thanhToanService;

        public FrmThanhToan()
        {
            InitializeComponent();
            thanhToanService = new ThanhToanService();
        }

        private void FrmThanhToan_Load(object sender, EventArgs e)
        {
            LoadDuLieu();
        }

        private void LoadDuLieu()
        {
            try
            {
                dgvHoaDon.DataSource = thanhToanService.LayDanhSachHoaDon();
                cboMaDichVu.DataSource = thanhToanService.LayDanhSachDichVu();
                cboMaDichVu.DisplayMember = "TenDichVu";
                cboMaDichVu.ValueMember = "MaDichVu";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLapHoaDonDV_Click(object sender, EventArgs e)
        {
            string soHDn = txtSoHoaDon.Text.Trim();
            string soHD = txtSoHopDong.Text.Trim();
            string maPhong = txtMaPhong.Text.Trim();
            string maDV = cboMaDichVu.SelectedValue?.ToString();

            if (string.IsNullOrEmpty(soHDn) || string.IsNullOrEmpty(soHD) || string.IsNullOrEmpty(maPhong))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Số hóa đơn, Số hợp đồng và Mã phòng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtSoLuong.Text.Trim(), out int soLuong))
            {
                MessageBox.Show("Số lượng sử dụng dịch vụ phải là số nguyên!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi Service xử lý lập hóa đơn dịch vụ cuối tháng
            KetQuaXuLy kq = thanhToanService.LapHoaDonDichVu(soHDn, soHD, maPhong, maDV, soLuong);

            // Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Lỗi", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (kq.ThanhCong)
            {
                LoadDuLieu();
                txtSoHoaDon.Clear();
                txtSoLuong.Clear();
            }
        }

        private void btnThanhToanTienPhong_Click(object sender, EventArgs e)
        {
            string soHD = txtSoHopDong.Text.Trim();
            string maPhong = txtMaPhong.Text.Trim();

            if (string.IsNullOrEmpty(soHD) || string.IsNullOrEmpty(maPhong))
            {
                MessageBox.Show("Vui lòng nhập Số hợp đồng và Mã phòng cần thanh toán tiền thuê!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtThangThu.Text.Trim(), out int thangThu))
            {
                MessageBox.Show("Tháng thứ mấy phải là số nguyên (>= 7)!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi Service xử lý thanh toán tiền thuê mặt bằng từ tháng thứ 7 (đầu tháng)
            KetQuaXuLy kq = thanhToanService.ThanhToanTienThueHangThang(soHD, maPhong, thangThu);

            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Cảnh báo", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        }
    }
}