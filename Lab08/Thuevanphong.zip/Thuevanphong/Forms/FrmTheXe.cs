﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmTheXe : Form
    {
        private TheXeService theXeService;

        public FrmTheXe()
        {
            InitializeComponent();
            theXeService = new TheXeService();
        }

        private void FrmTheXe_Load(object sender, EventArgs e)
        {
            LoadDuLieu();
        }

        private void LoadDuLieu()
        {
            try
            {
                dgvTheXe.DataSource = theXeService.LayDanhSachTheXe();
                dgvNhanVien.DataSource = theXeService.LayDanhSachNhanVien();
            }
            catch (Exception ex)
            {
                // Nếu chưa tạo bảng TheXe trong CSDL, form vẫn tải được danh sách nhân viên
                try
                {
                    dgvNhanVien.DataSource = theXeService.LayDanhSachNhanVien();
                }
                catch { }
                // Không báo lỗi quá nhiều nếu chưa có bảng TheXe
            }
        }

        private void btnCapThe_Click(object sender, EventArgs e)
        {
            string maThe = txtMaThe.Text.Trim();
            string msnv = txtMSNV.Text.Trim();
            string bienSo = txtBienSo.Text.Trim();
            string loaiXe = cboLoaiXe.SelectedItem?.ToString() ?? "Xe máy";

            if (string.IsNullOrEmpty(maThe) || string.IsNullOrEmpty(msnv) || string.IsNullOrEmpty(bienSo))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Mã thẻ, MSNV và Biển số xe!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi Service xử lý cấp thẻ xe
            KetQuaXuLy kq = theXeService.CapTheXe(maThe, msnv, bienSo, loaiXe);

            // Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Lỗi", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (kq.ThanhCong)
            {
                LoadDuLieu();
                txtMaThe.Clear();
                txtMSNV.Clear();
                txtBienSo.Clear();
            }
        }

        private void dgvNhanVien_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvNhanVien.Rows[e.RowIndex];
                txtMSNV.Text = row.Cells["MSNV"].Value.ToString();
            }
        }
    }
}