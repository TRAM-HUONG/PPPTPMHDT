﻿namespace QuanLyCaoOc.Forms
{
    partial class FrmThanhToan
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvHoaDon;
        private System.Windows.Forms.TextBox txtSoHoaDon;
        private System.Windows.Forms.TextBox txtSoHopDong;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.TextBox txtSoLuong;
        private System.Windows.Forms.TextBox txtThangThu;
        private System.Windows.Forms.ComboBox cboMaDichVu;
        private System.Windows.Forms.Label lblSoHDn;
        private System.Windows.Forms.Label lblSoHD;
        private System.Windows.Forms.Label lblMaPhong;
        private System.Windows.Forms.Label lblMaDV;
        private System.Windows.Forms.Label lblSoLuong;
        private System.Windows.Forms.Label lblThangThu;
        private System.Windows.Forms.Button btnLapHoaDonDV;
        private System.Windows.Forms.Button btnThanhToanTienPhong;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvHoaDon = new System.Windows.Forms.DataGridView();
            this.txtSoHoaDon = new System.Windows.Forms.TextBox();
            this.txtSoHopDong = new System.Windows.Forms.TextBox();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.txtSoLuong = new System.Windows.Forms.TextBox();
            this.txtThangThu = new System.Windows.Forms.TextBox();
            this.cboMaDichVu = new System.Windows.Forms.ComboBox();
            this.lblSoHDn = new System.Windows.Forms.Label();
            this.lblSoHD = new System.Windows.Forms.Label();
            this.lblMaPhong = new System.Windows.Forms.Label();
            this.lblMaDV = new System.Windows.Forms.Label();
            this.lblSoLuong = new System.Windows.Forms.Label();
            this.lblThangThu = new System.Windows.Forms.Label();
            this.btnLapHoaDonDV = new System.Windows.Forms.Button();
            this.btnThanhToanTienPhong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvHoaDon
            // 
            this.dgvHoaDon.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHoaDon.Location = new System.Drawing.Point(30, 230);
            this.dgvHoaDon.Name = "dgvHoaDon";
            this.dgvHoaDon.RowHeadersWidth = 51;
            this.dgvHoaDon.Size = new System.Drawing.Size(740, 220);
            this.dgvHoaDon.TabIndex = 0;
            // 
            // txtSoHoaDon
            // 
            this.txtSoHoaDon.Location = new System.Drawing.Point(140, 30);
            this.txtSoHoaDon.Name = "txtSoHoaDon";
            this.txtSoHoaDon.Size = new System.Drawing.Size(180, 22);
            this.txtSoHoaDon.TabIndex = 1;
            // 
            // txtSoHopDong
            // 
            this.txtSoHopDong.Location = new System.Drawing.Point(140, 70);
            this.txtSoHopDong.Name = "txtSoHopDong";
            this.txtSoHopDong.Size = new System.Drawing.Size(180, 22);
            this.txtSoHopDong.TabIndex = 2;
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Location = new System.Drawing.Point(140, 110);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.Size = new System.Drawing.Size(180, 22);
            this.txtMaPhong.TabIndex = 3;
            // 
            // txtSoLuong
            // 
            this.txtSoLuong.Location = new System.Drawing.Point(470, 70);
            this.txtSoLuong.Name = "txtSoLuong";
            this.txtSoLuong.Size = new System.Drawing.Size(180, 22);
            this.txtSoLuong.TabIndex = 4;
            // 
            // txtThangThu
            // 
            this.txtThangThu.Location = new System.Drawing.Point(470, 110);
            this.txtThangThu.Name = "txtThangThu";
            this.txtThangThu.Size = new System.Drawing.Size(180, 22);
            this.txtThangThu.TabIndex = 5;
            // 
            // cboMaDichVu
            // 
            this.cboMaDichVu.FormattingEnabled = true;
            this.cboMaDichVu.Location = new System.Drawing.Point(470, 30);
            this.cboMaDichVu.Name = "cboMaDichVu";
            this.cboMaDichVu.Size = new System.Drawing.Size(180, 24);
            this.cboMaDichVu.TabIndex = 6;
            // 
            // lblSoHDn
            // 
            this.lblSoHDn.AutoSize = true;
            this.lblSoHDn.Location = new System.Drawing.Point(30, 33);
            this.lblSoHDn.Name = "lblSoHDn";
            this.lblSoHDn.Size = new System.Drawing.Size(76, 16);
            this.lblSoHDn.Text = "Số Hóa Đơn";
            // 
            // lblSoHD
            // 
            this.lblSoHD.AutoSize = true;
            this.lblSoHD.Location = new System.Drawing.Point(30, 73);
            this.lblSoHD.Name = "lblSoHD";
            this.lblSoHD.Size = new System.Drawing.Size(84, 16);
            this.lblSoHD.Text = "Số Hợp Đồng";
            // 
            // lblMaPhong
            // 
            this.lblMaPhong.AutoSize = true;
            this.lblMaPhong.Location = new System.Drawing.Point(30, 113);
            this.lblMaPhong.Name = "lblMaPhong";
            this.lblMaPhong.Size = new System.Drawing.Size(68, 16);
            this.lblMaPhong.Text = "Mã Phòng";
            // 
            // lblMaDV
            // 
            this.lblMaDV.AutoSize = true;
            this.lblMaDV.Location = new System.Drawing.Point(360, 33);
            this.lblMaDV.Name = "lblMaDV";
            this.lblMaDV.Size = new System.Drawing.Size(71, 16);
            this.lblMaDV.Text = "Mã Dịch Vụ";
            // 
            // lblSoLuong
            // 
            this.lblSoLuong.AutoSize = true;
            this.lblSoLuong.Location = new System.Drawing.Point(360, 73);
            this.lblSoLuong.Name = "lblSoLuong";
            this.lblSoLuong.Size = new System.Drawing.Size(64, 16);
            this.lblSoLuong.Text = "Số Lượng";
            // 
            // lblThangThu
            // 
            this.lblThangThu.AutoSize = true;
            this.lblThangThu.Location = new System.Drawing.Point(360, 113);
            this.lblThangThu.Name = "lblThangThu";
            this.lblThangThu.Size = new System.Drawing.Size(73, 16);
            this.lblThangThu.Text = "Tháng Thứ ?";
            // 
            // btnLapHoaDonDV
            // 
            this.btnLapHoaDonDV.Location = new System.Drawing.Point(140, 160);
            this.btnLapHoaDonDV.Name = "btnLapHoaDonDV";
            this.btnLapHoaDonDV.Size = new System.Drawing.Size(180, 35);
            this.btnLapHoaDonDV.TabIndex = 7;
            this.btnLapHoaDonDV.Text = "Lập Hóa Đơn Dịch Vụ";
            this.btnLapHoaDonDV.UseVisualStyleBackColor = true;
            this.btnLapHoaDonDV.Click += new System.EventHandler(this.btnLapHoaDonDV_Click);
            // 
            // btnThanhToanTienPhong
            // 
            this.btnThanhToanTienPhong.Location = new System.Drawing.Point(470, 160);
            this.btnThanhToanTienPhong.Name = "btnThanhToanTienPhong";
            this.btnThanhToanTienPhong.Size = new System.Drawing.Size(180, 35);
            this.btnThanhToanTienPhong.TabIndex = 8;
            this.btnThanhToanTienPhong.Text = "Thu Tiền Thuê (Đầu Tháng)";
            this.btnThanhToanTienPhong.UseVisualStyleBackColor = true;
            this.btnThanhToanTienPhong.Click += new System.EventHandler(this.btnThanhToanTienPhong_Click);
            // 
            // FrmThanhToan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 480);
            this.Controls.Add(this.btnThanhToanTienPhong);
            this.Controls.Add(this.btnLapHoaDonDV);
            this.Controls.Add(this.lblThangThu);
            this.Controls.Add(this.lblSoLuong);
            this.Controls.Add(this.lblMaDV);
            this.Controls.Add(this.lblMaPhong);
            this.Controls.Add(this.lblSoHD);
            this.Controls.Add(this.lblSoHDn);
            this.Controls.Add(this.cboMaDichVu);
            this.Controls.Add(this.txtThangThu);
            this.Controls.Add(this.txtSoLuong);
            this.Controls.Add(this.txtMaPhong);
            this.Controls.Add(this.txtSoHopDong);
            this.Controls.Add(this.txtSoHoaDon);
            this.Controls.Add(this.dgvHoaDon);
            this.Name = "FrmThanhToan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Thanh Toán Tiền Thuê & Hóa Đơn Dịch Vụ";
            this.Load += new System.EventHandler(this.FrmThanhToan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHoaDon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}