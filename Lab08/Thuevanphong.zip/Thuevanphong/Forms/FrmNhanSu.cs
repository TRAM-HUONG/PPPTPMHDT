﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmNhanSu : Form
    {
        private NhanSuService nhanSuService;

        public FrmNhanSu()
        {
            InitializeComponent();
            nhanSuService = new NhanSuService();
        }

        private void FrmNhanSu_Load(object sender, EventArgs e)
        {
            LoadDuLieu();
        }

        private void LoadDuLieu()
        {
            try
            {
                dgvNhanVien.DataSource = nhanSuService.LayDanhSachNhanVien();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu nhân viên: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThemNV_Click(object sender, EventArgs e)
        {
            string msnv = txtMSNV.Text.Trim();
            string tenNV = txtTenNV.Text.Trim();
            string phai = cboPhai.SelectedItem?.ToString() ?? "Nam";
            string diaChi = txtDiaChi.Text.Trim();
            string sdt = txtSdt.Text.Trim();
            string chucVu = txtChucVu.Text.Trim();
            string maPhong = txtMaPhong.Text.Trim();
            string maCongTy = txtMaCongTy.Text.Trim();

            if (string.IsNullOrEmpty(msnv) || string.IsNullOrEmpty(tenNV) || string.IsNullOrEmpty(maPhong) || string.IsNullOrEmpty(maCongTy))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ MSNV, Tên nhân viên, Mã phòng và Mã công ty!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi Service xử lý báo cáo nhân viên mới
            KetQuaXuLy kq = nhanSuService.ThemNhanVienMoi(msnv, tenNV, phai, diaChi, sdt, chucVu, maPhong, maCongTy);

            // Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Lỗi", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (kq.ThanhCong)
            {
                LoadDuLieu();
                txtMSNV.Clear();
                txtTenNV.Clear();
                txtDiaChi.Clear();
                txtSdt.Clear();
                txtChucVu.Clear();
                txtMaPhong.Clear();
                txtMaCongTy.Clear();
            }
        }

        private void btnCapTheXe_Click(object sender, EventArgs e)
        {
            if (dgvNhanVien.SelectedRows.Count > 0)
            {
                string msnv = dgvNhanVien.SelectedRows[0].Cells["MSNV"].Value.ToString();
                string tenNV = dgvNhanVien.SelectedRows[0].Cells["TenNV"].Value.ToString();
                string maPhong = dgvNhanVien.SelectedRows[0].Cells["MaPhong"].Value.ToString();

                MessageBox.Show($"Cấp thẻ giữ xe thành công cho nhân viên: {tenNV} (MSNV: {msnv}) - Phòng: {maPhong}.\nThông tin thẻ gồm: Mã thẻ, thông tin nhân viên và thông tin xe gửi.", "Cấp thẻ giữ xe", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một nhân viên trong danh sách để cấp thẻ giữ xe!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}