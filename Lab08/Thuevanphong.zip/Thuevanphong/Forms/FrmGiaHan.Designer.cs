﻿namespace QuanLyCaoOc.Forms
{
    partial class FrmGiaHan
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvHopDong;
        private System.Windows.Forms.TextBox txtSoPhiieu;
        private System.Windows.Forms.TextBox txtSoHopDong;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.TextBox txtThoiGianGiaHan;
        private System.Windows.Forms.Label lblSoPhiieu;
        private System.Windows.Forms.Label lblSoHD;
        private System.Windows.Forms.Label lblMaPhong;
        private System.Windows.Forms.Label lblThoiGianGH;
        private System.Windows.Forms.Button btnLapPhieu;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvHopDong = new System.Windows.Forms.DataGridView();
            this.txtSoPhiieu = new System.Windows.Forms.TextBox();
            this.txtSoHopDong = new System.Windows.Forms.TextBox();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.txtThoiGianGiaHan = new System.Windows.Forms.TextBox();
            this.lblSoPhiieu = new System.Windows.Forms.Label();
            this.lblSoHD = new System.Windows.Forms.Label();
            this.lblMaPhong = new System.Windows.Forms.Label();
            this.lblThoiGianGH = new System.Windows.Forms.Label();
            this.btnLapPhieu = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvHopDong
            // 
            this.dgvHopDong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHopDong.Location = new System.Drawing.Point(30, 200);
            this.dgvHopDong.Name = "dgvHopDong";
            this.dgvHopDong.RowHeadersWidth = 51;
            this.dgvHopDong.Size = new System.Drawing.Size(660, 240);
            this.dgvHopDong.TabIndex = 0;
            // 
            // txtSoPhiieu
            // 
            this.txtSoPhiieu.Location = new System.Drawing.Point(170, 30);
            this.txtSoPhiieu.Name = "txtSoPhiieu";
            this.txtSoPhiieu.Size = new System.Drawing.Size(180, 22);
            this.txtSoPhiieu.TabIndex = 1;
            // 
            // txtSoHopDong
            // 
            this.txtSoHopDong.Location = new System.Drawing.Point(170, 75);
            this.txtSoHopDong.Name = "txtSoHopDong";
            this.txtSoHopDong.Size = new System.Drawing.Size(180, 22);
            this.txtSoHopDong.TabIndex = 2;
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Location = new System.Drawing.Point(510, 30);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.Size = new System.Drawing.Size(180, 22);
            this.txtMaPhong.TabIndex = 3;
            // 
            // txtThoiGianGiaHan
            // 
            this.txtThoiGianGiaHan.Location = new System.Drawing.Point(510, 75);
            this.txtThoiGianGiaHan.Name = "txtThoiGianGiaHan";
            this.txtThoiGianGiaHan.Size = new System.Drawing.Size(180, 22);
            this.txtThoiGianGiaHan.TabIndex = 4;
            // 
            // lblSoPhiieu
            // 
            this.lblSoPhiieu.AutoSize = true;
            this.lblSoPhiieu.Location = new System.Drawing.Point(30, 33);
            this.lblSoPhiieu.Name = "lblSoPhiieu";
            this.lblSoPhiieu.Size = new System.Drawing.Size(107, 16);
            this.lblSoPhiieu.Text = "Số Phiếu Gia Hạn";
            // 
            // lblSoHD
            // 
            this.lblSoHD.AutoSize = true;
            this.lblSoHD.Location = new System.Drawing.Point(30, 78);
            this.lblSoHD.Name = "lblSoHD";
            this.lblSoHD.Size = new System.Drawing.Size(84, 16);
            this.lblSoHD.Text = "Số Hợp Đồng";
            // 
            // lblMaPhong
            // 
            this.lblMaPhong.AutoSize = true;
            this.lblMaPhong.Location = new System.Drawing.Point(390, 33);
            this.lblMaPhong.Name = "lblMaPhong";
            this.lblMaPhong.Size = new System.Drawing.Size(68, 16);
            this.lblMaPhong.Text = "Mã Phòng";
            // 
            // lblThoiGianGH
            // 
            this.lblThoiGianGH.AutoSize = true;
            this.lblThoiGianGH.Location = new System.Drawing.Point(390, 78);
            this.lblThoiGianGH.Name = "lblThoiGianGH";
            this.lblThoiGianGH.Size = new System.Drawing.Size(114, 16);
            this.lblThoiGianGH.Text = "Thời Gian GH (tháng)";
            // 
            // btnLapPhieu
            // 
            this.btnLapPhieu.Location = new System.Drawing.Point(510, 130);
            this.btnLapPhieu.Name = "btnLapPhieu";
            this.btnLapPhieu.Size = new System.Drawing.Size(180, 35);
            this.btnLapPhieu.TabIndex = 5;
            this.btnLapPhieu.Text = "Lập Phiếu Gia Hạn";
            this.btnLapPhieu.UseVisualStyleBackColor = true;
            this.btnLapPhieu.Click += new System.EventHandler(this.btnLapPhieu_Click);
            // 
            // FrmGiaHan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 470);
            this.Controls.Add(this.btnLapPhieu);
            this.Controls.Add(this.lblThoiGianGH);
            this.Controls.Add(this.lblMaPhong);
            this.Controls.Add(this.lblSoHD);
            this.Controls.Add(this.lblSoPhiieu);
            this.Controls.Add(this.txtThoiGianGiaHan);
            this.Controls.Add(this.txtMaPhong);
            this.Controls.Add(this.txtSoHopDong);
            this.Controls.Add(this.txtSoPhiieu);
            this.Controls.Add(this.dgvHopDong);
            this.Name = "FrmGiaHan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Lập Phiếu Gia Hạn Hợp Đồng";
            this.Load += new System.EventHandler(this.FrmGiaHan_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}