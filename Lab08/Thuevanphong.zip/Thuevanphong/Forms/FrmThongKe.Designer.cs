﻿namespace QuanLyCaoOc.Forms
{
    partial class FrmThongKe
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvThongKe;
        private System.Windows.Forms.TextBox txtMaKiemTra;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.TextBox txtHinhThucPhat;
        private System.Windows.Forms.TextBox txtSoTienPhat;
        private System.Windows.Forms.ComboBox cboTrangThai;
        private System.Windows.Forms.DateTimePicker dtpNgayKiemTra;
        private System.Windows.Forms.Label lblMaKT;
        private System.Windows.Forms.Label lblNgayKT;
        private System.Windows.Forms.Label lblMaPhong;
        private System.Windows.Forms.Label lblTrangThai;
        private System.Windows.Forms.Label lblHinhThucPhat;
        private System.Windows.Forms.Label lblSoTienPhat;
        private System.Windows.Forms.Button btnGhiNhan;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvThongKe = new System.Windows.Forms.DataGridView();
            this.txtMaKiemTra = new System.Windows.Forms.TextBox();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.txtHinhThucPhat = new System.Windows.Forms.TextBox();
            this.txtSoTienPhat = new System.Windows.Forms.TextBox();
            this.cboTrangThai = new System.Windows.Forms.ComboBox();
            this.dtpNgayKiemTra = new System.Windows.Forms.DateTimePicker();
            this.lblMaKT = new System.Windows.Forms.Label();
            this.lblNgayKT = new System.Windows.Forms.Label();
            this.lblMaPhong = new System.Windows.Forms.Label();
            this.lblTrangThai = new System.Windows.Forms.Label();
            this.lblHinhThucPhat = new System.Windows.Forms.Label();
            this.lblSoTienPhat = new System.Windows.Forms.Label();
            this.btnGhiNhan = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongKe)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvThongKe
            // 
            this.dgvThongKe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvThongKe.Location = new System.Drawing.Point(30, 240);
            this.dgvThongKe.Name = "dgvThongKe";
            this.dgvThongKe.RowHeadersWidth = 51;
            this.dgvThongKe.Size = new System.Drawing.Size(840, 220);
            this.dgvThongKe.TabIndex = 0;
            // 
            // txtMaKiemTra
            // 
            this.txtMaKiemTra.Location = new System.Drawing.Point(150, 30);
            this.txtMaKiemTra.Name = "txtMaKiemTra";
            this.txtMaKiemTra.Size = new System.Drawing.Size(200, 22);
            this.txtMaKiemTra.TabIndex = 1;
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Location = new System.Drawing.Point(150, 110);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.Size = new System.Drawing.Size(200, 22);
            this.txtMaPhong.TabIndex = 2;
            // 
            // txtHinhThucPhat
            // 
            this.txtHinhThucPhat.Location = new System.Drawing.Point(520, 70);
            this.txtHinhThucPhat.Name = "txtHinhThucPhat";
            this.txtHinhThucPhat.Size = new System.Drawing.Size(200, 22);
            this.txtHinhThucPhat.TabIndex = 3;
            // 
            // txtSoTienPhat
            // 
            this.txtSoTienPhat.Location = new System.Drawing.Point(520, 110);
            this.txtSoTienPhat.Name = "txtSoTienPhat";
            this.txtSoTienPhat.Size = new System.Drawing.Size(200, 22);
            this.txtSoTienPhat.TabIndex = 4;
            // 
            // cboTrangThai
            // 
            this.cboTrangThai.FormattingEnabled = true;
            this.cboTrangThai.Items.AddRange(new object[] {
            "Bình thường",
            "Thay đổi kết cấu trái phép",
            "Cần tu sửa định kỳ"});
            this.cboTrangThai.Location = new System.Drawing.Point(520, 30);
            this.cboTrangThai.Name = "cboTrangThai";
            this.cboTrangThai.Size = new System.Drawing.Size(200, 24);
            this.cboTrangThai.TabIndex = 5;
            this.cboTrangThai.Text = "Bình thường";
            // 
            // dtpNgayKiemTra
            // 
            this.dtpNgayKiemTra.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayKiemTra.Location = new System.Drawing.Point(150, 70);
            this.dtpNgayKiemTra.Name = "dtpNgayKiemTra";
            this.dtpNgayKiemTra.Size = new System.Drawing.Size(200, 22);
            this.dtpNgayKiemTra.TabIndex = 6;
            // 
            // lblMaKT
            // 
            this.lblMaKT.AutoSize = true;
            this.lblMaKT.Location = new System.Drawing.Point(30, 33);
            this.lblMaKT.Name = "lblMaKT";
            this.lblMaKT.Size = new System.Drawing.Size(83, 16);
            this.lblMaKT.Text = "Mã Kiểm Tra";
            // 
            // lblNgayKT
            // 
            this.lblNgayKT.AutoSize = true;
            this.lblNgayKT.Location = new System.Drawing.Point(30, 73);
            this.lblNgayKT.Name = "lblNgayKT";
            this.lblNgayKT.Size = new System.Drawing.Size(94, 16);
            this.lblNgayKT.Text = "Ngày Kiểm Tra";
            // 
            // lblMaPhong
            // 
            this.lblMaPhong.AutoSize = true;
            this.lblMaPhong.Location = new System.Drawing.Point(30, 113);
            this.lblMaPhong.Name = "lblMaPhong";
            this.lblMaPhong.Size = new System.Drawing.Size(68, 16);
            this.lblMaPhong.Text = "Mã Phòng";
            // 
            // lblTrangThai
            // 
            this.lblTrangThai.AutoSize = true;
            this.lblTrangThai.Location = new System.Drawing.Point(380, 33);
            this.lblTrangThai.Name = "lblTrangThai";
            this.lblTrangThai.Size = new System.Drawing.Size(123, 16);
            this.lblTrangThai.Text = "Hiện Trạng Kết Cấu";
            // 
            // lblHinhThucPhat
            // 
            this.lblHinhThucPhat.AutoSize = true;
            this.lblHinhThucPhat.Location = new System.Drawing.Point(380, 73);
            this.lblHinhThucPhat.Name = "lblHinhThucPhat";
            this.lblHinhThucPhat.Size = new System.Drawing.Size(95, 16);
            this.lblHinhThucPhat.Text = "Hình Thức Phạt";
            // 
            // lblSoTienPhat
            // 
            this.lblSoTienPhat.AutoSize = true;
            this.lblSoTienPhat.Location = new System.Drawing.Point(380, 113);
            this.lblSoTienPhat.Name = "lblSoTienPhat";
            this.lblSoTienPhat.Size = new System.Drawing.Size(83, 16);
            this.lblSoTienPhat.Text = "Số Tiền Phạt";
            // 
            // btnGhiNhan
            // 
            this.btnGhiNhan.Location = new System.Drawing.Point(520, 160);
            this.btnGhiNhan.Name = "btnGhiNhan";
            this.btnGhiNhan.Size = new System.Drawing.Size(200, 35);
            this.btnGhiNhan.TabIndex = 7;
            this.btnGhiNhan.Text = "Ghi Nhan Kiểm Tra & Phạt";
            this.btnGhiNhan.UseVisualStyleBackColor = true;
            this.btnGhiNhan.Click += new System.EventHandler(this.btnGhiNhan_Click);
            // 
            // FrmThongKe
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 480);
            this.Controls.Add(this.btnGhiNhan);
            this.Controls.Add(this.lblSoTienPhat);
            this.Controls.Add(this.lblHinhThucPhat);
            this.Controls.Add(this.lblTrangThai);
            this.Controls.Add(this.lblMaPhong);
            this.Controls.Add(this.lblNgayKT);
            this.Controls.Add(this.lblMaKT);
            this.Controls.Add(this.dtpNgayKiemTra);
            this.Controls.Add(this.cboTrangThai);
            this.Controls.Add(this.txtSoTienPhat);
            this.Controls.Add(this.txtHinhThucPhat);
            this.Controls.Add(this.txtMaPhong);
            this.Controls.Add(this.txtMaKiemTra);
            this.Controls.Add(this.dgvThongKe);
            this.Name = "FrmThongKe";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kiểm Tra Định Kỳ (1 Năm/Lần) & Xử Lý Vi Phạm Kết Cấu";
            this.Load += new System.EventHandler(this.FrmThongKe_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvThongKe)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}