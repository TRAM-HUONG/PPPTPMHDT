﻿namespace QuanLyCaoOc.Forms
{
    partial class FrmNhanSu
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvNhanVien;
        private System.Windows.Forms.TextBox txtMSNV;
        private System.Windows.Forms.TextBox txtTenNV;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.TextBox txtSdt;
        private System.Windows.Forms.TextBox txtChucVu;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.TextBox txtMaCongTy;
        private System.Windows.Forms.ComboBox cboPhai;
        private System.Windows.Forms.Label lblMSNV;
        private System.Windows.Forms.Label lblTenNV;
        private System.Windows.Forms.Label lblPhai;
        private System.Windows.Forms.Label lblDiaChi;
        private System.Windows.Forms.Label lblSdt;
        private System.Windows.Forms.Label lblChucVu;
        private System.Windows.Forms.Label lblMaPhong;
        private System.Windows.Forms.Label lblMaCongTy;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.Button btnCapTheXe;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvNhanVien = new System.Windows.Forms.DataGridView();
            this.txtMSNV = new System.Windows.Forms.TextBox();
            this.txtTenNV = new System.Windows.Forms.TextBox();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.txtSdt = new System.Windows.Forms.TextBox();
            this.txtChucVu = new System.Windows.Forms.TextBox();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.txtMaCongTy = new System.Windows.Forms.TextBox();
            this.cboPhai = new System.Windows.Forms.ComboBox();
            this.lblMSNV = new System.Windows.Forms.Label();
            this.lblTenNV = new System.Windows.Forms.Label();
            this.lblPhai = new System.Windows.Forms.Label();
            this.lblDiaChi = new System.Windows.Forms.Label();
            this.lblSdt = new System.Windows.Forms.Label();
            this.lblChucVu = new System.Windows.Forms.Label();
            this.lblMaPhong = new System.Windows.Forms.Label();
            this.lblMaCongTy = new System.Windows.Forms.Label();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.btnCapTheXe = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvNhanVien
            // 
            this.dgvNhanVien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvNhanVien.Location = new System.Drawing.Point(30, 240);
            this.dgvNhanVien.Name = "dgvNhanVien";
            this.dgvNhanVien.RowHeadersWidth = 51;
            this.dgvNhanVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvNhanVien.Size = new System.Drawing.Size(840, 220);
            this.dgvNhanVien.TabIndex = 0;
            // 
            // txtMSNV
            // 
            this.txtMSNV.Location = new System.Drawing.Point(130, 30);
            this.txtMSNV.Name = "txtMSNV";
            this.txtMSNV.Size = new System.Drawing.Size(180, 22);
            this.txtMSNV.TabIndex = 1;
            // 
            // txtTenNV
            // 
            this.txtTenNV.Location = new System.Drawing.Point(130, 70);
            this.txtTenNV.Name = "txtTenNV";
            this.txtTenNV.Size = new System.Drawing.Size(180, 22);
            this.txtTenNV.TabIndex = 2;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Location = new System.Drawing.Point(130, 110);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(180, 22);
            this.txtDiaChi.TabIndex = 3;
            // 
            // txtSdt
            // 
            this.txtSdt.Location = new System.Drawing.Point(130, 150);
            this.txtSdt.Name = "txtSdt";
            this.txtSdt.Size = new System.Drawing.Size(180, 22);
            this.txtSdt.TabIndex = 4;
            // 
            // txtChucVu
            // 
            this.txtChucVu.Location = new System.Drawing.Point(450, 70);
            this.txtChucVu.Name = "txtChucVu";
            this.txtChucVu.Size = new System.Drawing.Size(180, 22);
            this.txtChucVu.TabIndex = 5;
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Location = new System.Drawing.Point(450, 110);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.Size = new System.Drawing.Size(180, 22);
            this.txtMaPhong.TabIndex = 6;
            // 
            // txtMaCongTy
            // 
            this.txtMaCongTy.Location = new System.Drawing.Point(450, 150);
            this.txtMaCongTy.Name = "txtMaCongTy";
            this.txtMaCongTy.Size = new System.Drawing.Size(180, 22);
            this.txtMaCongTy.TabIndex = 7;
            // 
            // cboPhai
            // 
            this.cboPhai.FormattingEnabled = true;
            this.cboPhai.Items.AddRange(new object[] {
            "Nam",
            "Nữ",
            "Khác"});
            this.cboPhai.Location = new System.Drawing.Point(450, 30);
            this.cboPhai.Name = "cboPhai";
            this.cboPhai.Size = new System.Drawing.Size(180, 24);
            this.cboPhai.TabIndex = 8;
            this.cboPhai.Text = "Nam";
            // 
            // lblMSNV
            // 
            this.lblMSNV.AutoSize = true;
            this.lblMSNV.Location = new System.Drawing.Point(30, 33);
            this.lblMSNV.Name = "lblMSNV";
            this.lblMSNV.Size = new System.Drawing.Size(47, 16);
            this.lblMSNV.Text = "MSNV";
            // 
            // lblTenNV
            // 
            this.lblTenNV.AutoSize = true;
            this.lblTenNV.Location = new System.Drawing.Point(30, 73);
            this.lblTenNV.Name = "lblTenNV";
            this.lblTenNV.Size = new System.Drawing.Size(53, 16);
            this.lblTenNV.Text = "Tên NV";
            // 
            // lblPhai
            // 
            this.lblPhai.AutoSize = true;
            this.lblPhai.Location = new System.Drawing.Point(350, 33);
            this.lblPhai.Name = "lblPhai";
            this.lblPhai.Size = new System.Drawing.Size(34, 16);
            this.lblPhai.Text = "Phái";
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.AutoSize = true;
            this.lblDiaChi.Location = new System.Drawing.Point(30, 113);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(49, 16);
            this.lblDiaChi.Text = "Địa Chỉ";
            // 
            // lblSdt
            // 
            this.lblSdt.AutoSize = true;
            this.lblSdt.Location = new System.Drawing.Point(30, 153);
            this.lblSdt.Name = "lblSdt";
            this.lblSdt.Size = new System.Drawing.Size(35, 16);
            this.lblSdt.Text = "SĐT";
            // 
            // lblChucVu
            // 
            this.lblChucVu.AutoSize = true;
            this.lblChucVu.Location = new System.Drawing.Point(350, 73);
            this.lblChucVu.Name = "lblChucVu";
            this.lblChucVu.Size = new System.Drawing.Size(56, 16);
            this.lblChucVu.Text = "Chức Vụ";
            // 
            // lblMaPhong
            // 
            this.lblMaPhong.AutoSize = true;
            this.lblMaPhong.Location = new System.Drawing.Point(350, 113);
            this.lblMaPhong.Name = "lblMaPhong";
            this.lblMaPhong.Size = new System.Drawing.Size(68, 16);
            this.lblMaPhong.Text = "Mã Phòng";
            // 
            // lblMaCongTy
            // 
            this.lblMaCongTy.AutoSize = true;
            this.lblMaCongTy.Location = new System.Drawing.Point(350, 153);
            this.lblMaCongTy.Name = "lblMaCongTy";
            this.lblMaCongTy.Size = new System.Drawing.Size(77, 16);
            this.lblMaCongTy.Text = "Mã Công Ty";
            // 
            // btnThemNV
            // 
            this.btnThemNV.Location = new System.Drawing.Point(670, 30);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(180, 35);
            this.btnThemNV.TabIndex = 9;
            this.btnThemNV.Text = "Báo Cáo Nhân Viên Mới";
            this.btnThemNV.UseVisualStyleBackColor = true;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // btnCapTheXe
            // 
            this.btnCapTheXe.Location = new System.Drawing.Point(670, 80);
            this.btnCapTheXe.Name = "btnCapTheXe";
            this.btnCapTheXe.Size = new System.Drawing.Size(180, 35);
            this.btnCapTheXe.TabIndex = 10;
            this.btnCapTheXe.Text = "Cấp Thẻ Giữ Xe";
            this.btnCapTheXe.UseVisualStyleBackColor = true;
            this.btnCapTheXe.Click += new System.EventHandler(this.btnCapTheXe_Click);
            // 
            // FrmNhanSu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 480);
            this.Controls.Add(this.btnCapTheXe);
            this.Controls.Add(this.btnThemNV);
            this.Controls.Add(this.lblMaCongTy);
            this.Controls.Add(this.lblMaPhong);
            this.Controls.Add(this.lblChucVu);
            this.Controls.Add(this.lblSdt);
            this.Controls.Add(this.lblDiaChi);
            this.Controls.Add(this.lblPhai);
            this.Controls.Add(this.lblTenNV);
            this.Controls.Add(this.lblMSNV);
            this.Controls.Add(this.cboPhai);
            this.Controls.Add(this.txtMaCongTy);
            this.Controls.Add(this.txtMaPhong);
            this.Controls.Add(this.txtChucVu);
            this.Controls.Add(this.txtSdt);
            this.Controls.Add(this.txtDiaChi);
            this.Controls.Add(this.txtTenNV);
            this.Controls.Add(this.txtMSNV);
            this.Controls.Add(this.dgvNhanVien);
            this.Name = "FrmNhanSu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Nhân Sự Văn Phòng & Cấp Thẻ Giữ Xe";
            this.Load += new System.EventHandler(this.FrmNhanSu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvNhanVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}