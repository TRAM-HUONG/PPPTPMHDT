﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmGiaHan : Form
    {
        private GiaHanService giaHanService;

        public FrmGiaHan()
        {
            InitializeComponent();
            giaHanService = new GiaHanService();
        }

        private void FrmGiaHan_Load(object sender, EventArgs e)
        {
            LoadDuLieu();
        }

        private void LoadDuLieu()
        {
            try
            {
                dgvHopDong.DataSource = giaHanService.LayDanhSachChiTietHopDong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLapPhieu_Click(object sender, EventArgs e)
        {
            string soPhieu = txtSoPhiieu.Text.Trim();
            string soHD = txtSoHopDong.Text.Trim();
            string maPhong = txtMaPhong.Text.Trim();

            if (string.IsNullOrEmpty(soPhieu) || string.IsNullOrEmpty(soHD) || string.IsNullOrEmpty(maPhong))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Số phiếu gia hạn, Số hợp đồng và Mã phòng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtThoiGianGiaHan.Text.Trim(), out int thoiGianGH))
            {
                MessageBox.Show("Thời gian gia hạn phải là số nguyên (tháng)!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi Service xử lý nghiệp vụ và kiểm tra ràng buộc
            KetQuaXuLy kq = giaHanService.LapPhiếuGiaHan(soPhieu, soHD, maPhong, thoiGianGH);

            // Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Cảnh báo nghiệp vụ", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (kq.ThanhCong)
            {
                LoadDuLieu();
                txtSoPhiieu.Clear();
                txtSoHopDong.Clear();
                txtMaPhong.Clear();
                txtThoiGianGiaHan.Clear();
            }
        }
    }
}