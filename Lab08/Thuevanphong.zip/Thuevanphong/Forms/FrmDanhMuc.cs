﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmDanhMuc : Form
    {
        private DanhMucService danhMucService;

        public FrmDanhMuc()
        {
            InitializeComponent();
            danhMucService = new DanhMucService();
        }

        private void FrmDanhMuc_Load(object sender, EventArgs e)
        {
            LoadDuLieuDichVu();
        }

        private void LoadDuLieuDichVu()
        {
            try
            {
                DataTable dt = danhMucService.LayDanhSachDichVu();
                dgvDichVu.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string maDV = txtMaDV.Text.Trim();
            string tenDV = txtTenDV.Text.Trim();
            string quyCach = txtQuyCach.Text.Trim();

            if (string.IsNullOrEmpty(maDV) || string.IsNullOrEmpty(tenDV))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ mã và tên dịch vụ!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi Service xử lý
            KetQuaXuLy kq = danhMucService.ThemDichVu(maDV, tenDV, quyCach);

            // Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Lỗi", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (kq.ThanhCong)
            {
                LoadDuLieuDichVu();
                txtMaDV.Clear();
                txtTenDV.Clear();
                txtQuyCach.Clear();
            }
        }
    }
}