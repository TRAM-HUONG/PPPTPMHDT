﻿namespace QuanLyCaoOc.Forms
{
    partial class FrmHopDong
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvHopDong;
        private System.Windows.Forms.DataGridView dgvPhong;
        private System.Windows.Forms.TextBox txtSoHopDong;
        private System.Windows.Forms.TextBox txtMaCongTy;
        private System.Windows.Forms.TextBox txtMaPhong;
        private System.Windows.Forms.TextBox txtThoiHan;
        private System.Windows.Forms.TextBox txtNoiDung;
        private System.Windows.Forms.DateTimePicker dtpNgayLap;
        private System.Windows.Forms.Label lblSoHD;
        private System.Windows.Forms.Label lblMaCT;
        private System.Windows.Forms.Label lblMaPhong;
        private System.Windows.Forms.Label lblThoiHan;
        private System.Windows.Forms.Label lblNgayLap;
        private System.Windows.Forms.Label lblNoiDung;
        private System.Windows.Forms.Button btnTaoHopDong;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvHopDong = new System.Windows.Forms.DataGridView();
            this.dgvPhong = new System.Windows.Forms.DataGridView();
            this.txtSoHopDong = new System.Windows.Forms.TextBox();
            this.txtMaCongTy = new System.Windows.Forms.TextBox();
            this.txtMaPhong = new System.Windows.Forms.TextBox();
            this.txtThoiHan = new System.Windows.Forms.TextBox();
            this.txtNoiDung = new System.Windows.Forms.TextBox();
            this.dtpNgayLap = new System.Windows.Forms.DateTimePicker();
            this.lblSoHD = new System.Windows.Forms.Label();
            this.lblMaCT = new System.Windows.Forms.Label();
            this.lblMaPhong = new System.Windows.Forms.Label();
            this.lblThoiHan = new System.Windows.Forms.Label();
            this.lblNgayLap = new System.Windows.Forms.Label();
            this.lblNoiDung = new System.Windows.Forms.Label();
            this.btnTaoHopDong = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvHopDong
            // 
            this.dgvHopDong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvHopDong.Location = new System.Drawing.Point(30, 260);
            this.dgvHopDong.Name = "dgvHopDong";
            this.dgvHopDong.RowHeadersWidth = 51;
            this.dgvHopDong.Size = new System.Drawing.Size(430, 220);
            this.dgvHopDong.TabIndex = 0;
            // 
            // dgvPhong
            // 
            this.dgvPhong.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPhong.Location = new System.Drawing.Point(480, 260);
            this.dgvPhong.Name = "dgvPhong";
            this.dgvPhong.RowHeadersWidth = 51;
            this.dgvPhong.Size = new System.Drawing.Size(400, 220);
            this.dgvPhong.TabIndex = 1;
            // 
            // txtSoHopDong
            // 
            this.txtSoHopDong.Location = new System.Drawing.Point(140, 30);
            this.txtSoHopDong.Name = "txtSoHopDong";
            this.txtSoHopDong.Size = new System.Drawing.Size(200, 22);
            this.txtSoHopDong.TabIndex = 2;
            // 
            // txtMaCongTy
            // 
            this.txtMaCongTy.Location = new System.Drawing.Point(140, 70);
            this.txtMaCongTy.Name = "txtMaCongTy";
            this.txtMaCongTy.Size = new System.Drawing.Size(200, 22);
            this.txtMaCongTy.TabIndex = 3;
            // 
            // txtMaPhong
            // 
            this.txtMaPhong.Location = new System.Drawing.Point(140, 110);
            this.txtMaPhong.Name = "txtMaPhong";
            this.txtMaPhong.Size = new System.Drawing.Size(200, 22);
            this.txtMaPhong.TabIndex = 4;
            // 
            // txtThoiHan
            // 
            this.txtThoiHan.Location = new System.Drawing.Point(580, 30);
            this.txtThoiHan.Name = "txtThoiHan";
            this.txtThoiHan.Size = new System.Drawing.Size(200, 22);
            this.txtThoiHan.TabIndex = 5;
            // 
            // txtNoiDung
            // 
            this.txtNoiDung.Location = new System.Drawing.Point(580, 110);
            this.txtNoiDung.Multiline = true;
            this.txtNoiDung.Name = "txtNoiDung";
            this.txtNoiDung.Size = new System.Drawing.Size(200, 60);
            this.txtNoiDung.TabIndex = 6;
            // 
            // dtpNgayLap
            // 
            this.dtpNgayLap.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgayLap.Location = new System.Drawing.Point(580, 70);
            this.dtpNgayLap.Name = "dtpNgayLap";
            this.dtpNgayLap.Size = new System.Drawing.Size(200, 22);
            this.dtpNgayLap.TabIndex = 7;
            // 
            // lblSoHD
            // 
            this.lblSoHD.AutoSize = true;
            this.lblSoHD.Location = new System.Drawing.Point(30, 33);
            this.lblSoHD.Name = "lblSoHD";
            this.lblSoHD.Size = new System.Drawing.Size(84, 16);
            this.lblSoHD.Text = "Số Hợp Đồng";
            // 
            // lblMaCT
            // 
            this.lblMaCT.AutoSize = true;
            this.lblMaCT.Location = new System.Drawing.Point(30, 73);
            this.lblMaCT.Name = "lblMaCT";
            this.lblMaCT.Size = new System.Drawing.Size(77, 16);
            this.lblMaCT.Text = "Mã Công Ty";
            // 
            // lblMaPhong
            // 
            this.lblMaPhong.AutoSize = true;
            this.lblMaPhong.Location = new System.Drawing.Point(30, 113);
            this.lblMaPhong.Name = "lblMaPhong";
            this.lblMaPhong.Size = new System.Drawing.Size(68, 16);
            this.lblMaPhong.Text = "Mã Phòng";
            // 
            // lblThoiHan
            // 
            this.lblThoiHan.AutoSize = true;
            this.lblThoiHan.Location = new System.Drawing.Point(470, 33);
            this.lblThoiHan.Name = "lblThoiHan";
            this.lblThoiHan.Size = new System.Drawing.Size(95, 16);
            this.lblThoiHan.Text = "Thời Hạn (tháng)";
            // 
            // lblNgayLap
            // 
            this.lblNgayLap.AutoSize = true;
            this.lblNgayLap.Location = new System.Drawing.Point(470, 73);
            this.lblNgayLap.Name = "lblNgayLap";
            this.lblNgayLap.Size = new System.Drawing.Size(64, 16);
            this.lblNgayLap.Text = "Ngày Lập";
            // 
            // lblNoiDung
            // 
            this.lblNoiDung.AutoSize = true;
            this.lblNoiDung.Location = new System.Drawing.Point(470, 113);
            this.lblNoiDung.Name = "lblNoiDung";
            this.lblNoiDung.Size = new System.Drawing.Size(61, 16);
            this.lblNoiDung.Text = "Nội Dung";
            // 
            // btnTaoHopDong
            // 
            this.btnTaoHopDong.Location = new System.Drawing.Point(580, 190);
            this.btnTaoHopDong.Name = "btnTaoHopDong";
            this.btnTaoHopDong.Size = new System.Drawing.Size(200, 35);
            this.btnTaoHopDong.TabIndex = 8;
            this.btnTaoHopDong.Text = "Lập & Ký Hợp Đồng";
            this.btnTaoHopDong.UseVisualStyleBackColor = true;
            this.btnTaoHopDong.Click += new System.EventHandler(this.btnTaoHopDong_Click);
            // 
            // FrmHopDong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 510);
            this.Controls.Add(this.btnTaoHopDong);
            this.Controls.Add(this.lblNoiDung);
            this.Controls.Add(this.lblNgayLap);
            this.Controls.Add(this.lblThoiHan);
            this.Controls.Add(this.lblMaPhong);
            this.Controls.Add(this.lblMaCT);
            this.Controls.Add(this.lblSoHD);
            this.Controls.Add(this.dtpNgayLap);
            this.Controls.Add(this.txtNoiDung);
            this.Controls.Add(this.txtThoiHan);
            this.Controls.Add(this.txtMaPhong);
            this.Controls.Add(this.txtMaCongTy);
            this.Controls.Add(this.txtSoHopDong);
            this.Controls.Add(this.dgvPhong);
            this.Controls.Add(this.dgvHopDong);
            this.Name = "FrmHopDong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản Lý Lập & Ký Hợp Đồng Thuê Văn Phòng";
            this.Load += new System.EventHandler(this.FrmHopDong_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvHopDong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPhong)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
    }
}