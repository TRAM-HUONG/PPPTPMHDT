﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmHopDong : Form
    {
        private HopDongService hopDongService;

        public FrmHopDong()
        {
            InitializeComponent();
            hopDongService = new HopDongService();
        }

        private void FrmHopDong_Load(object sender, EventArgs e)
        {
            LoadDuLieu();
        }

        private void LoadDuLieu()
        {
            try
            {
                dgvHopDong.DataSource = hopDongService.LayDanhSachHopDong();
                dgvPhong.DataSource = hopDongService.LayDanhSachPhong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnTaoHopDong_Click(object sender, EventArgs e)
        {
            string soHD = txtSoHopDong.Text.Trim();
            string maCT = txtMaCongTy.Text.Trim();
            string maPhong = txtMaPhong.Text.Trim();
            string noiDung = txtNoiDung.Text.Trim();
            DateTime ngayLap = dtpNgayLap.Value;

            if (string.IsNullOrEmpty(soHD) || string.IsNullOrEmpty(maCT) || string.IsNullOrEmpty(maPhong))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ Số hợp đồng, Mã công ty và Mã phòng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!int.TryParse(txtThoiHan.Text.Trim(), out int thoiHan))
            {
                MessageBox.Show("Thời hạn thuê phải là số nguyên (tính theo tháng)!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi Service xử lý nghiệp vụ
            KetQuaXuLy kq = hopDongService.TaoHopDong(soHD, ngayLap, noiDung, maCT, maPhong, thoiHan);

            // Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Lỗi", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Error);

            if (kq.ThanhCong)
            {
                LoadDuLieu();
                txtSoHopDong.Clear();
                txtMaCongTy.Clear();
                txtMaPhong.Clear();
                txtNoiDung.Clear();
                txtThoiHan.Clear();
            }
        }
    }
}