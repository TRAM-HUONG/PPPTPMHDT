﻿using System;
using System.Data;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmThongKe : Form
    {
        private ThongKeService thongKeService;

        public FrmThongKe()
        {
            InitializeComponent();
            thongKeService = new ThongKeService();
        }

        private void FrmThongKe_Load(object sender, EventArgs e)
        {
            LoadDuLieu();
        }

        private void LoadDuLieu()
        {
            try
            {
                dgvThongKe.DataSource = thongKeService.LayDanhSachKiemTraVaViPham();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi tải dữ liệu: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnGhiNhan_Click(object sender, EventArgs e)
        {
            string maKT = txtMaKiemTra.Text.Trim();
            string maPhong = txtMaPhong.Text.Trim();
            string trangThai = cboTrangThai.SelectedItem?.ToString() ?? "Bình thường";
            string hinhThucPhat = txtHinhThucPhat.Text.Trim();
            DateTime ngayKT = dtpNgayKiemTra.Value;

            if (string.IsNullOrEmpty(maKT) || string.IsNullOrEmpty(maPhong))
            {
                MessageBox.Show("Vui lòng nhập Mã kiểm tra và Mã phòng!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtSoTienPhat.Text.Trim(), out decimal soTienPhat))
            {
                soTienPhat = 0; // Mặc định không phạt tiền nếu để trống
            }

            // Gọi Service xử lý nghiệp vụ kiểm tra định kỳ & vi phạm kết cấu
            KetQuaXuLy kq = thongKeService.GhiNhanKiemTraViPham(maKT, ngayKT, maPhong, trangThai, hinhThucPhat, soTienPhat);

            // Form chỉ hiển thị thông báo và nạp lại dữ liệu
            MessageBox.Show(kq.ThongBao, kq.ThanhCong ? "Thành công" : "Cảnh báo", MessageBoxButtons.OK, kq.ThanhCong ? MessageBoxIcon.Information : MessageBoxIcon.Warning);

            if (kq.ThanhCong)
            {
                LoadDuLieu();
                txtMaKiemTra.Clear();
                txtMaPhong.Clear();
                txtHinhThucPhat.Clear();
                txtSoTienPhat.Clear();
            }
        }
    }
}