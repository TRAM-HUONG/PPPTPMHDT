﻿using System;
using System.Windows.Forms;
using QuanLyCaoOc.Services;

namespace QuanLyCaoOc.Forms
{
    public partial class FrmMain : Form
    {
        private MainService mainService;

        public FrmMain()
        {
            InitializeComponent();
            mainService = new MainService();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            // Kiểm tra kết nối CSDL khi mở form
            KetQuaXuLy kq = mainService.KiemTraKetNoi();
            if (!kq.ThanhCong)
            {
                MessageBox.Show(kq.ThongBao, "Cảnh báo kết nối", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // 1. Quản lý Danh mục (Dịch vụ,...)
        private void btnDanhMuc_Click(object sender, EventArgs e)
        {
            FrmDanhMuc frm = new FrmDanhMuc();
            frm.ShowDialog();
        }

        // 2. Quản lý Phòng & Tầng
        private void btnPhong_Click(object sender, EventArgs e)
        {
            FrmPhong frm = new FrmPhong();
            frm.ShowDialog();
        }

        // 3. Quản lý Hợp đồng (Thuê nhiều phòng, trả trước 6 tháng)
        private void btnHopDong_Click(object sender, EventArgs e)
        {
            FrmHopDong frm = new FrmHopDong();
            frm.ShowDialog();
        }

        // 4. Lập phiếu gia hạn hợp đồng
        private void btnGiaHan_Click(object sender, EventArgs e)
        {
            FrmGiaHan frm = new FrmGiaHan();
            frm.ShowDialog();
        }

        // 5. Quản lý Thanh toán (Tiền thuê từ tháng 7 & Hóa đơn dịch vụ cuối tháng)
        private void btnThanhToan_Click(object sender, EventArgs e)
        {
            FrmThanhToan frm = new FrmThanhToan();
            frm.ShowDialog();
        }

        // 6. Quản lý Nhân sự văn phòng
        private void btnNhanSu_Click(object sender, EventArgs e)
        {
            FrmNhanSu frm = new FrmNhanSu();
            frm.ShowDialog();
        }

        // 7. Cấp phát và quản lý Thẻ xe
        private void btnTheXe_Click(object sender, EventArgs e)
        {
            FrmTheXe frm = new FrmTheXe();
            frm.ShowDialog();
        }

        // 8. Kiểm tra định kỳ 1 năm/lần & Xử lý vi phạm kết cấu
        private void btnThongKe_Click(object sender, EventArgs e)
        {
            FrmThongKe frm = new FrmThongKe();
            frm.ShowDialog();
        }

        // 9. Thoát chương trình
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}