﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class TheXeService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        // Lấy danh sách thẻ xe đã cấp kết hợp thông tin nhân viên
        public DataTable LayDanhSachTheXe()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Giả định bảng TheXe lưu trữ: MaThe, MSNV, BienSoXe, LoaiXe
                string query = @"SELECT t.MaThe, t.BienSoXe, t.LoaiXe, 
                                        nv.MSNV, nv.TenNV, nv.ChucVu, nv.MaPhong, nv.MaCongTy
                                 FROM TheXe t
                                 JOIN NhanVien nv ON t.MSNV = nv.MSNV";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Lấy danh sách nhân viên đã được báo cáo để cấp thẻ xe
        public DataTable LayDanhSachNhanVien()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT MSNV, TenNV, MaPhong, MaCongTy FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Cấp thẻ giữ xe mới cho nhân viên
        public KetQuaXuLy CapTheXe(string maThe, string msnv, string bienSoXe, string loaiXe)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Kiểm tra nhân viên có tồn tại không
                    string checkNV = "SELECT COUNT(*) FROM NhanVien WHERE MSNV = @MSNV";
                    using (SqlCommand cmdCheck = new SqlCommand(checkNV, conn))
                    {
                        cmdCheck.Parameters.AddWithValue("@MSNV", msnv);
                        int count = (int)cmdCheck.ExecuteScalar();
                        if (count == 0)
                        {
                            return new KetQuaXuLy(false, "Mã số nhân viên không tồn tại trong hệ thống quản lý tòa nhà!");
                        }
                    }

                    // Thêm thẻ giữ xe
                    string query = @"INSERT INTO TheXe (MaThe, MSNV, BienSoXe, LoaiXe) 
                                     VALUES (@MaThe, @MSNV, @BienSoXe, @LoaiXe)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaThe", maThe);
                        cmd.Parameters.AddWithValue("@MSNV", msnv);
                        cmd.Parameters.AddWithValue("@BienSoXe", bienSoXe);
                        cmd.Parameters.AddWithValue("@LoaiXe", loaiXe);
                        cmd.ExecuteNonQuery();
                    }
                }
                return new KetQuaXuLy(true, "Cấp thẻ giữ xe thành công! Thẻ ghi rõ mã thẻ, thông tin nhân viên và thông tin xe.");
            }
            catch (Exception ex)
            {
                return new KetQuaXuLy(false, "Lỗi khi cấp thẻ xe (Có thể trùng mã thẻ): " + ex.Message);
            }
        }
    }
}