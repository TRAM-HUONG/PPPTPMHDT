﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class HopDongService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        // Lấy danh sách hợp đồng
        public DataTable LayDanhSachHopDong()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT h.SoHopDong, h.NgayLapHopDong, h.NoiDungHopDong, 
                                        c.TenCongTy, c.MaCongTy
                                 FROM HopDong h
                                 LEFT JOIN CongTy c ON h.SoHopDong = c.SoHopDong";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Lấy danh sách phòng trống để chọn thuê
        public DataTable LayDanhSachPhong()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT MaPhong, Tang, DienTich FROM Phong";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Thêm mới hợp đồng và chi tiết phòng thuê (Đảm bảo thời hạn ít nhất 6 tháng)
        public KetQuaXuLy TaoHopDong(string soHopDong, DateTime ngayLap, string noiDung, string maCongTy, string maPhong, int thoiHan)
        {
            if (thoiHan < 6)
            {
                return new KetQuaXuLy(false, "Quy định nghiệp vụ: Thời gian của đợt thuê ít nhất phải từ 6 tháng trở lên!");
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlTransaction transaction = conn.BeginTransaction();
                try
                {
                    // 1. Thêm vào bảng HopDong
                    string queryHD = "INSERT INTO HopDong (SoHopDong, NgayLapHopDong, NoiDungHopDong) VALUES (@SoHD, @NgayLap, @NoiDung)";
                    using (SqlCommand cmdHD = new SqlCommand(queryHD, conn, transaction))
                    {
                        cmdHD.Parameters.AddWithValue("@SoHD", soHopDong);
                        cmdHD.Parameters.AddWithValue("@NgayLap", ngayLap);
                        cmdHD.Parameters.AddWithValue("@NoiDung", noiDung);
                        cmdHD.ExecuteNonQuery();
                    }

                    // 2. Cập nhật thông tin hợp đồng cho Công ty
                    string queryCT = "UPDATE CongTy SET SoHopDong = @SoHD WHERE MaCongTy = @MaCT";
                    using (SqlCommand cmdCT = new SqlCommand(queryCT, conn, transaction))
                    {
                        cmdCT.Parameters.AddWithValue("@SoHD", soHopDong);
                        cmdCT.Parameters.AddWithValue("@MaCT", maCongTy);
                        cmdCT.ExecuteNonQuery();
                    }

                    // 3. Thêm vào bảng ChiTietHopDong (Thuê phòng & thời hạn)
                    string queryCTHD = "INSERT INTO ChiTietHopDong (SoHopDong, MaPhong, ThoiHan) VALUES (@SoHD, @MaPhong, @ThoiHan)";
                    using (SqlCommand cmdCTHD = new SqlCommand(queryCTHD, conn, transaction))
                    {
                        cmdCTHD.Parameters.AddWithValue("@SoHD", soHopDong);
                        cmdCTHD.Parameters.AddWithValue("@MaPhong", maPhong);
                        cmdCTHD.Parameters.AddWithValue("@ThoiHan", thoiHan);
                        cmdCTHD.ExecuteNonQuery();
                    }

                    transaction.Commit();
                    return new KetQuaXuLy(true, "Lập hợp đồng thành công! Khách hàng bắt buộc phải thanh toán trước tiền thuê 6 tháng đầu.");
                }
                catch (Exception ex)
                {
                    transaction.Rollback();
                    return new KetQuaXuLy(false, "Lỗi khi tạo hợp đồng: " + ex.Message);
                }
            }
        }
    }
}