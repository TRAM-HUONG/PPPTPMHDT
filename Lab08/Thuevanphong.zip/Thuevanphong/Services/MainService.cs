﻿using System;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class MainService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        public KetQuaXuLy KiemTraKetNoi()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    return new KetQuaXuLy(true, "Kết nối cơ sở dữ liệu thành công!");
                }
            }
            catch (Exception ex)
            {
                return new KetQuaXuLy(false, "Lỗi kết nối CSDL: " + ex.Message);
            }
        }
    }
}