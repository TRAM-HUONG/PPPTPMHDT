﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class ThongKeService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        // Lấy danh sách kiểm tra định kỳ 1 năm/lần & vi phạm kết cấu phòng
        public DataTable LayDanhSachKiemTraVaViPham()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                // Giả định bảng KiemTraDinhKy lưu trữ thông tin kiểm tra phòng và xử phạt vi phạm kết cấu
                string query = @"SELECT MaKiemTra, NgayKiemTra, MaPhong, TrangThaiKetCuu, HinhThucPhat, SoTienPhat 
                                 FROM KiemTraDinhKy";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        try
                        {
                            da.Fill(dt);
                        }
                        catch
                        {
                            // Trả về bảng trống nếu chưa tạo bảng KiemTraDinhKy trong CSDL
                        }
                    }
                }
            }
            return dt;
        }

        // Ghi nhận đợt kiểm tra định kỳ (1 năm/lần) hoặc xử phạt vi phạm thay đổi kết cấu
        public KetQuaXuLy GhiNhanKiemTraViPham(string maKiemTra, DateTime ngayKiemTra, string maPhong, string trangThai, string hinhThucPhat, decimal soTienPhat)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Kiểm tra phòng có tồn tại không
                    string checkPhong = "SELECT COUNT(*) FROM Phong WHERE MaPhong = @MaPhong";
                    using (SqlCommand cmdCheck = new SqlCommand(checkPhong, conn))
                    {
                        cmdCheck.Parameters.AddWithValue("@MaPhong", maPhong);
                        int count = (int)cmdCheck.ExecuteScalar();
                        if (count == 0)
                        {
                            return new KetQuaXuLy(false, "Mã phòng không tồn tại trong cao ốc!");
                        }
                    }

                    string query = @"INSERT INTO KiemTraDinhKy (MaKiemTra, NgayKiemTra, MaPhong, TrangThaiKetCuu, HinhThucPhat, SoTienPhat) 
                                     VALUES (@MaKT, @NgayKT, @MaPhong, @TrangThai, @HinhThuc, @TienPhat)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaKT", maKiemTra);
                        cmd.Parameters.AddWithValue("@NgayKT", ngayKiemTra);
                        cmd.Parameters.AddWithValue("@MaPhong", maPhong);
                        cmd.Parameters.AddWithValue("@TrangThai", trangThai);
                        cmd.Parameters.AddWithValue("@HinhThuc", hinhThucPhat);
                        cmd.Parameters.AddWithValue("@TienPhat", soTienPhat);
                        cmd.ExecuteNonQuery();
                    }
                }
                return new KetQuaXuLy(true, "Ghi nhận kết quả kiểm tra định kỳ (1 năm/lần) và xử phạt vi phạm kết cấu thành công!");
            }
            catch (Exception ex)
            {
                return new KetQuaXuLy(false, "Lỗi khi ghi nhận (Đảm bảo đã tạo bảng KiemTraDinhKy trong CSDL): " + ex.Message);
            }
        }
    }
}