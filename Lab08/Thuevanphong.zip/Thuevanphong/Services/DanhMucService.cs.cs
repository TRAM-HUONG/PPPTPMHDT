﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class DanhMucService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        // Lấy danh sách Dịch vụ (Điện, Nước, Internet...)
        public DataTable LayDanhSachDichVu()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT MaDichVu, TenDichVu, QuyCach FROM DichVu";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Thêm hoặc cập nhật dịch vụ với trả về KetQuaXuLy
        public KetQuaXuLy ThemDichVu(string maDV, string tenDV, string quyCach)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = "INSERT INTO DichVu (MaDichVu, TenDichVu, QuyCach) VALUES (@MaDV, @TenDV, @QuyCach)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaDV", maDV);
                        cmd.Parameters.AddWithValue("@TenDV", tenDV);
                        cmd.Parameters.AddWithValue("@QuyCach", quyCach);
                        cmd.ExecuteNonQuery();
                    }
                }
                return new KetQuaXuLy(true, "Thêm dịch vụ thành công!");
            }
            catch (Exception ex)
            {
                return new KetQuaXuLy(false, "Lỗi khi thêm dịch vụ: " + ex.Message);
            }
        }
    }
}