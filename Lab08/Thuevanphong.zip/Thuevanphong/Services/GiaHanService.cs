﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class GiaHanService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        // Lấy danh sách hợp đồng & chi tiết để khách chọn gia hạn
        public DataTable LayDanhSachChiTietHopDong()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT ct.SoHopDong, ct.MaPhong, ct.ThoiHan, h.NgayLapHopDong 
                                 FROM ChiTietHopDong ct
                                 JOIN HopDong h ON ct.SoHopDong = h.SoHopDong";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Lập phiếu gia hạn với kiểm tra điều kiện nghiệp vụ
        public KetQuaXuLy LapPhiếuGiaHan(string soPhiieu, string soHopDong, string maPhong, int thoiGianGiaHan)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();

                // 1. Kiểm tra thời gian thuê ban đầu của hợp đồng này
                string queryThoiHanGoc = "SELECT ThoiHan FROM ChiTietHopDong WHERE SoHopDong = @SoHD AND MaPhong = @MaPhong";
                int thoiHanGoc = 0;
                using (SqlCommand cmdTH = new SqlCommand(queryThoiHanGoc, conn))
                {
                    cmdTH.Parameters.AddWithValue("@SoHD", soHopDong);
                    cmdTH.Parameters.AddWithValue("@MaPhong", maPhong);
                    object result = cmdTH.ExecuteScalar();
                    if (result != null)
                    {
                        thoiHanGoc = Convert.ToInt32(result);
                    }
                    else
                    {
                        return new KetQuaXuLy(false, "Không tìm thấy thông tin chi tiết hợp đồng và phòng này!");
                    }
                }

                // 2. Kiểm tra quy tắc: Thời gian gia hạn <= 1/2 thời gian thuê ban đầu
                if (thoiGianGiaHan > (thoiHanGoc / 2.0))
                {
                    return new KetQuaXuLy(false, $"Quy định nghiệp vụ: Thời gian gia hạn tối đa không được vượt quá 1/2 thời gian thuê ban đầu (<= {thoiHanGoc / 2.0} tháng)!");
                }

                // 3. Kiểm tra điều kiện: Đã thanh toán đầy đủ dịch vụ và không nợ tiền thuê (Giả lập kiểm tra qua trạng thái hóa đơn/công nợ)
                // Trong thực tế sẽ có câu lệnh truy vấn kiểm tra các hóa đơn chưa thanh toán.
                bool chuaThanhToanHoaDon = false; // Ví dụ kiểm tra cước dịch vụ cuối tháng
                if (chuaThanhToanHoaDon)
                {
                    return new KetQuaXuLy(false, "Văn phòng thuê chưa thanh toán đầy đủ các hóa đơn dịch vụ hoặc còn nợ tiền mặt bằng. Không thể lập phiếu gia hạn!");
                }

                // 4. Tiến hành lập phiếu gia hạn
                string queryInsert = @"INSERT INTO PhieuGiaHan (SoPhieuGiaHan, NgayLapPhieuGiaHan, NgayHetHan, SoHopDong, MaPhong) 
                                       VALUES (@SoPhiieu, GETDATE(), DATEADD(month, @ThoiGianGH, GETDATE()), @SoHD, @MaPhong)";
                using (SqlCommand cmdInsert = new SqlCommand(queryInsert, conn))
                {
                    cmdInsert.Parameters.AddWithValue("@SoPhiieu", soPhiieu);
                    cmdInsert.Parameters.AddWithValue("@ThoiGianGH", thoiGianGiaHan);
                    cmdInsert.Parameters.AddWithValue("@SoHD", soHopDong);
                    cmdInsert.Parameters.AddWithValue("@MaPhong", maPhong);
                    cmdInsert.ExecuteNonQuery();
                }

                return new KetQuaXuLy(true, "Lập phiếu gia hạn hợp đồng thành công!");
            }
        }
    }
}