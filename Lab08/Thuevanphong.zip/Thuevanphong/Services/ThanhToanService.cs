﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class ThanhToanService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        // Lấy danh sách hóa đơn dịch vụ đã phát sinh
        public DataTable LayDanhSachHoaDon()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT h.SoHoaDon, h.NgayLapHoaDon, h.SoLuongDichVu, 
                                        h.SoHopDong, h.MaPhong, d.TenDichVu, d.QuyCach
                                 FROM HoaDon h
                                 JOIN DichVu d ON h.MaDichVu = d.MaDichVu";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Lấy danh sách dịch vụ để lập hóa đơn cuối tháng
        public DataTable LayDanhSachDichVu()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT MaDichVu, TenDichVu FROM DichVu";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Lập hóa đơn chi phí dịch vụ (Điện, nước, internet) thanh toán vào cuối tháng
        public KetQuaXuLy LapHoaDonDichVu(string soHoaDon, string soHopDong, string maPhong, string maDichVu, int soLuong)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string query = @"INSERT INTO HoaDon (SoHoaDon, NgayLapHoaDon, SoLuongDichVu, SoHopDong, MaPhong, MaDichVu) 
                                     VALUES (@SoHDn, GETDATE(), @SoLuong, @SoHD, @MaPhong, @MaDV)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@SoHDn", soHoaDon);
                        cmd.Parameters.AddWithValue("@SoLuong", soLuong);
                        cmd.Parameters.AddWithValue("@SoHD", soHopDong);
                        cmd.Parameters.AddWithValue("@MaPhong", maPhong);
                        cmd.Parameters.AddWithValue("@MaDV", maDichVu);
                        cmd.ExecuteNonQuery();
                    }
                }
                return new KetQuaXuLy(true, "Lập hóa đơn dịch vụ (thanh toán cuối tháng) thành công!");
            }
            catch (Exception ex)
            {
                return new KetQuaXuLy(false, "Lỗi khi lập hóa đơn dịch vụ: " + ex.Message);
            }
        }

        // Ghi nhận thanh toán tiền thuê mặt bằng hàng tháng (Từ tháng thứ 7 trở đi, trả vào đầu tháng)
        public KetQuaXuLy ThanhToanTienThueHangThang(string soHopDong, string maPhong, int thangThu)
        {
            if (thangThu < 7)
            {
                return new KetQuaXuLy(false, "6 tháng đầu tiên khách hàng đã trả trước khi ký hợp đồng! Tiền thuê hàng tháng chỉ áp dụng từ tháng thứ 7 trở đi.");
            }

            try
            {
                // Logic xử lý thu tiền thuê mặt bằng đầu tháng
                return new KetQuaXuLy(true, $"Xác nhận thanh toán tiền thuê văn phòng phòng {maPhong} cho tháng thứ {thangThu} thành công (Đã thu vào đầu tháng).");
            }
            catch (Exception ex)
            {
                return new KetQuaXuLy(false, "Lỗi thanh toán tiền thuê: " + ex.Message);
            }
        }
    }
}