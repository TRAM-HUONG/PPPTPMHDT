﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class PhongService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        // Lấy danh sách phòng kết hợp thông tin mức giá
        public DataTable LayDanhSachPhong()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT p.MaPhong, p.Tang, p.DienTich, m.GiaCa 
                                 FROM Phong p 
                                 LEFT JOIN MucGia m ON p.Tang = m.Tang AND p.DienTich = m.DienTich";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Thêm phòng mới
        public KetQuaXuLy ThemPhong(string maPhong, int tang, float dienTich)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    // Kiểm tra xem mức giá theo tầng và diện tích đã được cấu hình trong bảng MucGia chưa
                    string checkMucGia = "SELECT COUNT(*) FROM MucGia WHERE Tang = @Tang AND DienTich = @DienTich";
                    using (SqlCommand cmdCheck = new SqlCommand(checkMucGia, conn))
                    {
                        cmdCheck.Parameters.AddWithValue("@Tang", tang);
                        cmdCheck.Parameters.AddWithValue("@DienTich", dienTich);
                        int count = (int)cmdCheck.ExecuteScalar();
                        if (count == 0)
                        {
                            return new KetQuaXuLy(false, "Mức giá cho Tầng và Diện tích này chưa được cấu hình trong hệ thống!");
                        }
                    }

                    string query = "INSERT INTO Phong (MaPhong, Tang, DienTich) VALUES (@MaPhong, @Tang, @DienTich)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaPhong", maPhong);
                        cmd.Parameters.AddWithValue("@Tang", tang);
                        cmd.Parameters.AddWithValue("@DienTich", dienTich);
                        cmd.ExecuteNonQuery();
                    }
                }
                return new KetQuaXuLy(true, "Thêm phòng thành công!");
            }
            catch (Exception ex)
            {
                return new KetQuaXuLy(false, "Lỗi khi thêm phòng: " + ex.Message);
            }
        }
    }
}