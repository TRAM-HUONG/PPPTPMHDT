﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace QuanLyCaoOc.Services
{
    public class NhanSuService
    {
        private readonly string connectionString = "Server=localhost;Database=QuanLyChoThueVanPhong;Integrated Security=true;";

        // Lấy danh sách nhân viên làm việc tại các văn phòng
        public DataTable LayDanhSachNhanVien()
        {
            DataTable dt = new DataTable();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = @"SELECT MSNV, TenNV, Phai, DiaChiNV, SdtNV, ChucVu, MaPhong, MaCongTy 
                                 FROM NhanVien";
                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }
            }
            return dt;
        }

        // Báo cáo nhân viên mới (Khi công ty tuyển dụng nhân viên mới phải báo cáo cho bộ phận quản lý)
        public KetQuaXuLy ThemNhanVienMoi(string msnv, string tenNV, string phai, string diaChi, string sdt, string chucVu, string maPhong, string maCongTy)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    // Kiểm tra phòng và công ty có tồn tại không
                    string queryCheck = "SELECT COUNT(*) FROM Phong WHERE MaPhong = @MaPhong";
                    using (SqlCommand cmdCheck = new SqlCommand(queryCheck, conn))
                    {
                        cmdCheck.Parameters.AddWithValue("@MaPhong", maPhong);
                        int count = (int)cmdCheck.ExecuteScalar();
                        if (count == 0)
                        {
                            return new KetQuaXuLy(false, "Mã phòng không tồn tại trong hệ thống tòa nhà!");
                        }
                    }

                    string query = @"INSERT INTO NhanVien (MSNV, TenNV, Phai, DiaChiNV, SdtNV, ChucVu, MaPhong, MaCongTy) 
                                     VALUES (@MSNV, @TenNV, @Phai, @DiaChi, @Sdt, @ChucVu, @MaPhong, @MaCongTy)";
                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@MSNV", msnv);
                        cmd.Parameters.AddWithValue("@TenNV", tenNV);
                        cmd.Parameters.AddWithValue("@Phai", phai);
                        cmd.Parameters.AddWithValue("@DiaChi", diaChi);
                        cmd.Parameters.AddWithValue("@Sdt", sdt);
                        cmd.Parameters.AddWithValue("@ChucVu", chucVu);
                        cmd.Parameters.AddWithValue("@MaPhong", maPhong);
                        cmd.Parameters.AddWithValue("@MaCongTy", maCongTy);
                        cmd.ExecuteNonQuery();
                    }
                }
                return new KetQuaXuLy(true, "Báo cáo nhân viên mới và cập nhật hồ sơ thành công! Nhân viên đủ điều kiện cấp thẻ giữ xe.");
            }
            catch (Exception ex)
            {
                return new KetQuaXuLy(false, "Lỗi khi thêm nhân viên: " + ex.Message);
            }
        }
    }
}